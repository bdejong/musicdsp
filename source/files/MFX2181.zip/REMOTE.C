/****************************************************************************/
/*                      Link to MFX system (ADSP-2181)                      */
/****************************************************************************/

/****************************************************************************/
/*                      (C)oded by VladiTX, 1998                            */
/****************************************************************************/

#include    <stdio.h>
#include    <dos.h>
#include    <string.h>
#include    <conio.h>
#include    <ctype.h>

#define CMD_FILTER_OFF  0x0030
#define CMD_FILTER_ON   0x0031
#define CMD_CHORUS_OFF  0x0032
#define CMD_CHORUS_ON   0x0033
#define CMD_REVERB      0x0034

#define CMD_SYNTH       0x0010
#define CMD_GUITAR      0x0020

#define CMD_SONG_1      0x0040
#define CMD_SONG_2      0x0041
#define CMD_SONG_3      0x0042
#define CMD_SONG_4      0x0043
#define CMD_SONG_5      0x0044

/* ������������������������������������������������������������������������� */

#define spy_row     24
#define spy_col     38

char faces [] = {0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0x28,0x54,0xAA,0xFE,0xB6,
                 0xFE,0xFE,0xFE,0x44,0x7C,0x38,0x38,0x38,0xFE,0,0,0,0,0,0,0,0,
                 0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0x28,0x54,0x54,0,0,
                 0x28,0x54,0xAA,0xFE,0xDA,0xFE,0xFE,0xFE,0x44,0x7C,0x38,0x38,
                 0x38,0xFE,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0x28,0x54,0xAA,
                 0xFE,0x92,0x92,0xFE,0xC6,0x44,0x7C,0x38,0x38,0x38,0xFE};

unsigned    hgt;

void spy (void)
{
    hgt = 0;
    _asm {
        pusha

        call    draw
raise:  mov     si,offset faces [0]
        call    part
        mov     bx,2
        call    delay1
        inc     [hgt]
        mov     ax,[hgt]
        cmp     ax,17
        jb      raise

        mov     bx,8
        call    delay1
        mov     si,offset faces [64]
        call    showf
        mov     si,offset faces [16]
        call    showf
        mov     si,offset faces [64]
        call    showf
        mov     si,offset faces [16]
        call    showf
        mov     si,offset faces [96]
        call    showf
        mov     bx,8
        call    delay1

        dec     [hgt]
lower:  mov     si,offset faces [80]
        call    part
        mov     bx,2
        call    delay1
        dec     [hgt]
        jns     lower

        mov     ax,0b800h
        mov     es,ax
        mov     word ptr es:[spy_row*160+spy_col*2],' '+256*07
        mov     word ptr es:[spy_row*160+spy_col*2+2],' '+256*07
        mov     word ptr es:[spy_row*160+spy_col*2+4],' '+256*07

        popa
        jmp     spy_done
; --------------------------------------------------------------------------
draw:   call    Plane_2_enable
        mov     ax,0a000h
        mov     es,ax
        cld
        mov     di,1*32
        mov     cx,32
        xor     ax,ax
        rep     stosw
        call    Normal_Vga_Text
        mov     ax,0b800h
        mov     es,ax
        mov     word ptr es:[spy_row*160+spy_col*2],02+256*13
        mov     word ptr es:[spy_row*160+spy_col*2+2],01+256*14
        mov     word ptr es:[spy_row*160+spy_col*2+4],02+256*13
        ret
; --------------------------------------------------------------------------
Plane_2_enable:
        cli
        mov     dx,03c4h
        mov     ax,0402h                ; Select plane #02 for write.
        out     dx,ax                   ;
        mov     ax,0704h                ; Text, with seq. memory mapping.
        out     dx,ax
        mov     dx,03ceh
        mov     ax,0204h                ; Select plane #02 for read.
        out     dx,ax
        mov     ax,0005h                ; Sequential write mode #00 (?direct).
        out     dx,ax
        mov     ax,0406h                ; Map video memory at: 0a000h-0bfffh
        out     dx,ax
        sti
        ret
; --------------------------------------------------------------------------
Normal_Vga_Text:
        cli
        mov     dx,03c4h
        mov     ax,0302h                ; Select planes 0 & 1 for write.
        out     dx,ax                   ;            0 - text ; 1 - attributes
        mov     ax,0304h                ; Text, with odd-even mapping.
        out     dx,ax

        mov     dx,03ceh
        mov     ax,0004h                ; Select plane #00 for read.
        out     dx,ax
        mov     ax,1005h                ; bit A0=plane -> for Odd-Even.
        out     dx,ax
        mov     ax,0e06h                ; Map video memory at: 0b800h-0bfffh
        out     dx,ax
        sti
        ret
; --------------------------------------------------------------------------
part:   call    Plane_2_enable
        add     si,[hgt]
        cld
        mov     ax,0a000h
        mov     es,ax
        mov     di,1*32
        mov     cx,32
        rep     movsb
        mov     si,offset faces [32]
        add     si,[hgt]
        mov     cx,32
        rep     movsb
        jmp     Normal_Vga_Text
; --------------------------------------------------------------------------
delay1: xor     ah,ah
        int     1ah
        add     dx,bx
        adc     cx,0
        mov     si,cx
        mov     di,dx
sleep:  xor     ah,ah
        int     1ah
        sub     dx,di
        sbb     cx,si
        jc      sleep
        ret
; --------------------------------------------------------------------------
showf:  call    Plane_2_enable
        mov     ax,0a000h
        mov     es,ax
        cld
        mov     di,1*32
        mov     cx,16
        rep     movsb
        call    Normal_Vga_Text
        mov     bx,8
        jmp     delay1
; --------------------------------------------------------------------------
spy_done:
    }
}

/* ������������������������������������������������������������������������� */

#define BAUDRATE    0x0024                      /* divisor for 3200 bps */

#define UART_8250   0
#define UART_16450  1
#define UART_16550  2
#define UART_16550A 3

char    *UART_TYPES [] = {"8250", "16450", "16550", "16550A"};

int     comx [4];
int     uart_port;
char    IRQ,bit_IRQ;

void detect_COMs (void)
{
    comx [0] = *((int _far *)(0x400L));
    comx [1] = *((int _far *)(0x402L));
    comx [2] = *((int _far *)(0x404L));
    comx [3] = *((int _far *)(0x406L));
}

int uart_detect (void)
{
    int     i,scratch;
    int     iir;

    scratch = inp (uart_port + 7);
    for (i = 0; i < 256; i++) {
        outp (uart_port + 7, i);
        if (inp (uart_port + 7) != i) {
            outp (uart_port + 7, scratch);
            return (UART_8250);
        }
    }
    outp (uart_port + 7, scratch);
    outp (uart_port + 2, 0x01);                 /* enable FIFO              */
    iir = inp (uart_port + 2);
    outp (uart_port + 2, 0x00);                 /* disable FIFO             */
    if (iir & 0x40) return (UART_16550A);
    if (iir & 0x80) return (UART_16550);
    return (UART_16450);
}

void uart_init (int mode)                      /* Set bauds, 8n1            */
{
    outp (uart_port + 2, 0x00);                 /* disable FIFOs on 16550+  */
    outp (uart_port + 4, 0x00);
    inp (uart_port + 5);                        /* clear errors             */
    inp (uart_port);                            /* clear incoming data      */
    inp (uart_port + 7);                        /* clear modem status       */
    outp (uart_port + 3, 0x80);                 /* set divisor mode         */
    outpw (uart_port, BAUDRATE);                /* set bauds                */
    outp (uart_port + 3, 0x03);                 /* set 8n1                  */
    outp (uart_port + 1, mode ? 0x01 : 0x00);   /* interrupt on RxRDY       */
    outp (uart_port + 4, mode ? 0x0B : 0x00);   /* DTR = 1, RTS = 1         */
}

int uart_get_LSR (void)
{
    return (inp (uart_port + 5));
}

void uart_send (unsigned data)
{
    int     i;

    for (i = 0 ; i < 32 ; i++) inp (uart_port + 7);
    while (!(uart_get_LSR () & 0x20));
    outp (uart_port, data);
}

/* ������������������������������������������������������������������������� */

void (_interrupt _far *OLD) (void);

void _interrupt _far IRQ_HANDLER (void)
{
    inp (uart_port + 5);
    inp (uart_port);
    outp (0x20, 0x20);
}

/* ������������������������������������������������������������������������� */

void textmode (void)
{
    union REGS  regs;

    regs.x.ax = 0x0003;
    int86 (0x10, &regs, &regs);
}

unsigned key (void)
{
    union REGS  regs;

    regs.h.ah = 0x00;
    int86 (0x16, &regs, &regs);
    return (regs.x.ax);
}

int main (int argc, char *argv[])
{
    unsigned    i;
    char        c;

    uart_port = IRQ = 0;
    for (i = 1 ; i < argc ; i++) {
        if ((argv [i][0] == '-') || (argv [i][0] == '/')) {
            c = tolower (argv [i][1]);
            if (c == 'c') uart_port = (argv [i][2] - '1') & 0x03;
            else if (c == 'i') IRQ = (argv [i][2] - '0') & 0x07;
            else {
                printf ("Link to MFX system ADSP-2181\n\n"
                        "   Usage:  %s [options]\n\n"
                        "   Options:\n"
                        "            -c#    - use COM #\n"
                        "            -i#    - use IRQ #\n"
                        "\n", argv [0]);
                exit (1);
            }
        }
    }

    detect_COMs ();
    uart_port = comx [uart_port];
    if (!IRQ) {
        if (uart_port == 0x3F8) IRQ = 4;
        else if (uart_port == 0x2F8) IRQ = 3;
        else if (uart_port == 0x3E8) IRQ = 4;
        else if (uart_port == 0x2E8) IRQ = 3;
        else {
            printf ("COM port not installed\n");
            exit (0);
        }
    }
    bit_IRQ = (1 << IRQ);

    textmode ();

    printf ("\t\t*** MFX remote control (C) VladiTX ***\n"
            "\n"
            "   <-> / <+> - Filter off / on\n"
            "\n"
            "   <[> / <]> - Chorus off / on\n"
            "\n"
            "   <0> - Reverb off\n"
            "   <1> - Hall reverb\n"
            "   <2> - Room reverb\n"
            "   <3> - Huge reverb\n"
            "   <4> - Metallic reverb\n"
            "   <5> - Distant echo\n"
            "   <6> - Short echo\n"
            "   <7> - Long echo\n"
            "   <8> - Shroeder\n"
            "\n"
            "   <F1> .. <F10> - Guitar gain\n"
            "\n"
            "   <Shift> + <F1> .. <F10> - Synthesizer gain\n"
            "\n"
            "   <Q,W,E,R,T> - play songs 1..5\n"
            "\n"
            "   <V> - summon the author\n");

    outp (0x21, inp (0x21) | bit_IRQ);
    OLD = _dos_getvect (0x08 + IRQ);
    _dos_setvect (0x08 + IRQ, IRQ_HANDLER);
    uart_init (1);

    outp (0x21, inp (0x21) & ~bit_IRQ);

    for ( ; ; ) {
        if (kbhit ()) {
            c = i = key ();
            c = toupper (c);
            if (c == 0x1B) break;
            else if (c == 'V') spy ();
            else if (c == '-') uart_send (CMD_FILTER_OFF);
            else if ((c == '+') || (c == '=')) uart_send (CMD_FILTER_ON);
            else if (c == '[') uart_send (CMD_CHORUS_OFF);
            else if (c == ']') uart_send (CMD_CHORUS_ON);
            else if ((c >= '0') && (c <= '8'))
                uart_send (c - '0' + CMD_REVERB);
            else if ((i >= 0x3B00) && (i <= 0x4400))
                uart_send (((i - 0x3B00) >> 8) + CMD_GUITAR);
            else if ((i >= 0x5400) && (i <= 0x5D00))
                uart_send (((i - 0x5400) >> 8) + CMD_SYNTH);
            else if (c == 'Q') uart_send (CMD_SONG_1);
            else if (c == 'W') uart_send (CMD_SONG_2);
            else if (c == 'E') uart_send (CMD_SONG_3);
            else if (c == 'R') uart_send (CMD_SONG_4);
            else if (c == 'T') uart_send (CMD_SONG_5);
        }
    }

    outp (0x21, inp (0x21) | bit_IRQ);
    uart_init (0);
    _dos_setvect (0x08 + IRQ, OLD);

    textmode ();
    return (0);
}
