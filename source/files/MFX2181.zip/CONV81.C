/****************************************************************************/
/*                         Convert MOD file to M81                          */
/****************************************************************************/

/****************************************************************************/
/*                      (C)oded by VladiTX, 1998                            */
/****************************************************************************/

#include    <stdio.h>
#include    <string.h>
#include    <dos.h>
#include    <io.h>
#include    <fcntl.h>

#include    "m81def.h"

#define DBG
// #define DUMP

/* ------------------------------------------------------------------------ */

typedef unsigned char   byte;
typedef unsigned int    word;
typedef unsigned long   dword;

/* ------------------------------------------------------------------------ */

/* List of internal effects' #:                     */
/* 0x00 - no effect         0x08 - sample offset    */
/* 0x01 - set speed         0x09 - port. up         */
/* 0x02 - set tempo         0x0A - port. dn         */
/* 0x03 - jump to order     0x0B - fine port. up    */
/* 0x04 - break pattern     0x0C - fine port. dn    */
/* 0x05 - set volume        0x0D - port. to note    */
/* 0x06 - volume slide      0x0E - port. to + vol   */
/* 0x07 - fine vol. slide   0x0F - arpeggio         */

/* ------------------------------------------------------------------------ */

word ftune2hz [] = {8372,8433,8494,8555,8617,8680,8743,8806,
                    7902,7959,8017,8075,8134,8193,8252,8312};

/* ------------------------------------------------------------------------ */

typedef struct {
    dword   beg;
    dword   end;
    dword   loopbeg;
    word    defvol;
    word    tuning;
} INSTRUC;

typedef struct {
    byte    ins;
    byte    note;
    byte    eff;
    byte    prm;
} ENTRY;

/* ------------------------------------------------------------------------ */

INSTRUC instr;
word    order [MAX_ORDER];
ENTRY   ipatt [MAX_CHANNELS * MAX_ROWS];

byte    maycorrupt,corrupted;

word    sampleLen   [MAX_INSTRUMENT];
word    sampleLoopB [MAX_INSTRUMENT];
word    sampleLoopE [MAX_INSTRUMENT];
word    sampleVol   [MAX_INSTRUMENT];
word    sampleC4    [MAX_INSTRUMENT];

/* ------------------------------------------------------------------------ */

void usr_fatal (char *err)
{
    printf ("\nError: %s", err);
    exit (2);
}

void usr_fopen (char *its_name, int *fhandle, word mode)
{
    if (_dos_open (its_name, mode, fhandle))
        usr_fatal ("cannot open file");
    maycorrupt = corrupted = 0;
}

void usr_fcreat (char *its_name, int *fhandle, word mode)
{
    if (_dos_creat (its_name, mode, fhandle))
        usr_fatal ("cannot create file");
}

void usr_fread (int fhandle, word howmuch, void far *where)
{
    word    actread;

    if (_dos_read (fhandle, where, howmuch, &actread))
        usr_fatal ("cannot read from file");
    if (actread != howmuch) {
        if (!maycorrupt) usr_fatal ("unexpected end of file");
        else corrupted = 1;
    }
}

void usr_fwrite (int fhandle, word howmuch, void far *where)
{
    word    actwritten;

    if (_dos_write (fhandle, where, howmuch, &actwritten))
        usr_fatal ("cannot write to file");
    if (actwritten != howmuch)
        usr_fatal ("probably out of disk space");
}

void usr_fseek (int fhandle, dword where)
{
    if (lseek (fhandle, where, SEEK_SET) == -1L)
        usr_fatal ("cannot seek in file");
}

void usr_fcopy (int fdest, int fsrc, word howmuch)
{
    byte    buff [2048];
    word    quo,rem;

    if (howmuch) {
        quo = howmuch / sizeof (buff);
        rem = howmuch % sizeof (buff);
        for ( ; quo ; quo--) {
            usr_fread (fsrc, sizeof (buff), buff);
            usr_fwrite (fdest, sizeof (buff), buff);
        }
        if (rem) {
            usr_fread (fsrc, rem, buff);
            usr_fwrite (fdest, rem, buff);
        }
    }
}

void usr_fclose (int fhandle)
{
    if (_dos_close (fhandle))
        usr_fatal ("cannot close file");
}

int equal32 (char *s1, char *s2)
{
    return ((*(dword *)s1 == *(dword *)s2) ? 1 : 0);
}

void rev16 (word *x)
{
    byte    b1,b2;

    b1 = *((byte *) x);
    b2 = *((byte *) x + 1);
    *((byte *) x) = b2;
    *((byte *) x + 1) = b1;
}

void rev32 (dword *x)
{
    byte    b1,b2,b3,b4;

    b1 = *((byte *) x);
    b2 = *((byte *) x + 1);
    b3 = *((byte *) x + 2);
    b4 = *((byte *) x + 3);
    *((byte *) x) = b4;
    *((byte *) x + 1) = b3;
    *((byte *) x + 2) = b2;
    *((byte *) x + 3) = b1;
}

word mod_std [60] = {1712,1616,1525,1440,1357,1281,1209,1141,1077,1017,961,907,
                     856,808,762,720,678,640,604,570,538,508,480,453,
                     428,404,381,360,339,320,302,285,269,254,240,226,
                     214,202,190,180,170,160,151,143,135,127,120,113,
                     107,101,95,90,85,80,76,71,67,64,60,57};

byte mod2note (word p)
{
    byte i;

    for (i = 0 ; i < 60 ; i++)
        if (p >= mod_std [i]) return (i + 24);
    return (48);
}

/* ------------------------------------------------------------------------ */

/* returns: 0 - ok                                              */
/*          1 - module is possibly corrupted, but who knows ... */

int convert_MOD (char *themod, char *the81)
{
    int     modfile,m81file;
    word    i,k;
    struct MODsample {
        byte name [22];
        word len;
        byte fine;
        byte defvol;
        word loopb;
        word loope;
    } wrksam;
    char    songtitle [20];
    byte    id[4];
    byte    border [128];
    word    n_channels,orderlen,n_modsam,pattsiz,mod_patterns;
    dword   offset;
    byte    tpatt [64 * MAX_CHANNELS * 4],teff,tprm;
    ENTRY   *ipattptr;
    word    period;

/* - determine MOD type - */
    usr_fopen (themod, &modfile, O_RDONLY);
    usr_fcreat (the81, &m81file, 0);
    usr_fseek (modfile, 0x0438);
    usr_fread (modfile, 4, id);
    usr_fseek (modfile, 0);
    if (equal32 (id, "M.K.") || equal32 (id, "FLT4")) {
        n_channels = 4;
        n_modsam = 31;
    } else if (equal32 (id,"6CHN")) {
        n_channels = 6;
        n_modsam = 31;
    } else if (equal32 (id,"8CHN")) {
        n_channels = 8;
        n_modsam = 31;
    } else if (equal32 (id,"16CH")) {
        n_channels = 16;
        n_modsam = 31;
    } else if (equal32 (id,"32CH")) {
        n_channels = 32;
        n_modsam = 31;
    } else {
        n_channels = 4;
        n_modsam = 15;
    }
    if (n_channels != MAX_CHANNELS)
        usr_fatal ("invalid number of channels");
    pattsiz = n_channels * 64 * 4;
#ifdef DBG
    printf ("module id is <%-.4s>\n", id);
#endif

/* - get the module title - */
    usr_fread (modfile, 20, songtitle);
#ifdef DBG
    printf ("module title is <%-.20s>\n", songtitle);
#endif

/* - get all samples info - */
    for (i = 0 ; i < n_modsam ; i++) {
        usr_fread (modfile, sizeof (wrksam), &wrksam);
        rev16 (&wrksam.len);
        if (wrksam.len > 0x7fff)
            usr_fatal ("sample over 64k");
        wrksam.len <<= 1;
        rev16 (&wrksam.loopb);  wrksam.loopb <<= 1;
        rev16 (&wrksam.loope);  wrksam.loope <<= 1;
#ifdef DBG
        printf ("#%02x <%-.22s> len=%u", i, wrksam.name, wrksam.len);
        printf (" fine=%X vol=%u", wrksam.fine, wrksam.defvol);
        printf (" loopb=%u loope=%u\n", wrksam.loopb, wrksam.loope);
#endif
        if (wrksam.len > 2) {
            sampleLen [i] = wrksam.len;
            if (wrksam.loope > 2) {
                wrksam.loope += wrksam.loopb;
                if (wrksam.loope > wrksam.len) wrksam.loope = wrksam.len;
                if (wrksam.loopb >= wrksam.len) wrksam.loopb = wrksam.loope = 0;
                if (wrksam.loope <= wrksam.loopb) wrksam.loope = wrksam.len;      /* another stupid err */
            } else wrksam.loopb = wrksam.loope = 0;
            sampleLoopB [i] = wrksam.loopb;
            sampleLoopE [i] = wrksam.loope;
            if (wrksam.defvol > 64) wrksam.defvol = 64;
            sampleVol [i] = wrksam.defvol;
            wrksam.fine &= 0x0F;
            sampleC4 [i] = ftune2hz [wrksam.fine];
#ifdef DBG
            printf ("-> [%u] L=%u LB=%u LE=%u V=%u C4=%u\n", i,
            sampleLen [i], sampleLoopB [i], sampleLoopE [i],
            sampleVol [i], sampleC4 [i]);
#endif
        }
    }

/* - get order's length - */
    usr_fread (modfile, 2, &orderlen);
    orderlen &= 0xFF;
#ifdef DBG
    printf ("order length is %u\n", orderlen);
#endif

/* - get the order and scan for highest pattern - */
    memset (order, 0xFF, sizeof (order));
    usr_fread (modfile, 128, border);
    for (i = mod_patterns = 0 ; i < 128 ; i++) {
        if (border [i] > mod_patterns) mod_patterns = border [i];
        if (i < orderlen) order [i] = border [i];
        rev16 (&order [i]);
    }
    mod_patterns++;
#ifdef DBG
    printf ("patterns count is %u\n", mod_patterns);
#endif

/* - get MOD id if exists - */
    if (n_modsam != 15) usr_fread (modfile, 4, id);

/* - create header: instruments & order - */
    offset = MAX_INSTRUMENT * sizeof (INSTRUC) + \
             sizeof (order) + \
             (dword) mod_patterns * sizeof (ipatt);
#ifdef DBG
    printf ("samples block starts at %08lx\n", offset);
#endif
    for (i = 0 ; i < MAX_INSTRUMENT ; i++) {
#ifdef DBG
        printf ("sample %02u located at %08lx\n", i, offset);
#endif
        instr.beg = offset;
        if (sampleLoopE [i]) {
            instr.loopbeg = offset + sampleLoopB [i];
            instr.end = offset + sampleLoopE [i];
        } else {
            instr.loopbeg = 0;
            instr.end = offset + sampleLen [i];
        }
        offset += sampleLen [i];
        instr.defvol = sampleVol [i];
        instr.tuning = sampleC4 [i];
        rev32 (&instr.beg);
        rev32 (&instr.end);
        rev32 (&instr.loopbeg);
        rev16 (&instr.defvol);
        rev16 (&instr.tuning);
        usr_fwrite (m81file, sizeof (instr), &instr);
    }
    usr_fwrite (m81file, sizeof (order), order);

/* - get patterns and convert them - */
    for (i = 0 ; i < mod_patterns ; i++) {
        usr_fread (modfile, pattsiz, tpatt);
        for (k = 0, ipattptr = ipatt ; k < pattsiz ; k += 4, ipattptr++) {
            ipattptr -> ins = ((tpatt [k] & 0x10) | (tpatt [k+2] >> 4));
            period = ((tpatt [k] & 0x0F) << 8) | tpatt [k+1];
            if (period) ipattptr -> note = mod2note (period) + 1;
            else ipattptr -> note = 0;
            teff = tpatt [k+2] & 0x0F;
            tprm = tpatt [k+3];
            ipattptr -> eff = ipattptr -> prm = 0;      /* no effect */
            switch (teff) {
                case 0x00:  if (tprm) {                 /* Arpeggio */
                                ipattptr -> eff = 0x0F;
                                ipattptr -> prm = tprm;
                            }
                            break;
                case 0x01:  if (tprm) {                 /* Portamento Up */
                                ipattptr -> eff = 0x09;
                                ipattptr -> prm = tprm;
                            }
                            break;
                case 0x02:  if (tprm) {                 /* Portamento Down */
                                ipattptr -> eff = 0x0A;
                                ipattptr -> prm = tprm;
                            }
                            break;
                case 0x03:  ipattptr -> eff = 0x0D;     /* Portamento To */
                            ipattptr -> prm = tprm;
                            break;
                case 0x04:  break;
                case 0x05:  ipattptr -> eff = 0x0E;     /* PortaTo+Vol */
                            ipattptr -> prm = (tprm >> 4) - (tprm & 0x0F);
                            break;
                case 0x06:  break;
                case 0x07:  break;
                case 0x08:  break;
                case 0x09:  ipattptr -> eff = 0x08;     /* Sample Offset */
                            ipattptr -> prm = tprm;
                            break;
                case 0x0A:  ipattptr -> eff = 0x06;     /* SldVol */
                            ipattptr -> prm = (tprm >> 4) - (tprm & 0x0F);
                            break;
                case 0x0B:  if (tprm < orderlen) {      /* JMP */
                                ipattptr -> eff = 0x03;
                                ipattptr -> prm = tprm;
                            }
                            break;
                case 0x0C:  ipattptr -> eff = 0x05;     /* Set Volume */
                            if ((ipattptr -> prm = tprm) > 64)
                                ipattptr -> prm = 64;
                            break;
                case 0x0D:  ipattptr -> eff = 0x04;     /* BRK */
                            ipattptr -> prm = (tprm >> 4) * 10 + (tprm & 0x0F);
                            if (ipattptr -> prm > 63) ipattptr -> prm = 0;
                            break;
                case 0x0E:  teff = tprm >> 4;           /* Extended effects */
                            tprm &= 0x0F;
                            switch (teff) {
                                case 0x0:   break;
                                case 0x1:   if (tprm) {     /* Fine PortaUp */
                                                ipattptr -> eff = 0x0B;
                                                ipattptr -> prm = tprm;
                                            }
                                            break;
                                case 0x2:   if (tprm) {     /* Fine PortaDn */
                                                ipattptr -> eff = 0x0C;
                                                ipattptr -> prm = tprm;
                                            }
                                            break;
                                case 0x3:   break;
                                case 0x4:   break;
                                case 0x5:   break;
                                case 0x6:   break;
                                case 0x7:   break;
                                case 0x8:   break;
                                case 0x9:   break;
                                case 0xA:   if (tprm) {     /* Fine Vol Up */
                                                ipattptr -> eff = 0x07;
                                                ipattptr -> prm = tprm;
                                            }
                                            break;
                                case 0xB:   if (tprm) {     /* Fine Vol Dn */
                                                ipattptr -> eff = 0x07;
                                                ipattptr -> prm = -tprm;
                                            }
                                            break;
                                case 0xC:   break;
                                case 0xD:   break;
                                case 0xE:   break;
                                case 0xF:   break;
                            }
                            break;
                case 0x0F:  ipattptr -> prm = tprm;     /* Set speed */
                            if (!tprm)
                                ipattptr -> eff = 0x04;     /* -break */
                            else if (tprm <= 32)
                                ipattptr -> eff = 0x01;     /* -set ticks */
                            else ipattptr -> eff = 0x02;    /* -set BPM */
                            break;
            }
        }
#ifdef DUMP
        printf ("-- DUMP --\n");
        for (k = 0, ipattptr = ipatt ; k < (sizeof (ipatt) / sizeof (ENTRY)) ; k++, ipattptr++)
            printf ("%08lx ", *(dword *)ipattptr);
        printf ("\n");
#endif
        usr_fwrite (m81file, sizeof (ipatt), ipatt);
    }

/* - get samples data - */
    maycorrupt=1;
    for (i = 0 ; i < n_modsam ; i++) {
        usr_fcopy (m81file, modfile, sampleLen [i]);
    }

/* - that's all folks - */
    usr_fclose (modfile);
    usr_fclose (m81file);
    return (corrupted);
}

/* ------------------------------------------------------------------------ */

int main (int argc, char *argv[])
{
    if (argc != 3) {
        printf ("MOD to M81 converter (C) VladiTX, All rights re-reversed, etc.\n\n"
                "\tUsage: %s <modfile> <m81file>\n", argv [0]);
        exit (1);
    }

    if (convert_MOD (argv [1], argv [2]))
        printf ("Warning: module possibly corrupted ...\n");

    return (0);
}
