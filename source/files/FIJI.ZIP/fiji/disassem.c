/*
	File:		Disassemble56k.c

	Contains:	This file contains functions to disassemble
				DSP 56k opcodes.

	Written by:	Stephen A. Davis, sadman@ccrma.stanford.edu

 	Copyright:	� 1994-1995 by Stephen A. Davis

	This program is free software; you can redistribute it and/or modify
	it under the terms of the GNU General Public License as published by
	the Free Software Foundation; either version 2 of the License, or
	(at your option) any later version.

	This program is distributed in the hope that it will be useful,
	but WITHOUT ANY WARRANTY; without even the implied warranty of
	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
	GNU General Public License for more details.

	You should have received a copy of the GNU General Public
	along with this program; if not, write to the Free Software
	Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
*/
	
#include "util56k.h"
#include <stdio.h>
#include <string.h>


/*
	---------------------------------------------------------------------------
	private function declarations
	---------------------------------------------------------------------------
*/
static int DecodeParallel(unsigned long opcodeWord, unsigned long extensionWord);
static int p_mults(unsigned long opcodeWord);
static int p_non_mults(unsigned long opcodeWord);		
static int p_move(unsigned long opcodeWord, unsigned long extensionWord);

static int DecodeNonParallel(unsigned long opcodeWord, unsigned long extensionWord);
static int np_jumps(unsigned long opcodeWord, unsigned long extensionWord);	
static int np_bit(unsigned long opcodeWord, unsigned long extensionWord);
static int np_movep(unsigned long opcodeWord, unsigned long extensionWord);
static int np_movem(unsigned long opcodeWord, unsigned long extensionWord);
static int np_loops(unsigned long opcodeWord, unsigned long extensionWord);
static int np_movec(unsigned long opcodeWord, unsigned long extensionWord);
static int np_xfer(unsigned long opcodeWord, unsigned long extensionWord);	
static int np_alu(unsigned long opcodeWord, unsigned long extensionWord);
static int np_unique(unsigned long opcodeWord, unsigned long extensionWord);

static int DecodeEffectiveAddress(int memSpace, unsigned char effAddrCode,
								unsigned long extensionWord, char *outAddrBuf, int src);	
static int DecodeRegister(unsigned char regCode, char *outRegBuf);
static int DecodeRegisterALU(unsigned char ddddd, char *outRegBuf);

/*
	---------------------------------------------------------------------------
	statics and globals
	---------------------------------------------------------------------------
*/
extern int	gDevice;					/* Which 56K chip -> 56001,56002,56004,etc. */
extern int	gChipRev;					/* Revision mask of 56001 -> >0 = Rev. C or beyond */

static char	opcode_buf[8];				/* buffer for opcode mnemonic */
static char	operand_buf[40];			/* buffer for opcode operand(s) */
static char	pmove_buf[60];				/* buffer for parallel move portion */
static char	ea_buf[40];					/* holds decoded effective address field */
static char	reg_buf[4];					/* holds register decoding */
static char	temp_buf[60];				/* scratch space _only_ valid within a function */

static char	*d_decode[] = {"a", "b"};	/* decoding matrices */
static char	*e_decode[] = {"x0", "x1"};
static char	*k_decode[] = {"y0", "y1"};
static char	*DD_decode[] = {"x0", "x1", "y0", "y1"};
static char	*ee_decode[] = {"x0", "x1", "a", "b"};
static char	*ff_decode[] = {"y0", "y1", "a", "b"};
static char	*DDD_decode[] = {"a0","b0","a2","b2","a1","b1","a","b"};
static char	*LLL_decode[] = {"a10","b10","x","y","a","b","ab","ba"};
static char	*GGG_decode[] = {"\0","sr","omr","sp","ssh","ssl","la","lc"};
static char	*CCCC_decode[] = {"cc","ge","ne","pl","nn","ec","lc","gt","cs","lt","eq","mi","nr","es","ls","le"};

/*
	---------------------------------------------------------------------------
	defines
	---------------------------------------------------------------------------
*/
#define PMOVE_NOP	((unsigned long)0x200000)
#define ENDDO	((unsigned long)0x8C)	/* unique instructions */
#define STOP	((unsigned long)0x87)
#define WAIT	((unsigned long)0x86)
#define RESET	((unsigned long)0x84)
#define RTS		((unsigned long)0x0C)
#define DECA	((unsigned long)0x0A)
#define DECB	((unsigned long)0x0B)
#define INCA	((unsigned long)0x08)
#define INCB	((unsigned long)0x09)
#define SWI		((unsigned long)0x06)
#define ILLEGAL	((unsigned long)0x05)
#define RTI		((unsigned long)0x04)
#define DEBUG	((unsigned long)0x0200)
#define DEBUGCC	((unsigned long)0x0300)

#define kParallelType		((int)0)
#define kNonParallelType	((int)1)

#define kOpcodePos			0			/* positions used for formatting the output */
#define kOperandPos			8			/* RBJ - reduced this from 10   */
#define kPMovePos			20			/* RBJ - reduced this from 24   */
#define kMinSpacing			2			/* RBJ - reduced this from 5    */
#define kPMoveSpacing		14			/* RBJ - increased this from 12 */

/*
	===========================================================================
	Dissasemble
	===========================================================================
	Disassemble a one or two word 56k opcode
		'opcodeWord' is the first word of the instruction.
		'extensionWord' is the second word of the instruction (if necessary)
		'outCodeBuf' is the return buffer for the instruction string.

	Returns:
		-1 - bogus input arguments and general bad stuff
		0 - illegal opcode, return buf contains "DC $xxxxxx"
		1 - one word consumed for the disassembly
		2 - both words consumed for the disassembly
*/
int Disassemble(unsigned long opcodeWord, unsigned long extensionWord, char *outCodeBuf)
	{
	unsigned long	temp;
	int				theErr;
	short			decodeType;
	char			*bp;
	int				len, i;
	
	/* make sure outCodeBuf is a legal buffer */
	if (outCodeBuf == NULL)
		return -1;
	
	/* clear out the internal buffers */
	reg_buf[0] = '\0';
	ea_buf[0] = '\0';
	opcode_buf[0] = '\0';
	operand_buf[0] = '\0';
	pmove_buf[0] = '\0';
	
	/* check for NOP's */
	opcodeWord &= 0x00FFFFFFul;			/* mask off lower 24 bits */
	if (opcodeWord == 0ul)
		{
		strcpy(outCodeBuf, "nop");
		return 1;
		}
	
	/*
		Bits 23 - 20 encode parallel or non-parallel move:
		- 23..20 = [xxxx] where one or more of 'x' is set -> parallel move instruction
		- 23..20 = [0000] -> non-parallel move instruction
		- 23..16 = [0000:100x] & 14 = [0] -> parallel move Class II (see A-317 of family manual)
	*/
	temp = (opcodeWord & 0x0F0000ul);
	
	/* check for normal parallel move instructions */
	if (opcodeWord & 0xF00000ul)
		{
		/* normal parallel move instruction */
		theErr = DecodeParallel(opcodeWord, extensionWord);
		decodeType = kParallelType;
		}
	/* check for special parallel move instructions -- 56001 Rev. C and up */
	    else if (((gChipRev > REVB) || (gDevice > DSP56001))
			&& ((temp == 0x080000ul) || (temp == 0x090000ul))
			&& !(opcodeWord & 0x004000ul))	
		{	
		/* Class II parallel move instruction */
		theErr = DecodeParallel(opcodeWord, extensionWord);
		decodeType = kParallelType;
		}
	    else
		{	/* non-parallel move instruction */
		theErr = DecodeNonParallel(opcodeWord, extensionWord);
		decodeType = kNonParallelType;
		}
		
	/* check result of decoding */
	if (theErr <= 0)
		{
		sprintf(outCodeBuf, "dc\t$%6.6lX", opcodeWord);
		}
	    else
		{	
		/* decoded instruction was cool, build output */
		/* stick the opcode in the output buffer */
		sprintf(outCodeBuf, "%s", opcode_buf);
			
		/* only include operand field if it's non-empty */
		if (operand_buf[0] != '\0')
			{
			len = strlen(outCodeBuf);			/* add spaces for formatting */
			bp = outCodeBuf + len;
			temp = kOperandPos;
			if ((kOperandPos - len) < kMinSpacing)
				{
				/* if the opcode field is too close to the operand position, add spaces */
				len = 0;
				temp = kMinSpacing;
				}
			for (i = len; i < temp; i++)
				*bp++ = ' ';
			*bp = '\0';
			strcat(outCodeBuf, operand_buf);	/* strcat the operand field */
			}
		
		/* only include pmove field if it was used and non-empty */
		if ((decodeType == kParallelType) && (pmove_buf[0] != '\0'))
			{			
			len = strlen(outCodeBuf);			/* add spaces for formatting */
			bp = outCodeBuf + len;
			temp = kPMovePos;
			if ((kPMovePos - len) < kMinSpacing)
				{
				/* if the operand field is past the base Pmove position, add spaces */
				len = 0;
				temp = kMinSpacing;
				}
			for (i = len; i < temp; i++)
				*bp++ = ' ';
			*bp = '\0';			
			strcat(outCodeBuf, pmove_buf);		/* strcat the pmove field */
			}		
		}
	
	return theErr;
	}				

/*
	---------------------------------------------------------------------------
	DecodeParallel
	---------------------------------------------------------------------------
	break down parallel instruction into multiply or non-multiply group (or NOP)
*/
int DecodeParallel(unsigned long opcodeWord, unsigned long extensionWord)
	{
	int		err;
	
	#ifdef _DEBUG
	fprintf(stderr, "parallel instruction\n");
	#endif
	
	/* if bits [7..0] == 0, it's a move instruction only */
	if ( !(opcodeWord & 0x0FFul) )
		{
		/* check for parallel move NOP */
		if ((opcodeWord & 0xFFFF00L) == PMOVE_NOP)
			{
			sprintf(opcode_buf, "nop");		/* really a DC if opcode is 0 as well??? */
			operand_buf[0] = '\0';
			pmove_buf[0] = '\0';			
			return 1;
			}
		  else
			{
			sprintf(opcode_buf, "move");	/* ALU NOP with a parallel move */
			operand_buf[0] = '\0';
			err = 1;
			}
		}
	  else if (opcodeWord & 0x80L)			/* bit 7 indicates a multiply instruction */
		err = p_mults(opcodeWord);
	  else
		err = p_non_mults(opcodeWord);		/* else it's a non-multiply instruction */
	
	/* bail if opcode decoding failed... */
	if (err <= 0)
		return err;
	
	/* decode parallel move portion */
	err = p_move(opcodeWord, extensionWord);
	
	return err;
	}

/*
	---------------------------------------------------------------------------
	p_move
	---------------------------------------------------------------------------
	decode the parallel move portion of an instruction
*/
int p_move(unsigned long opcodeWord, unsigned long extensionWord)
	{
	/* 	
		The parallel move portion of an instruction is located
		in bits 23..8 of the instruction opcode. See pp. A-316 & 317.
		
		Bits 23..20 decode the type:
			[1xxx] -> X: Y: move
			[01xx] -> X: or	Y: move
			[0100] -> L: move
			[001x] -> I:,R:,U:,NOP
				- 23..18 [001000] -> R:,U:, or NOP
			[0001] -> Class I move, R:Y or X:R
			[0000] & 14 = [0] -> Class II move (only with [100x] in 19..16)
		Note: 23..8 = [0x2000] -> pmove NOP
		
		Note: in X: Y: encoding, various lengths are used for the
			ea encoding. For both, the result is not the same
			as Table A-26.
			- For X:, it's MMRRR but:	(M2 implied)
				(Rn)+Nn =	(0)01rrr
				(Rn)-	=	(0)10rrr
				(Rn)+	=	(0)11rrr
				(Rn)	=	(1)00rrr	where rrr = R0-R7
			- Fixed by setting the M2 implied bit when passing ea
				to the DecodeEffectiveAddress() routine.
			- For Y:, it's mmrr where rr is a 2-bit encoding in
			the opposite bank from the X: encoding RRR.
				- mm is the same as MM above.
	*/
	
	int				err = 1;
	unsigned char	ea;						/* ea field: MMMRRR coding, always LS 6 bits */
	unsigned short	imm = 0;
	unsigned char	ddddd = 0, LLL = 0;		/* register encodings */
	unsigned short	rrr = 0;
	unsigned char	temp;
	int				memspace = eNullSpace;	/* default which will fail if not set */
	/* int				upperBank;	RBJ removed */			/* bank of R0-R3 or R4-R7 (def = R0-R3) */
	int				src;					/* is the ea field the src or dest? */
	int				padlen, len, i;			/* RBJ - added padlen */
	double			imm_float;				/* added by RBJ */
	
	#ifdef _DEBUG
	fprintf(stderr, "move calculation\n");
	#endif
	
	opcodeWord >>= 8;						/* shift move portion into lowest 16 bits */
	opcodeWord &= 0x00FFFFul;				/* just to make sure we have no errant bits set */
	ea = (unsigned char)(opcodeWord & 0x3F);
	
	/* NOP check */
	if (opcodeWord == 0x2000ul)				/* PMOVE_NOP >> 8 */
		{
		sprintf(pmove_buf, "\0");			/* no parallel move */
		return 1;
		}
	
	/* X: Y: check -- [1wmm eeff WrrM MRRR] */
	if (opcodeWord & 0x8000ul)
		{
		/* X: Y: move, p. A-202 */
		
		/* do X: portion first */
		temp = (unsigned char)((opcodeWord & 0x0400) >> 10);
		/*  RBJ - removed in lieu of quick fix below
		if ((opcodeWord & 0x0018) == 0ul)
			ea |= 0x20;
		*/
		ea -= 0x0008ul;		/* RBJ - added as quick and simple way to fix kludge in MMRRR encoding */
		ea &= 0x001Ful;		/* only using MMRRR for X: portion */
		ea += 0x0008ul;		/* RBJ - added as quick and simple way to fix kludge in MMRRR encoding */
			/* fix kludge in MMRRR encoding, see above */

		src = (opcodeWord & 0x0080ul) ? kSrcOp : kDstOp;
		err = DecodeEffectiveAddress(eXSpace, ea, extensionWord, ea_buf, src);
		if (err <= 0)
			return err;
		if (opcodeWord & 0x0800ul)
			sprintf(reg_buf, "%s", d_decode[temp]);			/* A or B */
		  else
			sprintf(reg_buf, "x%hi", (unsigned short)temp);	/* X0 or X1 */
		if (src == kSrcOp)
			sprintf(pmove_buf, "%s,%s", ea_buf, reg_buf);
		  else
			sprintf(pmove_buf, "%s,%s", reg_buf, ea_buf);
		/* RBJ - removed and fixed below
		if (opcodeWord & 0x0004ul)
			upperBank = 1;
		*/
		
		/* now do Y: portion */
		temp = (unsigned char)((opcodeWord & 0x0100ul) >> 8);
		ea = (unsigned char)(((opcodeWord & 0x0060ul) >> 5) | ((opcodeWord &0x3000ul) >> 9));
		
		/*  RBJ - removed in lieu of quick fix below
		if ((opcodeWord & 0x3000ul) == 0ul)
			ea |= 0x20;
		*/			
		ea -= 0x0008ul;		/* RBJ - added as quick and simple way to fix kludge in MMRRR encoding */
		ea &= 0x001Ful;		/* only using MMRRR for X: portion */
		ea += 0x0008ul;		/* RBJ - added as quick and simple way to fix kludge in MMRRR encoding */
			/* fix kludge in mmrr encoding, see above */
			
		/* RBJ - removed and fixed below
		if ( !upperBank )
			ea |= 0x04;
		*/						/* Y: move must be in opposite Rn bank from X: */
		ea |= (~opcodeWord) & 0x0004ul;			/* RBJ - simplified this */
		src = (opcodeWord & 0x4000ul) ? kSrcOp : kDstOp;
		err = DecodeEffectiveAddress(eYSpace, ea, extensionWord, ea_buf, src);
		if (err <= 0)
			return err;
		if (opcodeWord & 0x0200ul)					/* RBJ - changed '0800' to '0200ul' */
			sprintf(reg_buf, "%s", d_decode[temp]);			/* A or B */
		  else
			sprintf(reg_buf, "y%hi", (unsigned short)temp);	/* Y0 or Y1 */
		
		/* add spaces for formatting */
		len = strlen(pmove_buf);
		if ((kPMoveSpacing - len) < kMinSpacing)
			padlen = len + kMinSpacing;
		  else
			padlen = kPMoveSpacing;
		for (i = len; i < padlen; i++)
			pmove_buf[i] = ' ';
		pmove_buf[i] = '\0';
		
		/* add the Y: portion to the buffer */
		if (src == kSrcOp)
			sprintf(temp_buf, "%s,%s", ea_buf, reg_buf);
		  else
			sprintf(temp_buf, "%s,%s", reg_buf, ea_buf);
		strcat(pmove_buf, temp_buf);
		return err;
		}
	
	/* R:, U:, or I: check */
	if ((opcodeWord & 0xE000ul) == 0x2000ul)
		{
		/* either R: or U: or I: */
		if ((opcodeWord & 0xFFE0ul) == 0x2040ul)
			{
			/* U: address register update, p.A-172 -- [0010 0000 010M MRRR] */
			rrr = (unsigned short)(opcodeWord & 0x7ul);
			switch(opcodeWord & 0x18ul)
				{
				case 0x00:
					sprintf(pmove_buf, "(r%hi)-n%hi", rrr, rrr);
					break;
				case 0x08:
					sprintf(pmove_buf, "(r%hi)+n%hi", rrr, rrr);
					break;
				case 0x10:
					sprintf(pmove_buf, "(r%hi)-", rrr);
					break;
				case 0x18:
					sprintf(pmove_buf, "(r%hi)+", rrr);
					break;
				default:
					err = 0;
					break;
				}
			return err;
			}
		  else if ((opcodeWord & 0xFC00ul) == 0x2000ul)
			{
			/* R: register to register, p.A-168 -- [0010 00ee eeed dddd] */
			ddddd = (opcodeWord & 0x3E0ul) >> 5;	/* actually source 'eeeee' */
			err = DecodeRegisterALU(ddddd, reg_buf);
			if (err <= 0)
				return err;
			sprintf(pmove_buf, "%s,", reg_buf);
			ddddd = (opcodeWord & 0x1Ful);
			err = DecodeRegisterALU(ddddd, reg_buf);	/* destination register */
			if (err <= 0)
				return err;
			strcat(pmove_buf, reg_buf);
			return err;
			}
		  else
			{
			/* I: move -- [001d dddd iiii iiii] */
			imm = (unsigned short)(opcodeWord & 0x0FFul);
			ddddd = (unsigned char)((opcodeWord & 0x1F00ul)>>8);
			err = DecodeRegisterALU(ddddd, reg_buf);
			if (err <= 0)
				return err;
				
			/*
			RBJ - To attempt to use a symbol for the immediate address field
			in a 'move  #imm,Rn' instruction, we're gonna run this through
			FindSymbol() and print the symbol that comes out.
			If Rn is R0-R3, search X: Y: L: P: N: in that order,
			if Rn is R4-R7, search Y: X: L: P: N: in that order.
			*/
			imm_float = (double)imm/128.0;
			if (imm >= 0x80)
				imm_float -= 2.0;
			if (reg_buf[0] == 'r')
				{
				if (reg_buf[1] <= '3')
					FindSymbol(eXYLPNSearch, (unsigned long)imm, ea_buf);
				  else
					FindSymbol(eYXLPNSearch, (unsigned long)imm, ea_buf);
				sprintf(pmove_buf, "#<%s,%c%c", ea_buf, 'r', reg_buf[1]);
				}
			  else if (reg_buf[0] == 'x' || reg_buf[0] == 'y')
				{
				sprintf(pmove_buf, "#<%1.7lf,%c%c", imm_float, reg_buf[0], reg_buf[1]);
				}
			  else if (reg_buf[0] == 'a' || reg_buf[0] == 'b')
				{
				if (reg_buf[1] == '\0')
					sprintf(pmove_buf, "#<%1.7lf,%c", imm_float, reg_buf[0]);
				  else
					sprintf(pmove_buf, "#<$%06X,%c%c", imm, reg_buf[0], reg_buf[1]);
				}
			  else
				sprintf(pmove_buf, "#<$%04X,%c%c", imm, reg_buf[0], reg_buf[1]);
			
			return err;
			}
		}

	/* X:,Y:,L: check */
	if ((opcodeWord & 0xC000ul) == 0x4000ul)
		{				/* RBJ - changed all pmove_buf's to temp_buf's then strcat at end */
		/* X:,Y:,or L: move */
		if ((opcodeWord & 0xF400ul) == 0x4000ul)
			{
			/* L: move -- [0100 L0LL W1MM MRRR] */
			temp = 'l';
			LLL = (unsigned char)(opcodeWord >> 8);
			LLL = (LLL & 0x03)|((LLL & 0x08) >> 1);
			memspace = eLSpace;
			sprintf(reg_buf, "%s", LLL_decode[LLL]);	
			}
		  else
			{
			/* X: or Y: -- [01dd Yddd W1MM MRRR] */
			/* get ddddd field from ddxddd in bits 21..16 */
			ddddd = (unsigned char)(opcodeWord >> 8);
			ddddd = (ddddd & 0x07)|((ddddd & 0x30) >> 1);
			err = DecodeRegisterALU(ddddd, reg_buf);
			if (err <= 0)
				return err;
		
			/* get X or Y designation */
			temp = (unsigned char)((opcodeWord & 0x0800ul) ? 'y':'x');
			memspace = (temp == 'y') ? eYSpace : eXSpace;
			}
		/* Rest applies to any of X,Y, or L moves */
		if (opcodeWord & 0x0040ul)
			{
			/* X/Y/L:ea move */
			src = (opcodeWord & 0x0080ul) ? kSrcOp : kDstOp;
			err = DecodeEffectiveAddress(memspace, ea, extensionWord, ea_buf, src);
			if (err <= 0)
				return err;
			if (src == kSrcOp)
				{
				if ((ea&0x3F) == 0x34)
					{
					imm_float = (double)extensionWord/8388608.0;
					if (extensionWord >= 0x800000)
						imm_float -= 2.0;
					if (reg_buf[0] == 'r')
						{
						if (reg_buf[1] <= '3')
							FindSymbol(eXYLPNSearch, extensionWord, ea_buf);
						  else
							FindSymbol(eYXLPNSearch, extensionWord, ea_buf);
						sprintf(temp_buf, "#>%s,%c%c", ea_buf, 'r', reg_buf[1]);
						}
					  else if (reg_buf[0] == 'x' || reg_buf[0] == 'y')
						{
						sprintf(temp_buf, "#>%1.8lf,%c%c", imm_float, reg_buf[0], reg_buf[1]);
						}
					  else if (reg_buf[0] == 'a' || reg_buf[0] == 'b')
						{
						if (reg_buf[1] == '\0')
							sprintf(temp_buf, "#>%1.8lf,%c", imm_float, reg_buf[0]);
						  else
							sprintf(temp_buf, "#>$%06lX,%c%c", extensionWord, reg_buf[0], reg_buf[1]);
						}
					  else
						sprintf(temp_buf, "%s,%s", ea_buf, reg_buf);
					}
				  else
					sprintf(temp_buf, "%s,%s", ea_buf, reg_buf);			
				}
			  else
				sprintf(temp_buf, "%s,%s", reg_buf, ea_buf);\
			}
		  else
			{
			/* absolute short address X: or Y: or L: move */
			imm = (unsigned short)(opcodeWord & 0x03Ful);
			FindSymbol(memspace, (unsigned long)imm, ea_buf);
			if (opcodeWord & 0x0080ul)	/* X/Y:aa,D */
				sprintf(temp_buf, "%c:<%s,%s", temp, ea_buf, reg_buf);
			  else
				sprintf(temp_buf, "%s,%c:<%s", reg_buf, temp, ea_buf);	
			}
		for (i = 0; i < kPMoveSpacing; i++)		/* RBJ added to move y: only moves to the right column */
			pmove_buf[i] = ' ';
		if (temp != 'y')
			i = 0;
		pmove_buf[i] = '\0';
		strcat(pmove_buf, temp_buf);
		return err;
		}	

	/* Class I X:R and R:Y check */	
	if ((opcodeWord & 0xF000ul) == 0x1000ul)
		{
		/* Class I R:Y or X:R move */
		src = (opcodeWord & 0x0080ul) ? kSrcOp : kDstOp;
		if (opcodeWord & 0x0040)
			{
			/* R:Y -- [0001 deff W1MM MRRR] */
			err = DecodeEffectiveAddress(eYSpace, ea, extensionWord, ea_buf, src);
			if (err <= 0)
				return err;
			ddddd = (unsigned char)((opcodeWord & 0x0800)>>11);		/* S1 */
			rrr = (unsigned short)((opcodeWord & 0x0400)>>10);		/* D1 */
			sprintf(pmove_buf, "%s,x%hi", d_decode[ddddd], rrr);
			ddddd = (unsigned char)((opcodeWord & 0x0100)>>8);
			if (opcodeWord & 0x0200)
				sprintf(reg_buf, "%s", d_decode[ddddd]);			/* A or B */
			  else
				sprintf(reg_buf, "y%hi", (unsigned short)ddddd);	/* Y0 or Y1 */
			
			len = strlen(pmove_buf);		/* add spaces for formatting */
			if ((kPMoveSpacing - len) < kMinSpacing)
				padlen = len + kMinSpacing;
			  else
				padlen = kPMoveSpacing;
			for (i = len; i < padlen; i++)
				pmove_buf[i] = ' ';
			pmove_buf[i] = '\0';
			if (src == kSrcOp)
				sprintf(temp_buf, "%s,%s", ea_buf, reg_buf);
			  else
				sprintf(temp_buf, "%s,%s", reg_buf, ea_buf);
			strcat(pmove_buf, temp_buf);
			}
		  else
			{
			/* X:R -- [0001 ffdf W0MM MRRR] */
			err = DecodeEffectiveAddress(eXSpace, ea, extensionWord, ea_buf, src);
			if (err <= 0)
				return err;
			ddddd = (unsigned char)((opcodeWord & 0x0400)>>10);		/* S1|D1 */
			if (opcodeWord & 0x0800)
				sprintf(reg_buf, "%s", d_decode[ddddd]);			/* A or B */
			  else
				sprintf(reg_buf, "x%hi", (unsigned short)ddddd);	/* X0 or X1 */
			if (src == kSrcOp)
				sprintf(pmove_buf, "%s,%s", ea_buf, reg_buf);
			  else
				sprintf(pmove_buf, "%s,%s", reg_buf, ea_buf);
				
			len = strlen(pmove_buf);		/* add spaces for formatting */
			if ((kPMoveSpacing - len) < kMinSpacing)
				padlen = len + kMinSpacing;
			  else
				padlen = kPMoveSpacing;
			for (i = len; i < padlen; i++)
				pmove_buf[i] = ' ';
			pmove_buf[i] = '\0';
						
			ddddd = (unsigned char)((opcodeWord & 0x0200)>>9);		/* S2 */
			rrr = (unsigned short)((opcodeWord & 0x0100)>>8);		/* D2 */			
			sprintf(temp_buf, "%s,y%hi", d_decode[ddddd], rrr);			
			strcat(pmove_buf, temp_buf);
			}
		return err;
		}
	
	/* Class II X:R and R:Y check */
	if (((opcodeWord & 0xFEC0ul) == 0x0800ul) || ((opcodeWord & 0xFEC0ul) == 0x0880ul))
		{
		/* Class II R:Y or X:R move */
		/* 1)	A/B,X:ea	X0,A/B		-- [0000 100d 00MM MRRR] */
		/* 2)	Y0,A/B		A/B,Y:ea	-- [0000 100d 10MM MRRR] */	
		memspace = (opcodeWord & 0x0080ul) ? eYSpace : eXSpace;
		if ((ea & 0x38) == 0x30)	/* abs/imm addressing not allowed */
			return 0;
		err = DecodeEffectiveAddress(memspace, ea, extensionWord, ea_buf, kDstOp);
		if (err <= 0)
			return err;
		temp = (opcodeWord & 0x0100) >> 8 ;
		if (opcodeWord & 0x0080)
			{
			/* R:Y */
			sprintf(pmove_buf, "y0,%s", d_decode[temp]);
			sprintf(temp_buf, "%s,%s", d_decode[temp], ea_buf);
			}
		  else
			{
		 	/* X:R */
			sprintf(pmove_buf, "%s,%s", d_decode[temp], ea_buf);
			sprintf(temp_buf, "x0,%s", d_decode[temp]);
			}
		
		len = strlen(pmove_buf);		/* add spaces for formatting */
		if ((kPMoveSpacing - len) < kMinSpacing)
			padlen = len + kMinSpacing;
		  else
			padlen = kPMoveSpacing;
		for (i = len; i < padlen; i++)
			pmove_buf[i] = ' ';
		pmove_buf[i] = '\0';

		strcat(pmove_buf, temp_buf);	/* add second portion */
		return err;
		}
	
	/* didn't find anything so return an error */
	return 0;
	}	/* end p_move() */

/*
	---------------------------------------------------------------------------
	p_mults
	---------------------------------------------------------------------------
	decode the opcode of a multiply parallel move instruction (in LS 8 bits)

	Formats:
		MACR		1QQQ dk11
		MAC			1QQQ dk10
		MPYR		1QQQ dk01
		MPY			1QQQ dk00
*/
int p_mults(unsigned long opcodeWord)
	{
	/*	
		Type of multiply encoded in bit 1: MPY = 0, MAC = 1.
		Round tag in bit 0 -> 'R' = 1, ' ' = 0.
		Sign in bit 2 -> '+' = 0, '-' = 1.
		Source inputs encoded in bits 6..4 -> decoded in QQQ matrix.
		Accumulator tag in bit 3 -> 'A' = 0,'B' = 1.
	*/	
	unsigned long	i;
	char			*QQQ[] = {"x0,x0,","y0,y0,","x1,x0,","y1,y0,","x0,y1,","y0,x0,","x1,y0,","y1,x1,"};

	/* only look at the last 8 bits for the opcode */
	opcodeWord &= 0x0000FFul;
	
	/* make sure it's a multiply instruction (bit 7 is set) */
	if (!(opcodeWord & 0x80ul))
		return 0;
		
	/* type decode */
	if (opcodeWord & 0x02ul)
		sprintf(opcode_buf, "mac");
	  else
		sprintf(opcode_buf, "mpy");
	
	/* round option decode */
	if (opcodeWord & 0x01ul)
		strcat(opcode_buf, "r");
	
	/* sign decode */
	if (opcodeWord & 0x04ul)
		sprintf(operand_buf, "-");
	  else
		sprintf(operand_buf, "\0");	
	
	/* source operand decode -> QQQ matrix index = decoded sources */
	i = ((opcodeWord & 0x70ul) >> 4);
	strcat(operand_buf, QQQ[i]);
	
	/* destination operand decoded in bit 3 */
	strcat(operand_buf, d_decode[(opcodeWord & 0x08ul) >> 3]);

	return 1;
	} /* end p_mults() */

/*
	---------------------------------------------------------------------------
	p_non_mults
	---------------------------------------------------------------------------
	decode the opcode of a non-multiply parallel move instruction (in LS 8 bits)

	Formats:
		CMPM	0JJJ d111,	AND		01JJ d110,	CMP		0JJJ d101
		SUB		0JJJ d100,	EOR		01JJ d011,	OR		01JJ d010
		TFR		0JJJ d001,	ADD		0JJJ d000,	SBC		001J d101
		ADC		001J d001,	ROL		0011 d111,	NEG		0011 d110
		LSL		0011 d011,	ASL		0011 d010,	ROR		0010 d111
		ABS		0010 d110,	ABS		0010 d110,	LSR		0010 d011
		ASR		0010 d010,	NOT		0001 d111,	SUBL	0001 d110
		CLR		0001 d011,	ADDL	0001 d010,	RND		0001 d001
		SUBR	0000 d110,	TST		0000 d011,	ADDR	0000 d010
*/
#define ADD		0x0
#define TFR 	0x1
#define OR		0x2
#define EOR		0x3
#define SUB		0x4
#define CMP		0x5
#define AND		0x6
#define CMPM	0x7
int p_non_mults(unsigned long opcodeWord)
	{
	int				err = 1;
	unsigned long	index = (opcodeWord & 0x30ul) >> 4;		/* source Xn/Yn */
	unsigned long	index2 = (opcodeWord & 0x8ul) >> 3;		/* dest. A/B */
	unsigned long	index3 = (opcodeWord & 0x10ul) >> 4;	/* source X,Y */
	
	char			*JJ_2[] = {"x0","y0","x1","y1"};		/* 2nd half matrix */
	char			XY[] = {'x','y'};

	/* check for bit 7 being set --> error */
	if (opcodeWord & 0x80ul)
		return 0;
		
	/* break the opcode down into halves - see p. A-332 */
	if (opcodeWord & 0x40ul)
		{
		/* one of 2nd half opcodes: JJJ = 1xx */
		switch (opcodeWord & 0x07ul)
			{
			case ADD:
				sprintf(opcode_buf, "add");
				sprintf(operand_buf, "%s,%s", JJ_2[index], d_decode[index2]);
				break;
			case TFR:
				sprintf(opcode_buf, "tfr");
				sprintf(operand_buf, "%s,%s", JJ_2[index], d_decode[index2]);
				break;
			case OR:
				sprintf(opcode_buf, "or");
				sprintf(operand_buf, "%s,%s", JJ_2[index], d_decode[index2]);
				break;
			case EOR:
				sprintf(opcode_buf, "eor");
				sprintf(operand_buf, "%s,%s", JJ_2[index], d_decode[index2]);
				break;
			case SUB:
				sprintf(opcode_buf, "sub");
				sprintf(operand_buf, "%s,%s", JJ_2[index], d_decode[index2]);
				break;
			case CMP:
				sprintf(opcode_buf, "cmp");
				sprintf(operand_buf, "%s,%s", JJ_2[index], d_decode[index2]);
				break;
			case AND:
				sprintf(opcode_buf, "and");
				sprintf(operand_buf, "%s,%s", JJ_2[index], d_decode[index2]);
				break;
			case CMPM:
				sprintf(opcode_buf, "cmpm");
				sprintf(operand_buf, "%s,%s", JJ_2[index], d_decode[index2]);
				break;
			default:
				/* should not get here */
				err = 0;
				break;
				}
		/* end of 2nd half checks: JJJ = 1xx */
		}
	/* must be one of the more confusing 1st half instructions */
	  else if (!(opcodeWord & 0x20ul))
		{
		/* 1st and 2nd rows of 1st half: JJJ = 00x */
		if (opcodeWord & 0x10ul)
			{	
			/* 2nd row of 1st half: JJJ = 001 */
			switch (opcodeWord & 0x07ul)
				{
				case 0x0:
					sprintf(opcode_buf, "add");
					sprintf(operand_buf, "%s,%s", d_decode[!index2], d_decode[index2]);
					break;
				case 0x1:
					sprintf(opcode_buf, "rnd");
					sprintf(operand_buf, "%s", d_decode[index2]);
					break;
				case 0x2:
					sprintf(opcode_buf, "addl");
					sprintf(operand_buf, "%s,%s", d_decode[!index2], d_decode[index2]);
					break;
				case 0x3:
					sprintf(opcode_buf, "clr");
					sprintf(operand_buf, "%s", d_decode[index2]);
					break;
				case 0x4:
					sprintf(opcode_buf, "sub");
					sprintf(operand_buf, "%s,%s", d_decode[!index2], d_decode[index2]);
					break;
				case 0x5:
					err = 0;		/* reserved instruction */
					break;
				case 0x6:
					sprintf(opcode_buf, "subl");
					sprintf(operand_buf, "%s,%s", d_decode[!index2], d_decode[index2]);
					break;
				case 0x7:
					sprintf(opcode_buf, "not");
					sprintf(operand_buf, "%s", d_decode[index2]);
					break;
				default:
					/* should not get here */
					err = 0;
					break;
				}
			/* end of 2nd row of 1st half: JJJ = 001 */
			}		
		  else	
			{
			/* 1st row of 1st half: JJJ = 000 */
			switch (opcodeWord & 0x07ul)
				{
				case 0x0:
					/* NOP w/ a parallel move (bit 7 set is reserved) */
					if (opcodeWord & 0x08ul)
						err = 0;
					sprintf(opcode_buf, "\0");
					sprintf(operand_buf, "\0");					
					break;
				case 0x1:
					sprintf(opcode_buf, "tfr");
					sprintf(operand_buf, "%s,%s", d_decode[!index2], d_decode[index2]);
					break;
				case 0x2:
					sprintf(opcode_buf, "addr");
					sprintf(operand_buf, "%s,%s", d_decode[!index2], d_decode[index2]);
					break;
				case 0x3:
					sprintf(opcode_buf, "tst");
					sprintf(operand_buf, "%s", d_decode[index2]);
					break;
				case 0x4:
					err = 0;
					break;
				case 0x5:
					sprintf(opcode_buf, "cmp");
					sprintf(operand_buf, "%s,%s", d_decode[!index2], d_decode[index2]);
					break;
				case 0x6:
					sprintf(opcode_buf, "subr");
					sprintf(operand_buf, "%s,%s", d_decode[!index2], d_decode[index2]);
					break;
				case 0x7:
					sprintf(opcode_buf, "cmpm");
					sprintf(operand_buf, "%s,%s", d_decode[!index2], d_decode[index2]);
					break;
				default:
					err = 0;
					break;			
				}
			/* end of 1st row of 1st half: JJJ = 000 */
			}
		}
	  else
		{
		/* preemptively assume this section is mostly single operand instructions */
		sprintf(operand_buf, "%s", d_decode[index2]);
		
		/* 3rd and 4th rows of 1st half: JJJ = 01x */	
		switch (opcodeWord & 0x07ul)
			{
			case 0x0:
				sprintf(opcode_buf, "add");
				break;
			case 0x1:
				sprintf(opcode_buf, "adc");
				break;
			case 0x2:
				if (index3)
					sprintf(opcode_buf, "asl");
				  else
					sprintf(opcode_buf, "asr");
				return err;
			case 0x3:
				if (index3)
					sprintf(opcode_buf, "lsl");
				  else
					sprintf(opcode_buf, "lsr");
				return err;
			case 0x4:
				sprintf(opcode_buf, "sub");
				break;
			case 0x5:
				sprintf(opcode_buf, "sbc");
				break;
			case 0x6:
				if (index3)
					sprintf(opcode_buf, "neg");
				  else
					sprintf(opcode_buf, "abs");
				return err;
			case 0x7:
				if (index3)
					sprintf(opcode_buf, "rol");
				  else
					sprintf(opcode_buf, "ror");
				return err;
			default:
				err = 0;
				break;
			}
		
		/* only do this for 2 operand cases */
		/* kkk = x1x chooses A/B source, X/Y otherwise */
		if (opcodeWord & 0x2ul)
			sprintf(operand_buf, "%s,%s", d_decode[!index2], d_decode[index2]);
		  else
			sprintf(operand_buf, "%c,%s", XY[index3], d_decode[index2]);
		}
			
	return err;
	} /* end p_non_mults() */


/*
	---------------------------------------------------------------------------
	DecodeNonParallel
	---------------------------------------------------------------------------
	break the non-parallel instruction into groups for decoding
*/
int DecodeNonParallel(unsigned long opcodeWord, unsigned long extensionWord)
	{
	int		err = 0;
	
	#ifdef _DEBUG
	fprintf(stderr, "non-parallel instruction -> ");
	#endif
	
	switch(opcodeWord & 0x0F0000ul)
		{
		case 0x0F0000ul:
		case 0x0E0000ul:
		case 0x0D0000ul:
		case 0x0C0000ul:
			/* Jump instructions (JSR, JMP, Jcc, JScc) */
			err = np_jumps(opcodeWord, extensionWord);
			#ifdef _DEBUG
			fprintf(stderr, "np_jumps().\n");
			#endif
			break;
		case 0x0B0000ul:
		case 0x0A0000ul:
			/*
				Jump on bit condition instructions and Bit manipulation instructions
				- but, overlap with JSR, JMP, Jcc, and JScc instructions so distinguish them
				-- the 'jumps' have the pattern [0000 101x 11xx xxxx 1xxx xxxx] where
				--	bit 7 = 1 is the deciding factor for the rest of the pattern
			*/
			if ((opcodeWord & 0xFEC080ul) == 0x0AC080ul)
				{
				err = np_jumps(opcodeWord, extensionWord);	/* JSR, JMP, Jcc, JScc */
				#ifdef _DEBUG
				fprintf(stderr, "np_jumps().\n");
				#endif
				}
			  else
				{
				err = np_bit(opcodeWord, extensionWord);	/* Bit instruction */
				#ifdef _DEBUG
				fprintf(stderr, "np_bit().\n");
				#endif
				}
			break;
		case 0x090000ul:
		case 0x080000ul:
			/* MOVEP instructions */
			err = np_movep(opcodeWord, extensionWord);
			#ifdef _DEBUG
			fprintf(stderr, "np_movep().\n");
			#endif
			break;
		case 0x070000ul:
			/* MOVEM instructions */
			err = np_movem(opcodeWord, extensionWord);
			#ifdef _DEBUG
			fprintf(stderr, "np_movem().\n");
			#endif
			break;
		case 0x060000ul:
			/* REP and DO instructions */
			err = np_loops(opcodeWord, extensionWord);
			#ifdef _DEBUG
			fprintf(stderr, "np_loops().\n");
			#endif
			break;
		case 0x050000ul:
		case 0x040000ul:
			/* MOVEC instructions (and LUA) */
			err = np_movec(opcodeWord, extensionWord);
			#ifdef _DEBUG
			fprintf(stderr, "np_movec().\n");
			#endif
			break;
		case 0x030000ul:
		case 0x020000ul:
			/* Tcc instructions */
			err = np_xfer(opcodeWord, extensionWord);
			#ifdef _DEBUG
			fprintf(stderr, "np_xfer().\n");
			#endif
			break;
		case 0x010000ul:
			/* non-parallel ALU instructions */
			/* - NORM, DIV, MAC #n, MACR #n, MPY #n, MPYR #n */
			err = np_alu(opcodeWord, extensionWord);
			#ifdef _DEBUG
			fprintf(stderr, "np_alu().\n");
			#endif
			break;
		case 0x0ul:
			/* unique instructions */
			/* - DEBUGcc, DEBUG, ORI, ANDI, ENDDO, STOP, WAIT, RESET, */
			/*	 RTS, DEC, INC, SWI, ILLEGAL, RTI */
			err = np_unique(opcodeWord, extensionWord);
			#ifdef _DEBUG
			fprintf(stderr, "np_unique().\n");
			#endif
			break;		
		default:
			#ifdef _DEBUG
			fprintf(stderr, "unknown non-parallel instruction (0x%lX)\n", opcodeWord);
			#endif
			break;
		}
	return err;
	}

/*
	---------------------------------------------------------------------------
	np_jumps
	---------------------------------------------------------------------------
	jump instructions (jmp, jcc, jscc, jsr)

	Formats:
		JScc	xxx		0000 1111 CCCC aaaa aaaa aaaa
		Jcc		xxx		0000 1110 CCCC "
		JSR		xxx		0000 1101 0000 "
		JMP		xxx		0000 1100 0000 "
		JScc	ea		0000 1011 11MM MRRR 1010 CCCC
		Jcc		ea		0000 1010 "
		JSR		ea		0000 1011 11MM MRRR 1000 0000
		JMP		ea		0000 1010 "
*/
int np_jumps(unsigned long opcodeWord, unsigned long extensionWord)
	{
	int				err = 1;
	unsigned long	addr;
	unsigned long	CCCC;
	unsigned char	effAddr;
	
	/* search for absolute address versions first */
	switch (opcodeWord & 0xFF0000ul)
		{
		case 0x0F0000ul:
			/* JScc xxx */
			CCCC = (opcodeWord & 0xF000ul) >> 12;
			sprintf(opcode_buf, "js%s", CCCC_decode[CCCC]);
			break;
		case 0x0E0000ul:
			/* Jcc	xxx */
			CCCC = (opcodeWord & 0xF000ul) >> 12;
			sprintf(opcode_buf, "j%s", CCCC_decode[CCCC]);
			break;
		case 0x0D0000ul:
			/* JSR xxx */
			if (opcodeWord & 0x00F000ul)
				return 0;	/* if non-zero, not a valid instruction */
			strcpy(opcode_buf, "jsr");
			break;
		case 0x0C0000ul:
			/* JMP xxx */
			if (opcodeWord & 0x00F000ul)
				return 0;	/* if non-zero, not a valid instruction */
			strcpy(opcode_buf, "jmp");
			break;
		default:
			err = 0;		/* didn't find one here, fall through to next section */
			break;
		}
	/* decode the address portion of the above four instructions if no error was detected */
	/* - otherwise, fall through to the next section */
	if (err != 0)
		{
		addr = opcodeWord & 0xFFFul;
		FindSymbol(ePSpace, addr, ea_buf);
		sprintf(operand_buf, "<%s", ea_buf);
		return 1;
		}
	
	/* search for effective address versions now */
	switch (opcodeWord & 0xFFC0F0ul)
		{
		case 0x0BC0A0ul:		
			/* JScc ea */
			CCCC = opcodeWord & 0xFul;
			sprintf(opcode_buf, "js%s", CCCC_decode[CCCC]);
			break;
		case 0x0BC080ul:
			/* JSR ea */
			if (opcodeWord & 0xFul)
				return 0;	/* if non-zero, not a valid instruction */
			strcpy(opcode_buf, "jsr");
			break;
		case 0x0AC0A0ul:
			/* Jcc ea */
			CCCC = opcodeWord & 0xFul;
			sprintf(opcode_buf, "j%s", CCCC_decode[CCCC]);
			break;
		case 0x0AC080ul:
			/* JMP ea */
			if (opcodeWord & 0xFul)
				return 0;	/* if non-zero, not a valid instruction */
			strcpy(opcode_buf, "jmp");
			break;
		default:
			return 0;		/* didn't find one here, return error */
		}

	/* if we made it this far, we have an effective address to decode */
	/*	into the operand buf */
	effAddr = (unsigned char)((opcodeWord & 0x3F00ul) >> 8);

	/* RBJ - check for abs addressing */
	if ((effAddr&0x3B) == 0x30)
		{
		operand_buf[0] = '>';
		FindSymbol(ePSpace, extensionWord, &operand_buf[1]);
		err = 2;
		}
	  else
		err = DecodeEffectiveAddress(eNullSpace, effAddr, extensionWord, operand_buf, kDstOp);

	return err;
	}

/*
	---------------------------------------------------------------------------
	np_bit
	---------------------------------------------------------------------------
	The bit test/change/jmp/etc. instructions
	- jsset, jsclr, jset, jclr, btst, bchg, bset, bclr

	Formats: these are too messy to list out individually but the basic idea is
		<op>	#n,X/Y:pp[,xxxx]	0000 oooo 10pp pppp ooob bbbb
		<op>	#n,X/Y:ea[,xxxx]	0000 oooo 01MM MRRR ooob bbbb
		<op>	#n,X/Y:aa[,xxxx]	0000 oooo 00aa aaaa ooob bbbb
		<op>	#n,S[,xxxx]			0000 oooo 11dd dddd ooob bbbb

		where <op> is the opcode, [,xxxx] is the optional jump address for the
			jump versions, and the 'ooo...' fields encode which opcode it is.
			See pp. A-319 thru A-324 for more info.

	Note:	There are special cases where the jump instruction decoding overlaps	
			with the bit instructions.  These occur when bits [15:14] = 11.
			If this is the case, then the decoding defaults to a jump version
			but only if bit six is clear.  It's weird, I know.
*/
int np_bit(unsigned long opcodeWord, unsigned long extensionWord)
	{
	unsigned short	bitAddr;
	unsigned short	bbbbb;
	int				memSpace;
	unsigned short	jmpAddr;
	int				err;
	int				isJump = 0;		/* is Jxxx instruction, not Bxxx instruction */
	unsigned short	bitSixSet;		/* used for a certain patterns of instructions */
	unsigned short	isSpecial;		/* used to denote for special cases */
	char			scratch[40];
	unsigned long	tempAddr;
	
	/* first, check for an illegal bit encoding */
	/* - the LS 5 bits cannot have the pattern 11bbb. */
	if ((opcodeWord & 0x18ul) == 0x18ul)
		return 0;
				
	/* prepare for special cases */
	bitSixSet = (opcodeWord & 0x40ul) ? 1 : 0;
	isSpecial = ((opcodeWord & 0x00C000ul) == 0x00C000ul) ? 1 : 0;
		
	/* second, decode the opcode */
	err = 1;
	switch (opcodeWord & 0xFF00A0ul)
		{
		case 0x0B00A0ul:
			/* JSSET */
			sprintf(opcode_buf, "jsset");
			isJump = 1;
			break;
		case 0x0B0080ul:
			/* JSCLR */
			sprintf(opcode_buf, "jsclr");
			isJump = 1;
			break;
		case 0x0A00A0ul:
			/* JSET */
			sprintf(opcode_buf, "jset");
			isJump = 1;
			break;
		case 0x0A0080ul:
			/* JCLR */
			sprintf(opcode_buf, "jclr");
			isJump = 1;
			break;
		case 0x0B0020ul:
			/* BTST */
			if ( !isSpecial)
				sprintf(opcode_buf, "btst");
			  else if ( !bitSixSet )
				{
				sprintf(opcode_buf, "jsset");	/* special case but only if bit 6 clear */
				isJump = 1;
				}
			  else
				sprintf(opcode_buf, "btst");	/* special case with bit 6 set */
			break;
		case 0x0B0000ul:
			/* BCHG */
			if ( !isSpecial )
				sprintf(opcode_buf, "bchg");
			  else if ( !bitSixSet )
				{
				sprintf(opcode_buf, "jsclr");	/* special case but only if bit 6 clear */
				isJump = 1;
				}
			  else
				sprintf(opcode_buf, "bchg");	/* special case with bit 6 set */
			break;			
		case 0x0A0020ul:
			/* BSET */
			if ( !isSpecial )
				sprintf(opcode_buf, "bset");
			  else if ( !bitSixSet )
				{
				sprintf(opcode_buf, "jset");	/* special case but only if bit 6 clear */
				isJump = 1;
				}
			  else
				sprintf(opcode_buf, "bset");	/* special case with bit 6 set */
			break;
		case 0x0A0000ul:
			/* BCLR */
			if ( !isSpecial )
				sprintf(opcode_buf, "bclr");
			  else if ( !bitSixSet )
				{
				sprintf(opcode_buf, "jclr");	/* special case but only if bit 6 clear */
				isJump = 1;
				}
			  else
				sprintf(opcode_buf, "bclr");	/* special case with bit 6 set */
			break;
		default:
			return 0;							/* invalid opcode found */
		}
	
	/* next, decode the common portions of all the instructions */
	
	/* decode the bit number */
	/* - bits [4:0] */
	bbbbb = (unsigned short)(opcodeWord & 0x1Ful);
	sprintf(operand_buf, "#%hi,", bbbbb);
	
	/* decode the memory space (not used for <opcode #n,S,xxxx> instructions) */
	/* - memory space bit is bit 6 (0 = X, 1 = Y) */
	memSpace = (opcodeWord & 0x000040ul) ? eYSpace : eXSpace;
	
	/* decode the address space for the operand under bit test */
	/* - bits [13:8] */
	bitAddr = (unsigned char)((opcodeWord & 0x003F00ul) >> 8);
	jmpAddr = extensionWord & 0x00FFFFul;	/* only 16 bit address is valid -- is more an error? */
	switch (opcodeWord & 0x00C000ul)
		{
		case 0x008000ul:
			/* <op> #n,X/Y:pp[,xxxx] */
			bitAddr += (unsigned char)0xC0;	/* peripheral addresses are FFC0 + bitAddr */
			if (memSpace == eXSpace)		/* adjust mem space to be a peripheral space for symbol lookup */
				memSpace = eXPeriphSpace;
			  else
				memSpace = eYPeriphSpace;
			tempAddr = (unsigned long)bitAddr + 0xFF00;
			FindSymbol(memSpace, tempAddr, scratch);
			sprintf(ea_buf, "%c:<<%s", ((memSpace == eYPeriphSpace) ? 'y' : 'x'), scratch);
			strcat(operand_buf, ea_buf);	/* add the two pieces */
			err = 1;
			break;
		case 0x004000ul:
			/* <op> #n,X/Y:ea[,xxxx] */
			if (isJump && ((bitAddr & 0x38) == 0x30))	/* abs addr and immediate data not allowed */
				return 0;								/*	for the jump class of instructions */
				/* Note: immediate data not allowed for bit manipulation instructions but this	*/
				/*	is taken care of in DecodeEffectiveAddress by specifying it's a destination code */
			err = DecodeEffectiveAddress(memSpace, bitAddr, extensionWord, ea_buf, kDstOp);
			if (err <= 0)
				return err;
			strcat(operand_buf, ea_buf);	/* add up the result */
			break;
		case 0x000000ul:
			/* <op> #n,X/Y:aa[,xxxx] */
			FindSymbol(memSpace, (long)bitAddr, scratch);	/* RBJ - changed this */
			sprintf(ea_buf, "%c:<%s", ((memSpace == eYSpace) ? 'y' : 'x'), scratch);
			strcat(operand_buf, ea_buf);	/* add the two pieces */
			err = 1;
			break;
		case 0x00C000ul:
			/* <op> #n,S[,xxxx] */
			err = DecodeRegister(bitAddr, reg_buf);	/* decode the register under test */
			if (err <= 0)
				return err;
			strcat(operand_buf, reg_buf);	/* add the two pieces */
			err = 1;
			break;
		}
	
	/* add the jump address portion if it's a jump instruction */
	if (isJump)
		{
		FindSymbol(ePSpace, (long)jmpAddr, scratch);
		sprintf(ea_buf, ",%s", scratch);
		strcat(operand_buf, ea_buf);
		err = 2;
		}
	return err;
	}

/*
	---------------------------------------------------------------------------
	np_movep
	---------------------------------------------------------------------------
	MOVEP instructions for moving data to/from the peripheral memory spaces.

	Formats:
		movep	X/Y:ea,X/Y:pp		0000 100S W1MM MRRR 1spp pppp
				X/Y:pp,X/Y:ea
		movep	P:ea,X/Y:pp			0000 100S W1MM MRRR 01pp pppp
				X/Y:pp,P:ea
		movep	S,X/Y:pp			0000 100S W1dd dddd 00pp pppp
				X/Y:pp,D

	NOTE:		in the user's manual, the placement of the X/Y effective address
			memory space bit and the corresponding X/Y peripheral memory space
			bit are swapped with the other instruction types (P and register).
			The relevant pages are A-224 and A-324.  I'm just treating them the
			same as the P and register versions and it seems to match with the
			assembler so I'm assuming that's correct.
*/
int np_movep(unsigned long opcodeWord, unsigned long extensionWord)
	{
	unsigned char		effAddr, ppMemChar;
	int					memSpace, ppMemSpace;
	int					src;
	unsigned short		pppppp;	
	int					err;
	char				pp_buf[20];
	
	/* set opcode to "movep" */
	sprintf(opcode_buf, "movep");
	
	/* first, figure out the memory space attributes */
	ppMemSpace = (opcodeWord & 0x010000ul) ? eYPeriphSpace : eXPeriphSpace;
	ppMemChar = (ppMemSpace == eXPeriphSpace) ? 'x' : 'y';
	memSpace = (opcodeWord & 0x40ul) ? eYSpace : eXSpace;
	pppppp = (unsigned short)((opcodeWord & 0x3Ful) | 0xFFC0ul);
	effAddr = (unsigned char)((opcodeWord & 0x3F00ul) >> 8);
	src = (opcodeWord & 0x008000ul) ? kSrcOp : kDstOp;
	
	/* do symbol lookup on the given peripheral space */
	FindSymbol(ppMemSpace, pppppp, pp_buf);
			
	/* figure out which type of movep it was */
	switch (opcodeWord & 0xFE40C0ul)
		{
		case 0x084040ul:
			/* movep P */
			memSpace = ePSpace;	/* set memSpace and fall through */
		case 0x084080ul:
		case 0x0840C0ul:			
			/* movep X/Y and movep P share common decode except for the memory space */
			err = DecodeEffectiveAddress(memSpace, effAddr, extensionWord, ea_buf, src);
			if (err <= 0)
				return err;
			/* complete the decode */
			if (src == kSrcOp)
				/* ea_buf holds source operand */
				sprintf(operand_buf, "%s,%c:<<%s", ea_buf, ppMemChar, pp_buf);
			  else
				sprintf(operand_buf, "%c:<<%s,%s", ppMemChar, pp_buf, ea_buf);
			return err;
		case 0x084000ul:
			/* movep <reg> - the <reg> bits are the same as the effAddr */
			err = DecodeRegister(effAddr, reg_buf);
			if (err <= 0)
				return err;
			if (src == kSrcOp)	/* reg is src */
				sprintf(operand_buf, "%s,%c:<<%s", reg_buf, ppMemChar, pp_buf);
			  else
				sprintf(operand_buf, "%c:<<%s,%s", ppMemChar, pp_buf, reg_buf);				
			return 1;
		default:
			return 0;
		}
	}

/*
	---------------------------------------------------------------------------
	np_movem
	---------------------------------------------------------------------------
	MOVEM instructions for moving data to/from Program memory

	Formats:
		S,P:ea or P:ea,D	0000 0111 W1MM MRRR 10dd dddd
		S,P:aa or P:aa,D	0000 0111 W0aa aaaa 00dd dddd
*/
int np_movem(unsigned long opcodeWord, unsigned long extensionWord)
	{
	unsigned char	regCode;
	unsigned char	effAddr;
	int				err;
	int				src;

	/* copy the opcode into the opcode buffer */
	strcpy(opcode_buf, "movem");	
	
	/* get the source/destination register first and decode it */
	regCode = (unsigned char)(opcodeWord & 0x3Ful);
	err = DecodeRegister(regCode, reg_buf);
	if (err <= 0)
		return 0;
	
	/* get the effective address (can be used for absolute address as well) */
	effAddr = (unsigned char)((opcodeWord & 0x3F00ul) >> 8);
	
	/* get the source/destination flag: 1 -> mem is source */
	src = (opcodeWord & 0x008000ul) ? kSrcOp : kDstOp;
		
	switch (opcodeWord & 0xFF40C0ul)
		{
		case 0x074080ul:
			/* MOVEM S,P:ea or MOVEM P:ea,D */
			err = DecodeEffectiveAddress(ePSpace, effAddr, extensionWord, ea_buf, src);
			if (err <= 0)
				return 0;
			if (src == kSrcOp)
				{
				/* MOVEM P:ea,D */
				sprintf(operand_buf, "%s,%s", ea_buf, reg_buf);
				}
			  else
				{
				/* MOVEM S,P:ea */
				sprintf(operand_buf, "%s,%s", reg_buf, ea_buf);
				}
			return err;
		case 0x070000ul:
			/* MOVEM S,P:aa or MOVEM P:aa,D */
			FindSymbol(ePSpace, (long)effAddr, ea_buf);	/* RBJ - added this */
			if (src == kSrcOp)
				{
				/* MOVEM P:aa,D */
				sprintf(operand_buf, "p:<%s,%s", ea_buf, reg_buf);	
				}
			  else
				{
				/* MOVEM S,P:aa */
				sprintf(operand_buf, "%s,p:<%s", reg_buf, ea_buf);	
				}
			return 1;
		default:
			return 0;	
		}
	return 0;
	}

/*
	---------------------------------------------------------------------------
	np_loops
	---------------------------------------------------------------------------
	REP and DO instructions for starting hardware assisted looping
	
	Formats:
		REP		#xxx		0000 0110 iiii iiii 1010 hhhh
				S			0000 0110 11dd dddd 0010 0000
				X/Y:ea		0000 0110 01MM MRRR 0s10 0000
				X/Y:aa		0000 0110 00aa aaaa 0s10 0000
		DO		#xxx,expr	0000 0110 iiii iiii 1000 hhhh
				S,expr		0000 0110 11DD DDDD 0000 0000
				X/Y:ea,expr	0000 0110 01MM MRRR 0S00 0000
				X/Y:aa,expr	0000 0110 00aa aaaa 0S00 0000
*/
int np_loops(unsigned long opcodeWord, unsigned long extensionWord)
	{
	int					err = 0;
	unsigned short		addr;
	unsigned char		space, reg;
	unsigned char		effAddr;
	int					memSpace;
	unsigned short		imm;
	
	/* find out if the opcode indicates a REP or a DO instruction */
	/* -> bit 5 = 1 for REP instructions */
	if (opcodeWord & 0x000020ul)
		{
		/* REP instructions */
		sprintf(opcode_buf, "rep");
		
		/* find one of the four available cases */
		if ((opcodeWord & 0xFF00F0) == 0x0600A0ul)
			{
			/* REP #xxx -- 12 bit immediate data */
			/* - hhhhiiiiiiii where [xxxx xxxx iiii iiii xxxx hhhh] */
			imm = (unsigned short)((opcodeWord & 0x00FF00ul) >> 8);
			imm |= (unsigned short)((opcodeWord & 0xFul) << 8);
			
			sprintf(operand_buf, "#%hi", imm);
			err = 1;			
			}
		  else if ((opcodeWord & 0xFFC0FF) == 0x06C020ul)
			{
			/* REP S */
			reg = (unsigned char)((opcodeWord & 0x003F00ul) >> 8);
			err = DecodeRegister(reg, operand_buf);	/* register placed into operand_buf[] for us */
			if (err != 1)
				return 0;
			}
		  else if ((opcodeWord & 0xFFC0BF) == 0x064020ul)
			{
			/* REP x:/y:ea */
			memSpace = (opcodeWord & 0x40ul) ? eYSpace : eXSpace;

			/* find the effective address (puts the result in operand_buf[] so we're done) */
			effAddr = (unsigned char)((opcodeWord & 0x003F00ul) >> 8);
			/* MMMRRR == 110RRR is not allowed for this instruction */
			if ((effAddr & 0x38) == 0x30)
				return 0;
			err = DecodeEffectiveAddress(memSpace, effAddr, extensionWord, operand_buf, kDstOp);
			return err;
			}
		  else if ((opcodeWord & 0xFFC0BFul) == 0x060020ul)
			{
			/* REP x:/y:aa */
			addr = (unsigned short)((opcodeWord & 0x3F00ul) >> 8);
			if (opcodeWord & 0x40ul)
				{
				FindSymbol(eYSpace, (long)addr, ea_buf);	/* RBJ - added this */
				effAddr = 'y';
				}
			  else
			  	{
				FindSymbol(eXSpace, (long)addr, ea_buf);
				effAddr = 'x';
				}
			sprintf(operand_buf, "%c:<%s", effAddr, ea_buf);
			err = 1;
			}
		  else
			err = 0;
		}
	  else
		{
		/* DO instructions */
		sprintf(opcode_buf, "do");
		
		if ((opcodeWord & 0xFF00F0ul) == 0x060080ul)
			{
			/* D0 #xxx,expr */
			/* find immediate portion and put it into operand buf */
			imm = (unsigned short)((opcodeWord & 0x00FF00ul) >> 8);
			imm |= (unsigned short)((opcodeWord & 0xFul) << 8);
			sprintf(operand_buf, "#%hi,", imm);
			err = 2;
			}
		  else switch (opcodeWord & 0xFFC0FFul)
			{
			case 0x06C000ul:
				/* DO S,expr */
				/* decode the source register and put it into operand buf */
				effAddr = (unsigned char)((opcodeWord >> 8) & 0x3Ful);
				err = DecodeRegister(effAddr, reg_buf);
				if (err <= 0)
					return 0;
				sprintf(operand_buf, "%s,", reg_buf);
				err = 2;
				break;
			case 0x064000ul:
			case 0x064040ul:
				/* DO x:/y:ea,expr */
				memSpace = (opcodeWord & 0x40ul) ? eYSpace : eXSpace;	/* find if X: or Y: */
				effAddr = (opcodeWord & 0x003F00ul) >> 8;
				/* have to make sure absolute address or immediate data mode isn't specified */
				/*	since the extension word is needed for the loop address */
				if ((effAddr & 0x38) == 0x30)
					return 0;
				err = DecodeEffectiveAddress(memSpace, effAddr, extensionWord, ea_buf, kSrcOp);
				if (err <= 0)
					err = 0;				
				  else
					{
					sprintf(operand_buf, "%s,", ea_buf);
					err = 2;
					}
				break;
			case 0x060000ul:
			case 0x060040ul:
				/* DO x:/y:aa,expr */
				addr = (unsigned short)((opcodeWord & 0x003F00ul) >> 8);
				if (opcodeWord & 0x000040ul)		/* decode X: or Y: space */
					{
					FindSymbol(eYSpace, (long)addr, ea_buf);	/* RBJ - added this */
					space = 'y';
					}
				  else
				  	{
					FindSymbol(eXSpace, (long)addr, ea_buf);
					space = 'x';
					}
				sprintf(operand_buf, "%c:<%s,", space, ea_buf);
				err = 2;
				break;
			default:
				err = 0;
			}
		
		if (err > 0)
			{
			/* handle 'expr' portion of DO instructions	*/
			/* - second word of instruction contains the 16-bit loop ending address
				but the actual hardware address encoded is one less than what the
				 user specifies in the assembler -- so we massage the loop address
				 to look normal to the user
			*/
			/*  changed by RBJ
			sprintf(temp_buf, "$%4.4lX", extensionWord+1);
			*/		
			FindSymbol(ePSpace, extensionWord+1, temp_buf);
			strcat(operand_buf, temp_buf);
			}
		}
	return err;
	}

/*
	---------------------------------------------------------------------------
	np_movec
	---------------------------------------------------------------------------
	MOVEC instructions (and LUA) for moving data to/from control registers

	Formats:
		MOVEC	#xx,D1					0000 0101 iiii iiii 101d dddd
				X/Y:ea,D1 or S1,X/Y:ea	0000 0101 W1MM MRRR 0s1d dddd
				X/Y:aa,D1 or S1,X/Y:aa	0000 0101 W0aa aaaa 0s1d dddd
				S1,D2 or S2,D1			0000 0100 W1ee eeee 101d dddd
		LUA		ea,D					0000 0100 010M MRRR 0001 dddd
*/
int np_movec(unsigned long opcodeWord, unsigned long extensionWord)
	{
	unsigned char	regCode;
	int				memSpace;
	unsigned char	effAddr;
	unsigned short	imm;
	unsigned short	absAddr;
	int				err;
	int				src;
	
	/* stick "movec" into the opcode buffer */
	strcpy(opcode_buf, "movec");

	/* find the reg code first because it's always there */
	/* - actually uses the 6-bit encoding with bit 6 preset to 1 */
	regCode = (unsigned char)(opcodeWord & 0x1Ful) | (unsigned char)0x20;
	
	/* find out if the effective address field is the source or destination */
	src = (opcodeWord & 0x008000ul) ? kSrcOp : kDstOp;

	/* decode the oddball types first */
	if ((opcodeWord & 0xFF00E0ul) == 0x0500A0ul)
		{
		/* MOVEC #xx,D1 */
		regCode |= 0x20;		/* uses 6 bit dddddd encoding with high bit set */
		err = DecodeRegister(regCode, reg_buf);
		if (err <= 0)
			return 0;
		imm = (unsigned short)((opcodeWord & 0x00FF00ul) >> 8);
		sprintf(operand_buf, "#%hi,%s", imm, reg_buf);
		return 1;
		}	
	if ((opcodeWord & 0xFFE0F0ul) == 0x044010ul)
		{
		/* LUA instruction */
		/* - note: only allows address register update modes, no memory spaces needed */
		/* - note: we take care of the imm. data cases by specifying it as the destination */
		strcpy(opcode_buf, "lua");
		effAddr = (unsigned char)((opcodeWord & 0x3F00ul) >> 8);
		err = DecodeEffectiveAddress(eNullSpace, effAddr, extensionWord, ea_buf, kDstOp);
		if (err <= 0)
			return err;
		regCode = (unsigned char)(opcodeWord & 0x1Ful);
		err = DecodeRegister(regCode, reg_buf);
		if (err <= 0)
			return err;
		sprintf(operand_buf, "%s,%s", ea_buf, reg_buf);
		return err;	
		}
	
	/* decode the other types of movec */
	switch (opcodeWord & 0xFF40A0ul)
		{
		case 0x054020ul:
			/* movec X/Y:ea,D1 or S1,X/Y:ea */
			effAddr = (unsigned char)((opcodeWord & 0x3F00ul) >> 8);
			memSpace = (opcodeWord & 0x40ul) ? eYSpace : eXSpace;
			err = DecodeEffectiveAddress(memSpace, effAddr, extensionWord, ea_buf, src);
			if (err <= 0)
				return err;
			if (DecodeRegister(regCode, reg_buf) == 0)
				return 0;
			if (src == kSrcOp)	/* effAddr is source */
				sprintf(operand_buf, "%s,%s", ea_buf, reg_buf);
			  else
				sprintf(operand_buf, "%s,%s", reg_buf, ea_buf);
			return err;
		case 0x050060ul:
		case 0x050020ul:
			/* movec aa */
			absAddr = (unsigned short)((opcodeWord & 0x3F00ul) >> 8);
			if (opcodeWord & 0x40ul)
				{
				FindSymbol(eYSpace, (long)absAddr, ea_buf);	/* RBJ - added this */
				effAddr = 'y';
				}
			  else
			  	{
				FindSymbol(eXSpace, (long)absAddr, ea_buf);
				effAddr = 'x';
				}			
			/*
			effAddr = (opcodeWord & 0x40ul) ? 'y' : 'x';
			*/
			err = DecodeRegister(regCode, reg_buf);
			if (err <= 0)
				return err;
			if (src == kSrcOp)	/* effAddr is source */
				sprintf(operand_buf, "%c:<%s,%s", effAddr, ea_buf, reg_buf);
			  else
				sprintf(operand_buf, "%s,%c:<%s", reg_buf, effAddr, ea_buf);
			return err;
		}
	
	/* check for last type of movec */
	if ((opcodeWord & 0xFF40E0ul) == 0x0440A0ul)
		{
		/* S1/D1 uses 6 bit dddddd encoding with high bit set */
		regCode |= 0x20;
		
		/* get S2/D2 field - eeeeee encoding */
		effAddr = (unsigned char)((opcodeWord & 0x3F00ul) >> 8);
		
		/* decode the source and destination register encodings */
		err = DecodeRegister(regCode, reg_buf);
		if (err <= 0)
			return err;
		err = DecodeRegister(effAddr, ea_buf);
		if (err <= 0)
			return err;
			
		/* if bit 15 == 1, format is movec eeeeee,1ddddd */
		if (src == kSrcOp)
			sprintf(operand_buf, "%s,%s", ea_buf, reg_buf);		
		  else
			sprintf(operand_buf, "%s,%s", reg_buf, ea_buf);		
		return 1;
		}
	
	return 0;
	}

/*
	---------------------------------------------------------------------------
	np_xfer
	---------------------------------------------------------------------------
	Tcc instructions - they share a common decode for the first transfer but
						the second is decoded separately.

	Formats:
		Tcc	S1,D1	S2,D2		0000 0011 CCCC 0ttt 0JJJ DTTT
		Tcc	S1,D1				0000 0010 CCCC 0000 0JJJ D000
*/	
int np_xfer(unsigned long opcodeWord, unsigned long extensionWord)
	{
	unsigned long		sourceReg;
	unsigned long		destReg;
	unsigned short		S2,D2;
	
	/* first, get the condition code stuff common to both */
	sprintf(opcode_buf, "t%s", CCCC_decode[(opcodeWord & 0x00F000ul) >> 12]);
	
	/* second, get the encoding for the source register of the first transfer (JJJ field) */
	sourceReg = (opcodeWord & 0xF0ul) >> 4;		/* include bit 7 in the mask */
	
	/* third, get the encoding for the destination register of the first transfer (D field) */
	destReg = (opcodeWord & 0x8ul) >> 3;		
	
	/* make sure we have a good source register number */
	switch (sourceReg)
		{
		case 0:	/* special transfer: A,B or B,A - depends on D field */
		case 4:	/* X0,(A/B)		-- note: this does not obey the DD_decode[] matrix */
		case 6:	/* X1,(A/B)				 although it looks like it might. */
		case 5:	/* Y0,(A/B) */
		case 7:	/* Y1,(A/B) */
			break;
		default:
			/* bad case found for the JJJ field (possibly bit 7 was set which is not valid) */
			return 0;	
		}
	
	/* check for the special case */
	if (sourceReg == 0)
		{
		/* this is a special case that also depends on the D bit */
		/* - either A,B or B,A */
		if (destReg == 1)
			sprintf(operand_buf, "a,b ");		/* padded a space to make it the same as "y0,b" */
		  else
			sprintf(operand_buf, "b,a ");
		}
	  else	/* this is the normal case */
		{
		/* stick source register into the operand field using the e_encode[] */
		/*	and k_encode[] matrices. */
		/* - 3 bit encoding is [1 n Y/!X] */
		sourceReg &= 0x3ul;		/* get rid of top bit */
		if (sourceReg & 0x1)	/* it's a Yn operand */
			sprintf(operand_buf, "%s,", k_decode[sourceReg >> 1]);
		  else					/* it's an Xn operand */
			sprintf(operand_buf, "%s,", e_decode[sourceReg >> 1]);
	
		/* add the destination register to the operand field */
		strcat(operand_buf, d_decode[destReg]);	 	
		}
		
	/* only add the second transfer field if it's the right instruction */
	if ((opcodeWord & 0x0F0000ul) == 0x030000ul)
		{
		/* add extra field for second transfer (only Rn to Rn) */
		S2 = (unsigned short)((opcodeWord & 0xF00ul) >> 8);
		if (S2 > 7)		/* bit 11 == 1 is not valid */
			return 0;
		D2 = (unsigned short)(opcodeWord & 0x7ul);
		
		/* if the source and destination are the same, that's bad (?) ...  naw! */
/*
		if (S2 == D2)
			return 0;
*/

		/* now, put the second transfer field into the operand buffer */
		sprintf(temp_buf, "        r%hi,r%hi", S2, D2);
		strcat(operand_buf, temp_buf);
		}
	  else if ((opcodeWord & 0x0F87ul) != 0)	
		/* if it's the simpler form, bits [11..7,2..0] must be zero */
		return 0;
	return 1;
	}

/*
	---------------------------------------------------------------------------
	np_alu
	---------------------------------------------------------------------------
	non-parallel move ALU instructions

	Formats:
		NORM	Rn,D		0000 0001 1101 1RRR 0001 d101
		DIV		S,D			0000 0001 1000 0000 01JJ d000
		MAC		S,#n,D		0000 0001 000s ssss 11QQ dk10
		MACR	S,#n,D		0000 0001 000s ssss 11QQ dk11
		MPY		S,#n,D		0000 0001 000s ssss 11QQ dk00
		MPYR	S,#n,D		0000 0001 000s ssss 11QQ dk01		
*/
int np_alu(unsigned long opcodeWord, unsigned long extensionWord)
	{
	int				err = 1;
	unsigned char	d, reg;
	unsigned short	shiftConstant;
	
	/* check to see if it's a new Multiply instruction (56002+ only) */
	if ((opcodeWord & 0x00E000ul) == 0ul)
		{
		/* these opcodes only valid on 56002 chips and up */
		if (gDevice < DSP56002)
			return 0;
				
		/* decode MAC/MACR/MPY/MPYR part */
		switch (opcodeWord & 0xFFE0C3ul)
			{
			case 0x0100C2ul:
				/* MAC +/-S,#n,D */
				sprintf(opcode_buf, "mac");
				break;
			case 0x0100C3ul:
				/* MACR +/-S,#n,D */
				sprintf(opcode_buf, "macr");
				break;
			case 0x0100C0ul:
				/* MPY	+/-S,#n,D */
				sprintf(opcode_buf, "mpy");
				break;
			case 0x0100C1ul:
				/* MPYR	+/-S,#n,D */
				sprintf(opcode_buf, "mpyr");
				break;		
			default:
				return 0;
			}
		
		/* if necessary, insert a negative sign for the source operand */
		if (opcodeWord & 4ul)
			{
			operand_buf[0] = '-';
			operand_buf[1] = '\0';	
			}
		  else
			operand_buf[0] = '\0';
		
		/* find the source register (check out this oddball encoding!) */
		reg = (unsigned char)((opcodeWord & 0x30ul) >> 4);
		switch (reg)
			{
			case 0:
				strcat(operand_buf, "y1");
				break;
			case 1:
				strcat(operand_buf, "x0");
				break;
			case 2:
				strcat(operand_buf, "y0");
				break;
			case 3:
				strcat(operand_buf, "x1");
				break;		
			}
		
		/* find the shift constant common to all -- bits 12..8 */
		/* - can't be 0 or greater than 23 */
		shiftConstant = (unsigned short)((opcodeWord & 0x001F00ul) >> 8);
		if ((shiftConstant > 23) || (shiftConstant == 0))
			return 0;
		
		/* find the destination register */
		d = (unsigned char)((opcodeWord & 0x08ul) >> 3);				
		
		/* add the shift constant and the destination register */
		sprintf(temp_buf, ",#%hi,%s", shiftConstant, d_decode[d]);
		strcat(operand_buf, temp_buf);
		}
	  else if ((opcodeWord & 0xFFF8F7ul) == 0x01D815ul)
		{
		/* NORM		Rn,D */
		sprintf(opcode_buf, "norm");
		reg = (unsigned char)((opcodeWord & 0x700ul) >> 8);	/* get Rn number */
		sprintf(operand_buf, "r%i,%s", (int)reg, ((opcodeWord & 0x08ul) ? d_decode[1] : d_decode[0]));
		}
	  else if ((opcodeWord & 0xFFFFC7ul) == 0x018040ul)
		{
		/* DIV		S,D */
		sprintf(opcode_buf, "div");
		
		/* do stupid bit shifting and flipping so that this encoding maps to one of */
		/*	our decode arrays (DD) just because Motorola did it backwards... */
		reg = (unsigned char)(((opcodeWord & 0x20ul) >> 5) | ((opcodeWord & 0x10ul) >> 3));
		d = (unsigned char)((opcodeWord & 0x08ul) >> 3);	/* get acc A or B index */
		sprintf(operand_buf, "%s,%s", DD_decode[reg], d_decode[d]);
		}
	  else
		err = 0;
	
	return err;
	}

/*
	---------------------------------------------------------------------------
	np_unique
	---------------------------------------------------------------------------
	decode one of the unique opcodes by brute force
*/
#define ENDDO	((unsigned long)0x8C)
#define STOP	((unsigned long)0x87)
#define WAIT	((unsigned long)0x86)
#define RESET	((unsigned long)0x84)
#define RTS		((unsigned long)0x0C)
#define DECA	((unsigned long)0x0A)
#define DECB	((unsigned long)0x0B)
#define INCA	((unsigned long)0x08)
#define INCB	((unsigned long)0x09)
#define SWI		((unsigned long)0x06)
#define ILLEGAL	((unsigned long)0x05)
#define RTI		((unsigned long)0x04)
#define DEBUG	((unsigned long)0x0200)
#define DEBUGCC	((unsigned long)0x0300)

int np_unique(unsigned long opcodeWord, unsigned long extensionWord)
	{	
	/* 	
		All of this instructions are unique with no variable bit fields
		except DEBUGcc.  It is decoded with the CCCC_decode matrix.
		Note:	The DEBUG,INC, and DEC instructions only apply to
				56K Family members, not the 56001.
	*/
	int				err = 1;		/* if it works, it's always a one word instruction */
	unsigned char	imm;
	
	/* null the operand buf in case it's not used */
	operand_buf[0] = '\0';
	
	switch (opcodeWord)
		{
		case ENDDO:
			sprintf(opcode_buf, "enddo");
			break;
		case STOP:
			sprintf(opcode_buf, "stop");
			break;
		case WAIT:
			sprintf(opcode_buf, "wait");
			break;
		case RESET:
			sprintf(opcode_buf, "reset");
			break;
		case RTS:
			sprintf(opcode_buf, "rts");
			break;
		case DECA:
		case DECB:
			if (gDevice > DSP56001)
				{
				sprintf(opcode_buf, "dec");
				sprintf(operand_buf, "%s", d_decode[(opcodeWord & 0x1)]);
				}
			  else
				err = 0;
			break;
		case INCA:
		case INCB:
			if (gDevice > DSP56001)
				{
				sprintf(opcode_buf, "inc");
				sprintf(operand_buf, "%s", d_decode[(opcodeWord & 0x1)]);
				}
			  else
				err = 0;
			break;
		case SWI:
			sprintf(opcode_buf, "swi");
			break;
		case ILLEGAL:
			sprintf(opcode_buf, "illegal");
			break;
		case RTI:
			sprintf(opcode_buf, "rti");
			break;
		case DEBUG:
			if (gDevice > DSP56001)
				sprintf(opcode_buf, "debug");
			  else
				err = 0;
			break;
		default:	/* special cases */
			if ((opcodeWord & 0xFFFFF0ul) == DEBUGCC)
				{
				/* DEBUGcc instruction */
				if (gDevice > DSP56001)
					sprintf(opcode_buf, "debug%s", CCCC_decode[(opcodeWord & 0x0Ful)]);
				  else
					err = 0;
				}
			  else if (((opcodeWord & 0xFF00FCul) == 0x0000F8ul) ||
					((opcodeWord & 0xFF00FCul) == 0x0000B8ul))
				{
				/* ORI instruction or ANDI instruction which share common portions */
				if (opcodeWord & 0x40ul)
					sprintf(opcode_buf, "ori");
				  else
					sprintf(opcode_buf, "andi");
					
				/* find the immediate data portion */
				imm = (unsigned char)((opcodeWord & 0x00FF00ul) >> 8);
				sprintf(operand_buf, "#$%hX,", (unsigned short)imm);
				
				/* find the destination register */
				switch (opcodeWord & 0x3ul)
					{	
					case 0:
						strcat(operand_buf, "mr");
						break;
					case 1:
						strcat(operand_buf, "ccr");
						break;
					case 2:
						strcat(operand_buf, "omr");
						break;			
					default:		/* case 3 is not allowed */
						err = 0;
						break;
					}
				}
			  else
				err = 0;
			break;
		}
		
	return err;
	} /* end np_unique() */

/*
	---------------------------------------------------------------------------
	DecodeEffectiveAddress
	---------------------------------------------------------------------------
	decode the effective address specified by the extension word, memory space
	and the effective address code (MMMRRR), place the result in the outAddrBuf.
*/
int DecodeEffectiveAddress(int memSpace, unsigned char effAddrCode,
							unsigned long extensionWord, char *outAddrBuf, int src)	
	{
	int				err = 0;
	unsigned char	rrr = 0;
		/* for the memory space attribute, we use "X/Y/L/P:" or "" */
	unsigned char	space[] = 	{' ', ':', '\0'	};
	char			scratch[30];
	
	/* make sure the output buffer is okay */
	if (outAddrBuf == NULL)
		return -1;
	outAddrBuf[0] = '\0';
	
	/* only look at lowest 7 bits */
	effAddrCode &= 0x3F;

	/* get rrr bits */
	rrr = (unsigned short)(effAddrCode & 0x7);

	/* find the memory space character */
	if(memSpace == eXSpace)
		space[0] = 'x';
	  else if (memSpace == eYSpace)
		space[0] = 'y';
	  else if (memSpace == eLSpace)
		space[0] = 'l';
	  else if (memSpace == ePSpace)
		space[0] = 'p';
	  else
		space[0] = '\0';	/* no memory space attribute for this address */
		
	/* decode the address mode */
	if (effAddrCode & 0x20)
		{
		/* non post update modes */
		if ((effAddrCode & 0x38) == 0x30)
			{
			/* abs addr or imm data */
			if ((effAddrCode & 0x3) != 0)
				return 0;				/* LS 2 bits must be zero */
				
			if (effAddrCode & 0x4)
				{
				/* immediate data cannot be the destination */
				if (src == kDstOp)
					return 0;
				/*  changed by RBJ
				sprintf(outAddrBuf, "#>$%lX", extensionWord);
				*/
				FindSymbol(eNullSpace, extensionWord, scratch);
				sprintf(outAddrBuf, "#>%s", scratch);
				}
			  else
				{
				/* find symbol for absolute address and use it instead of a number - changed by RBJ */
				FindSymbol(memSpace, extensionWord, scratch);
				/* don't print out the '>' if it's a null space address (like a jmp $xxxx) */
				if (memSpace == eNullSpace)
					sprintf(outAddrBuf, "%s", scratch);
				  else
					sprintf(outAddrBuf, "%s>%s", space, scratch);
				}
			err = 2;	/* used "both" words -  moved here by RBJ */
			}	
		  else
			{	
			/* find no update, indexed + N, Pre-1 */
			err = 1;
			switch(effAddrCode & 0x18)
				{
				/* the 'space' buffer contains the memory space indicator (X/Y/L and a ':') */
				/*	unless there is no memory space attribute in which case the 'space' */
				/*	buffer is a null string and it's just an address register update	*/
				case 0x00:
					/* no update */
					sprintf(outAddrBuf, "%s(r%hi)", space, rrr);
					break;
				case 0x08:
					/* indexed + N */
					sprintf(outAddrBuf, "%s(r%hi+n%hi)", space, rrr, rrr);
					break;
				case 0x18:
					/* predecrement by 1 */
					sprintf(outAddrBuf, "%s-(r%hi)", space, rrr);
					break;
				default:
					err = 0;
					break;	
				}
			}
		}
	  else
		{	
		/* all post update modes */
		sprintf(outAddrBuf, "%s(r%hi)%c", space, rrr, (effAddrCode & 0x8)?'+':'-');
		if ( !(effAddrCode & 0x10) )
			{
			sprintf(scratch, "n%hi", rrr);		/* RBJ - changed 'r%hi' to 'n%hi' */
			strcat(outAddrBuf, scratch);
			}
		err = 1;
		}
	
	return err;
	}

/*
	---------------------------------------------------------------------------
	DecodeRegister
	---------------------------------------------------------------------------
	Decode one of the 43 on-chip registers [dddddd or DDDDDD encodings]
	using 6 bit encoding of Table A-21 on p. A-314.
*/
int DecodeRegister(unsigned char regCode, char *outRegBuf)
	{
	int				err = 1;
	unsigned char	grpCode;
	unsigned char	aguPrefix;
	
	/* check for the first reserved case -- [0000dd] is invalid */
	if ((regCode & 0x3C) == 0x0)
		return 0;
		
	/* now, decode the registers by grouping */
	grpCode = (regCode & 0x38) >> 3;
	regCode &= 0x7;							/* keep low order 3 bits of original code */
	switch (grpCode)
		{
		case 0x0:
			/* DD Data ALU register */
			sprintf(outRegBuf, "%s", DD_decode[regCode & 0x3]);	/* only need LS 2 bits */
			break;
		case 0x1:
			/* DDD Data ALU register */
			sprintf(outRegBuf, "%s", DDD_decode[regCode]);
			break;
		case 0x2:
			/* TTT Address ALU register (Rn) */
			aguPrefix = 'r';
			goto FinishAGUReg;
		case 0x3:
			/* NNN Address Offset register (Nn) */
			aguPrefix = 'n';							/* RBJ - changed 'r' to 'n' */
			goto FinishAGUReg;
		case 0x4:
			/* FFF Address Modifier register (Mn) */
			aguPrefix = 'm';
FinishAGUReg:			
			sprintf(outRegBuf, "%c%hi", aguPrefix, (unsigned short)regCode);
			break;
		case 0x7:
			/* Program controller register ([000] is not valid) */
			if (regCode != 0)
				sprintf(outRegBuf, "%s", GGG_decode[regCode]);
			  else
				err = 0;
			break;
		default:		/* groups 5 & 6 are reserved */
			err = 0;
			break;	
		}
	
	return err;
	}

/*
	---------------------------------------------------------------------------
	DecodeRegisterALU
	---------------------------------------------------------------------------
	get register for ddddd 5 bit encoding
	- see 'ddddd' coding on A-314, Table A-20
*/
int DecodeRegisterALU(unsigned char ddddd, char *outRegBuf)
	{	
	unsigned char one = ddddd & 0x1;
	unsigned char two = ddddd & 0x2;
	
	/* check for bad output buffer */
	if (outRegBuf == NULL)
		return 0;
	
	switch(ddddd >> 2)
		{
		case 0x0:
			return 0;	/* ddddd = '000xx' illegal */
		case 0x1:
			if (two)
				outRegBuf[0] = 'y';
			  else
				outRegBuf[0] = 'x';
			if (one)
				outRegBuf[1] = '1';
			  else
				outRegBuf[1] = '0';
			break;
		case 0x2:
			if (one)
				outRegBuf[0] = 'b';
			  else
				outRegBuf[0] = 'a';
			if (two)
				outRegBuf[1] = '2';
			  else
				outRegBuf[1] = '0';
			break;
		case 0x3:
			if (one)
				outRegBuf[0] = 'b';
			  else
				outRegBuf[0] = 'a';
			if (two)
				outRegBuf[1] = '\0';
			  else
				outRegBuf[1] = '1';
			break;
		default:
			if (ddddd & 0x8)
				outRegBuf[0] = 'n';
			  else
				outRegBuf[0] = 'r';
			outRegBuf[1] = (unsigned char)((ddddd & 7) + 0x30);	/* ASCII offset */
			break;
		}
	
	outRegBuf[2]='\0';	/* in case calling routine wants a string */

	return 1;
	} /* end DecodeRegisterALU() */

/*
	Change History (most recent first):
		
		<25>	 8/18/98	RBJ		Fixed a an unbalanced comment delimiter in DecodeParallel.
		<24>	 7/18/96	RBJ		Fixed a little bug in np_bit.
		<23>	 3/28/96	RBJ		Fixed a little bug in DecodeRegister.
		<22>	 3/27/96	RBJ		Fixed a little bug in DecodeEffectiveAddress.
		<21>	 11/16/95	RBJ		Simplified some X:Y: parallel move decoding and aligned
									Y: move field to right column (for Y: only move).
		<20>	 8/29/95	RBJ		LAST KNOWN BUG!  The src and dst of the movec Mm,Mn was switched.
		<19>	 8/29/95	RBJ		Fixed (easy) big bug.  In X:Y: move, a,b, was switched
									y0,y1.  OUTPUT NOW ASSEMBLES WITH NO ERRORS!!
		<18>	 8/28/95	RBJ		Fixed little bug.  'move (Rn)+Rn' to '(Rn)+Nn'
		<17>	 8/27/95	RBJ		Made mucho improvements, fractional immediate moves to
									x0, x1, y0, y1, a, b.  Call FindSymbol more to resolve
									jmp, jcc, jsr, do, move #..,Rn, (etc) destination address.  Put in
									'>' and '<' for known long and short immediate addressing.																									
		<16>	 8/26/95	RBJ		Changed all register names and 'DEBUG' to small case.  Modified
									kPMovePos, kMinSpacing, and kPMoveSpacing so that
									columns were nicely aligned.
		<15>	 6/23/95	SAD		Fix periph space flipping in np_movep().  Massage do loop end
									address to conform with assembler. Add error checking in
									p_move(). Remove ASCII fix junk.
		<14>	 6/18/95	SAD		Fix bugs in np_movec().  Add copyright stuff.
		<13>	 4/16/95	SAD		Remove debug statements, fix bugs. Add peripheral space symbol
									lookup. Change enums to ints. Remove extra params.
		<12>	 2/28/95	SAD		Fix np_movem(), np_bit().  Change all memory spaces to lower
									case.
		<11>	 2/24/95	SAD		Add formatting code.  Finish np_movec().
		<10>	 2/19/95	SAD		Remove C++ style comments. Ugh.
		 <9>	 2/14/95	SAD		Add checks for empty operand/pmove fields for better formatting
									of the output. Fix bugs in single operand p_non_mults(). Fix
									DIV, NORM, REP #xxx, DO #xxx/ea/aa/S, and various other bugs.
		 <8>	 1/13/95	SAD		Minor fixes in DecodeParallel(). Fix many bugs in np_xfer().
									Add bit field formats under function comments.
		 <7>	12/18/94	SAD		Finished np_bit().  Fixed DecodeEffectiveAddress() for
									post-update modes.  Cleaned up some stuff and a few bugs.
		 <6>	12/16/94	SAD		Finished np_movec().  Added np_movep().
		<5+>	11/23/94	SAD		Change DecodeEffectiveAddress() to use enum memory space
									and add source/destination parameter for proper decode.
		 <5>	11/20/94	SAD		More stuff in np_bit().  Still broken.
		 <4>	10/31/94	SAD		Added np_bit().
		 <3>	10/24/94	SAD		Changed p_get_ddddd() to DecodeRegisterALU().  Fixed bugs in
									np_unique(). Added LUA case in np_movec().
		 <2>	10/24/94	SAD		Added np_movem(), changed all opcodes to lower case (except
									DEBUG).  Added np_jumps().
		 <1>	10/17/94	SAD		Added np_alu(), np_loops(), DecodeRegister(),
									finished np_unique() for ORI, ANDI, DEBUGcc cases.
		 <0>	 10/1/94	SAD		Created from sketches.
*/


