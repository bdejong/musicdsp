/****************************************************************************************
*																						*
*			fiji.c																		*
*																						*
*			Scans ####.lod files from the Motorola DSP56000CLASA 						*
*			development system and loads any boot code into the							*
*			Turtle Beach Fiji board.													*
*																						*
*			Also provides host port communications ultilities:							*
*				boot_dsp()																*
*				load_dsp_application()													*
*				set_dsp_write_ptr()														*
*				set_dsp_read_ptr()														*
*				write_dsp_data()														*
*				read_dsp_data()															*
*																						*
*																						*
*																						*
****************************************************************************************/


#include "fiji.h"
#include "util56k.h"


#ifdef HASH_BY_NAME
symbol_entry symbol_hash_by_name_table[SYMBOL_TABLE_SIZE];
#endif
symbol_entry symbol_hash_by_addr_table[SYMBOL_TABLE_SIZE][(eNullSpace+1)];

char *symbol_names = NULL;
int symbol_names_index = 0;

int fiji_io_address = 0x290;
int dsp_read_enable = 0, dsp_write_enable = 0, bootflag = 0;

FILE *errOut = stderr;

/* Re-direct error messages */

void redirect_dsp_err(FILE *newErrOut)
	{
	errOut = newErrOut;
	}

void fiji_set_io_address(int newAddress)
	{
	fiji_io_address = newAddress;
	}


int host_command(register unsigned int cmd)
	{
	register long timeout;
	register int CVR;

	for (timeout=0; timeout<1000; timeout++)
		;

	CVR = cmd + HC;

	outp(cvrRegister, CVR);

	CVR = inp(cvrRegister);
	timeout = 100000L;
	while (timeout > 0 && (CVR&HC) != 0)
		{
		CVR = inp(cvrRegister);
		timeout--;
		}
	if (timeout == 0)
		{
		(void) fprintf(errOut, "DSP_HC_TIMEOUT\n");
		return DSP_HC_TIMEOUT;
		}

	for (timeout=0; timeout<1000; timeout++)
		;

	return 0;
	}


int set_dsp_read_write_ptr(register long mode_plus_ptr)
	{
	register long timeout;
	register int CVR, ISR;

	if (mode_plus_ptr >= 0 && bootflag != 0)
		{
		ISR = inp(isrRegister);
		timeout = 100000L;
		while ((timeout > 0) && (((ISR)&(TXDE+TRDY)) != (TXDE+TRDY)))
			{
			ISR = inp(isrRegister);
			timeout--;
			}
		if (timeout == 0)
			{
			(void) fprintf(errOut, "DSP_WRITE_TIMEOUT 0\n");
			return DSP_WRITE_TIMEOUT;
			}

		for (timeout=0; timeout<1000; timeout++)
			;

		CVR = (SET_PTR_HOST_CMD+HC);
		outp(cvrRegister, CVR);

		CVR = inp(cvrRegister);
		timeout = 100000L;
		while (timeout > 0 && (CVR&HC) != 0)
			{
			CVR = inp(cvrRegister);
			timeout--;
			}
		if (timeout == 0)
			{
			(void) fprintf(errOut, "DSP_HC_TIMEOUT 0\n");
			return DSP_HC_TIMEOUT;
			}

		for (timeout=0; timeout<1000; timeout++)
			;
		ISR = inp(isrRegister);
		timeout = 100000L;
		while ((timeout > 0) && (((ISR)&(TXDE+TRDY)) != (TXDE+TRDY)))
			{
			ISR = inp(isrRegister);
			timeout--;
			}
		if (timeout == 0)
			{
			(void) fprintf(errOut, "DSP_WRITE_TIMEOUT 1\n");
			return DSP_WRITE_TIMEOUT;
			}

		outp(txhRegister, (int)(mode_plus_ptr>>16));
		outp(txmRegister, (int)(mode_plus_ptr>>8));
		outp(txlRegister, (int)(mode_plus_ptr));

		if (!(mode_plus_ptr & WRITE_DSP))
			{
			ISR = inp(isrRegister);
			timeout = 100000L;
			while ((timeout > 0) && (((ISR)&(RXDF+HF3)) != (RXDF+HF3)))
				{
				ISR = inp(isrRegister);
				timeout--;
				}
			if (timeout == 0)
				{
				(void) fprintf(errOut, "DSP_READ_TIMEOUT 0\n");
				return DSP_READ_TIMEOUT;
				}
			for (timeout=0; timeout<1000; timeout++)
				;
			ISR = inp(rxlRegister);			/*  dummy read to clear out buffer.  next word is good. */
			dsp_write_enable = 0;
			dsp_read_enable = 1;
			}
		 else
			{
			dsp_write_enable = 1;
			dsp_read_enable = 0;
			}
		return 0;
		}
	  else
		{
		dsp_write_enable = 0;
		dsp_read_enable = 0;
		(void) fprintf(errOut, "improper DSP r/w address: $%08lx\n", mode_plus_ptr);
		return DSP_ADDRESS_ERROR;
		}
	}


int write_dsp_data(register long data)
	{
	register long timeout;
	register int ISR;

	if (!dsp_write_enable)
		{
		(void) fprintf(errOut, "DSP_WRITE_ENABLE_ERROR\n");
		return DSP_WRITE_ENABLE_ERROR;
		}

	ISR = inp(isrRegister);
	timeout = 100000L;
	while ((timeout > 0) && (((ISR)&(TXDE+TRDY)) != (TXDE+TRDY)))
		{
		ISR = inp(isrRegister);
		timeout--;
		}
	if (timeout == 0)
		{
		(void) fprintf(errOut, "DSP_WRITE_TIMEOUT\n");
		return DSP_WRITE_TIMEOUT;
		}

	outp(txhRegister, (int)(data>>16));
	outp(txmRegister, (int)(data>>8));
	outp(txlRegister, (int)(data));

	return 0;
	}


int read_dsp_data(long *data_ptr)
	{
	register long timeout, data;
	register int ISR;

	if (!dsp_read_enable)
		{
		(void) fprintf(errOut, "DSP_READ_ENABLE_ERROR\n");
		return DSP_READ_ENABLE_ERROR;
		}

	ISR = inp(isrRegister);
	timeout = 100000L;
	while ((timeout > 0) && (((ISR)&(RXDF+HF3)) != (RXDF+HF3)))
		{
		ISR = inp(isrRegister);
		timeout--;
		}
	if (timeout == 0)
		 {
		 (void) fprintf(errOut, "DSP_READ_TIMEOUT\n");
		 return DSP_READ_TIMEOUT;
		 }

	data = (long)inp(rxhRegister);
	data <<= 8;
	data += (long)inp(rxmRegister);
	data <<= 8;
	data += (long)inp(rxlRegister);

	if (data < 0x00800000L)
		*data_ptr = data;
	  else
		*data_ptr = data - 0x01000000L;		/* sign extend a negative number */

	return 0;
	}


long hash_symbol(char *symbol_name)
	{
	register int i, hash;

	hash = 0;
	i = 0;
	while (symbol_name[i]!='\0')
		{
		hash += (int)(symbol_name[i++]);
		}
	hash &= (SYMBOL_TABLE_SIZE-1);
	i = 0;
	while ( (symbol_hash_by_name_table[hash].address<0 || strcmp(symbol_hash_by_name_table[hash].name, symbol_name)!=0) && i<SYMBOL_TABLE_SIZE )
		{
		hash++;
		hash &= (SYMBOL_TABLE_SIZE-1);
		i++;
		}
	if (i < SYMBOL_TABLE_SIZE)
		{
		return (symbol_hash_by_name_table[hash].address)&0x00FFFFFFL;
		}
	  else
		{
		(void) fprintf (errOut, "label '%s' not found. \n", symbol_name);
		return (long)HASH_SYMBOL_ERROR;
		}
	}


int get_at_label(char *symbol_name, int offset)
	{
	long dsp_address;

	dsp_address = hash_symbol(symbol_name);
	if (dsp_address >= 0)
		{
		return set_dsp_read_write_ptr(READ_DSP + dsp_address + (long)offset);
		}
	 else
		{
		dsp_write_enable = 0;
		dsp_read_enable = 0;
		return (int)dsp_address;
		}
	}


int put_at_label(char *symbol_name, int offset)
	{
	long dsp_address;

	dsp_address = hash_symbol(symbol_name);
	if (dsp_address >= 0)
		{
		return set_dsp_read_write_ptr(WRITE_DSP + dsp_address + (long)offset);
		}
	 else
		{
		dsp_write_enable = 0;
		dsp_read_enable = 0;
		return (int)dsp_address;
		}
	}


long get_long(void)
	{
	long value = 0;
	(void) read_dsp_data(&value);
	return value;
	}


long read_long(char *symbol_name)
	{
	long value = 0;
	(void) get_at_label(symbol_name, 0);
	(void) read_dsp_data(&value);
	return value;
	}


void write_long(char *symbol_name, long value)
	{
	(void) put_at_label(symbol_name, 0);
	(void) put_long(value);
	}


double get_double(void)
	{
	long value = 0;
	(void) read_dsp_data(&value);
	return (double)value*(1.0/8388608.0);
	}


void put_double(double value)
	{
	if (value > 0.99999988079071)
		value = 0.99999988079071;
	  else if (value < -1.0)
		value = -1.0;
	(void) write_dsp_data( (long)floor(8388608.0*value + 0.5) );
	}


double read_double(char *symbol_name)
	{
	long value;
	(void) get_at_label(symbol_name, 0);
	(void) read_dsp_data(&value);
	return (double)value*(1.0/8388608.0);
	}


void write_double(char *symbol_name, double value)
	{
	(void) put_at_label(symbol_name, 0);
	if (value > 0.99999988079071)
		value = 0.99999988079071;
	  else if (value < -1.0)
		value = -1.0;
	(void) write_dsp_data( (long)floor(8388608.0*value + 0.5) );
	}



void set_mic_pot_gain(double dBr_left, double dBr_right)
	{
	long left_level, right_level;

	if (bootflag)
		{
		left_level  =  (long)floor(2.0*dBr_left + 180.5);
		if ( left_level < 0)
			left_level = 0;
		if ( left_level > 255)
			left_level = 255;
		right_level  =  (long)floor(2.0*dBr_right + 180.5);
		if (right_level < 0)
			right_level = 0;
		if (right_level > 255)
			right_level = 255;
		(void)set_dsp_read_write_ptr(READ_DSP);  /* NOP out DSP read from host */

		dsp_write_enable = 1;
		(void) write_dsp_data( (left_level<<16) + (right_level<<8) );
		dsp_write_enable = 0;

		(void) host_command(SET_MIC_GAIN_HOST_CMD);
		}
	}

void set_input_pot_gain(double dBr_left, double dBr_right)
	{
	long left_level, right_level;

	if (bootflag)
		{
		left_level  =  (long)floor(2.0*dBr_left + 180.5);
		if ( left_level < 0)
			left_level = 0;
		if ( left_level > 255)
			left_level = 255;
		right_level  =  (long)floor(2.0*dBr_right + 180.5);
		if (right_level < 0)
			right_level = 0;
		if (right_level > 255)
			right_level = 255;
		(void)set_dsp_read_write_ptr(READ_DSP);  /* NOP out DSP read from host */

		dsp_write_enable = 1;
		(void) write_dsp_data( (left_level<<16) + (right_level<<8) );
		dsp_write_enable = 0;

		(void) host_command(SET_INPUT_GAIN_HOST_CMD);
		}
	}

void set_aux_pot_gain(double dBr_left, double dBr_right)
	{
	long left_level, right_level;

	if (bootflag)
		{
		left_level  =  (long)floor(2.0*dBr_left + 180.5);
		if ( left_level < 0)
			left_level = 0;
		if ( left_level > 255)
			left_level = 255;
		right_level  =  (long)floor(2.0*dBr_right + 180.5);
		if (right_level < 0)
			right_level = 0;
		if (right_level > 255)
			right_level = 255;
		(void)set_dsp_read_write_ptr(READ_DSP);  /* NOP out DSP read from host */

		dsp_write_enable = 1;
		(void) write_dsp_data( (left_level<<16) + (right_level<<8) );
		dsp_write_enable = 0;

		(void) host_command(SET_AUX_GAIN_HOST_CMD);
		}
	}

void set_analog_input(void)
	{
	host_command(SET_ANALOG_IN_HOST_CMD);
	}

void set_digital_input(void)
	{
	host_command(SET_DIGITAL_IN_HOST_CMD);
	}

double sample_rate(void)
	{
	long inst_per_chunk = 1814L; 	/* default to 44100.0 */
	double samp_rate = 44100.0;

	(void) set_dsp_read_ptr(X, chunk_period);
	(void) read_dsp_data(&inst_per_chunk);
	samp_rate = (double)(1L<<(2*(int)CHUNK_SIZE+3))*CHUNK_SIZE*MIPS/(double)inst_per_chunk;
	return samp_rate;
	}

void set_sample_rate(double samp_rate)
	{
	long sr_reg = 0;
	if (samp_rate > 46050.0  && samp_rate < 54000.0)
		{
		sr_reg = sr48kHz;
		}
	if (samp_rate > 38050.0)
		{
		sr_reg = sr44kHz;
		}
	if (samp_rate > 28000.0)
		{
		sr_reg = sr32kHz;
		}
	if (samp_rate > 23000.0)
		{
		sr_reg = sr24kHz;
		}
	if (samp_rate > 19025.0)
		{
		sr_reg = sr22kHz;
		}
	if (samp_rate > 14000.0)
		{
		sr_reg = sr16kHz;
		}
	if (samp_rate > 11512.5)
		{
		sr_reg = sr12kHz;
		}
	if (samp_rate > 9512.5)
		{
		sr_reg = sr11kHz;
		}
	if (samp_rate > 7000.0)
		{
		sr_reg = sr08kHz;
		}
	if (samp_rate > 5756.25)
		{
		sr_reg = sr06kHz;
		}
	if (samp_rate > 5000.0)
		{
		sr_reg = sr05kHz;
		}

	if (sr_reg > 0)
		{
		set_dsp_write_ptr(Y, INT_SR_REGISTER);
		write_dsp_data(sr_reg);
		}
	}





#define NEELY_CODE 0

#if NEELY_CODE

#define _getch  getch
#define _inp    inp
#define _kbhit  kbhit
#define _outp   outp

/*
	the code immediately following came from Stephan T. Neely
*/
#define MSND_PAGE   0xD000          /* shared memory area */
#define MSND_PORT   0x290           /* DSP host base port */
#define MSND_CFGP   0x260           /* configuration port (set on card) */

/* the first 8 MSND I/O registers contain the DSP host interface (HI) */
#define MSND_ICR    0x0     /* HI interrupt control register (R/W) */
#define MSND_CVR    0x1     /* HI command vector (R/W) */
#define MSND_ISR    0x2     /* HI interrupt status register (RO) */
#define MSND_IVR    0x3     /* HI interrupt vector register (R/W) */
#define MSND_ZER    0x4     /*    byte of zero (RO) */
#define MSND_DAH    0x5     /* HI Tx/Rx data high */
#define MSND_DAM    0x6     /* HI Tx/Rx data middle */
#define MSND_DAL    0x7     /* HI Tx/Rx data low */

/* the next 4 MSND I/O registers contain Bus Ctrl. and Board Info */
#define MSND_DSPR   0x4     /* DSP reset control register (WO) */

static unsigned int cfgp = MSND_CFGP;
static unsigned int port = MSND_PORT;
static unsigned int page = MSND_PAGE;
static struct {int act, ad0, ad1, irq, ram;} res[5];

void wrcfg(int a, int v)
{
	_outp(cfgp, a);
	_outp(cfgp + 1, v);
}

int config_dsp()
{
	wrcfg(0x07, 0);
	wrcfg(0x60, res[0].ad0 >> 8);
	wrcfg(0x61, res[0].ad0 & 0xFF);

	wrcfg(0x07, 0);
	wrcfg(0x62, res[0].ad1 >> 8);
	wrcfg(0x63, res[0].ad1 & 0xFF);

	wrcfg(0x07, 0);
    wrcfg(0x70, res[0].irq >> 8);
	wrcfg(0x71, res[0].irq & 0xFF);

    wrcfg(0x07, 0);
	wrcfg(0x40, res[0].ram >> 8);
    wrcfg(0x41, res[0].ram & 0xFF);
    wrcfg(0x42, 3);

    wrcfg(0x07, 0);
    wrcfg(0x30, res[0].act);

    return (0);
}

int reset_dsp()
{
	int time_out = 20000;

	_outp(port + MSND_DSPR, 0);  /* turn DSP reset on */
	_outp(port + MSND_DSPR, 2);  /* turn DSP reset off */
	while(time_out-- >= 0) {
		if (_inp(port + MSND_CVR) == 0x12)
			return (1);
	}
	return (0);
}

int init_dsp()
{

	if (config_dsp())				// we'll use the config register only if we need to
		return (1);					//  otherwise, just find out at what address Windows put the Fiji Digital Audio port

	if (!reset_dsp())
    	return (2);
}
#endif






/*
 *	Boot DSP from .lod file
 */
int boot_dsp(char *fileName)
	{
	FILE *input;
	long input_size;
	char *input_buffer;

	if (strcmp( fileName+(strlen(fileName)-4), ".lod") != 0)
		{
		(void) fprintf(errOut, "boot file, %s, is not .lod . \n", fileName);
		return(FILE_ERROR);
		}

	if ((input_buffer = (char *)malloc(10001)) == NULL)
		{
		(void) fprintf(errOut, "boot_dsp() malloc error.\n");
		return(MALLOC_ERROR);
		}

	if ((input = fopen(fileName, "r")) == NULL)
		{
		(void) fprintf(errOut, "unable to open DSP boot file: %s\n", fileName);
		return(FILE_ERROR);
		}

	input_size = fread(input_buffer, 1, 10000, input);

	fclose(input);

	if ( input_size> 0)
		{
		upload_bootcode(input_buffer,input_size);
		}
	 else
		{
		(void) fprintf (errOut, "Error reading boot file. \n");
		return(FILE_ERROR);
		}

	free(input_buffer);
	return(0);
	}


/*
 *	Parse boot code in memory and upload into processor
 */
int upload_bootcode(char *input_buffer, long input_size)
	{
	long op;
	unsigned long pc;
	register int i;
	register char *input_ptr;
	char *buffer_end, op_str[8];
	long bootcode[512];
	char mode;
	int err;


	op_str[6] = '\0';
	dsp_read_enable = 0;
	dsp_write_enable = 0;
	bootflag = 0;

	for (i=0; i<512; i++)
		{
		bootcode[i] = NOP;
		}

	input_ptr = input_buffer;
	buffer_end = input_buffer + (int)input_size;
	mode = OTHER;

	while (input_ptr<buffer_end && isspace(*input_ptr))
		input_ptr++;

	while (input_ptr < buffer_end)
		{
		
		if (*input_ptr == '_')
			{
			if (strncmp(input_ptr, "_DATA P", 7) == 0)
				{
				input_ptr += 7;
				while (input_ptr<buffer_end && isspace(*input_ptr))
					input_ptr++;
				sscanf(input_ptr, "%4lx", &pc);
				
				if (pc == 0)
					bootflag = 1;
				
				mode = 'P';
				}
			  else
				mode = OTHER;
				
			while (input_ptr<buffer_end && *input_ptr!='\n')
				input_ptr++;
			while (input_ptr<buffer_end && isspace(*input_ptr))
				input_ptr++;
			}

		switch (mode)
			{
			case OTHER:
				while ( input_ptr<buffer_end && (*input_ptr!='_' || *(input_ptr-1)!='\n') )
					input_ptr++;
				break;
			
			case 'P':
				for (i=0; i<6; i++)
					op_str[i] = *input_ptr++;

				sscanf(op_str, "%6lx", &op);

				while (input_ptr<buffer_end && isspace(*input_ptr))
					input_ptr++;
				
				if (pc < 0x200)
					bootcode[(int)(pc++)] = op;
				break;
			}
		
		while (input_ptr<buffer_end && isspace(*input_ptr))
			input_ptr++;
		}

	/* Create symbol table */

	err = init_symbol_table();
	if (err != 0) return(err);

	/* Boot the DSP */

	if (bootflag)
		{
	    int status;
#if NEELY_CODE
		init_dsp();
#else
		outp(resetRegister, DSPRESET_ON);		/* reset 56K */
		for (i=0; i<2000; i++)
			;									/* wait one tick */
		outp(resetRegister, DSPRESET_OFF);
		for (i=0; (i<20000 && inp(cvrRegister)!=0x12); i++)
			;
		if (inp(cvrRegister)!=0x12)
			{
			return (DSP_HC_TIMEOUT);
			}

#endif

		dsp_write_enable = 1;
		for (i=0; i<512; i++)	/* load program */
			{
			err = write_dsp_data(bootcode[i]);
			if (err != 0)
				{
				(void) fprintf (errOut, "Error writing to DSP while booting. \n");
				dsp_write_enable = 0;
				bootflag = 0;
				return(err);
				}
			}
		dsp_write_enable = 0;
		}

	return(0);
	}


/*
 *
 *	Upload a DSP application directly from a .lod file.
 *
 */
int load_dsp_application(char *app_file)
	{
	FILE *input;
	long input_size;
	char *input_buffer;
	
	if (strcmp( app_file+(strlen(app_file)-4), ".lod") != 0)
		{
		(void) fprintf(errOut, "application file, %s, is not .lod . \n", app_file);
		return(FILE_ERROR);
		}
	
	if ((input_buffer = (char *)malloc(32767)) == NULL)
		{
		(void) fprintf(errOut, "load_dsp_application() malloc error.\n");
		return(MALLOC_ERROR);
		}

	if ((input = fopen(app_file, "r")) == NULL)
		{
		(void) fprintf(errOut, "unable to open application file: %s \n", app_file);
		return(FILE_ERROR);
		}

	input_size = fread(input_buffer, 1, 32767, input);
	if (input_size == 32767)
		{
		(void) fprintf(errOut, "application too large: %s \n", app_file);
		fclose(input);
		return(FILE_ERROR);
		}
	
	fclose(input);

	upload_program(input_buffer, input_size);
	load_symbols(input_buffer, input_size);

	free(input_buffer);
	return(0);
	}


/*
 *
 *	Upload a DSP application into Fiji board. The application is in the format of
 *	a .lod file and should reside in memory.
 *
 */
int upload_program(char *input_buffer, long input_size)
	{
	long op;
	unsigned long pc, mem_space, mem_address;
	register int i, hash;
	register char *input_ptr;
	char *buffer_end, op_str[8];
	char mode;
	int err;

	op_str[6] = '\0';

	if (input_size > 0)
		{
		err = set_dsp_write_ptr(P, process_stereo_chunk);
		if (err != 0)
		   {
		   (void) fprintf (errOut, "Error writing to DSP. \n");
		   return(err);
		   }
		err = write_dsp_data(RTI);
		if (err != 0)
		   {
		   (void) fprintf (errOut, "Error writing to DSP. \n");
		   return(err);
		   }

		input_ptr = input_buffer;
		buffer_end = input_buffer + (int)input_size;
		mode = OTHER;

		while (input_ptr<buffer_end && isspace(*input_ptr))
			input_ptr++;

		while (input_ptr < buffer_end)
			{
			if (*input_ptr == '_')
				{
				if (strncmp(input_ptr, "_DATA ", 6) == 0)
					{
					input_ptr += 6;
					mode = *input_ptr++;

					if (mode == 'P' || mode == 'X' || mode == 'Y')
						{
						while (input_ptr<buffer_end && isspace(*input_ptr))
							input_ptr++;
						sscanf(input_ptr, "%4lx", &pc);
						if (mode == 'P')
							{
							err = set_dsp_write_ptr(P, pc);
							if (err != 0)
							   {
							   (void) fprintf (errOut, "Error writing to DSP. \n");
							   return(err);
							   }
							}
						  else if (mode == 'X')
							{
							err = set_dsp_write_ptr(X, pc);
							if (err != 0)
							   {
							   (void) fprintf (errOut, "Error writing to DSP. \n");
							   return(err);
							   }
							}
						  else if (mode == 'Y')
							{
							err = set_dsp_write_ptr(Y, pc);
							if (err != 0)
							   {
							   (void) fprintf (errOut, "Error writing to DSP. \n");
							   return(err);
							   }
							}
						}
					  else
						{
						fprintf(errOut, "ERROR - unknown _DATA block type: %c\n", mode);
						mode = OTHER;
						}
					}
				  else if (strncmp(input_ptr, "_SYMBOL ", 8) == 0)
					{
					input_ptr += 8;
					mode = *input_ptr++;

					if (mode == 'P')
						{
						mem_space = ePSpace;
						mode = SYMBOL;
						}
					  else if (mode == 'X')
						{
						mem_space = eXSpace;
						mode = SYMBOL;
						}
					  else if (mode == 'Y')
						{
						mem_space = eYSpace;
						mode = SYMBOL;
						}
					  else if (mode == 'L')
						{
						mem_space = eLSpace;
						mode = SYMBOL;
						}
					  else if (mode == 'N')
						{
						mem_space = eNullSpace;
						mode = SYMBOL;
						}
					  else
						mode = OTHER;
					}
				  else
					mode = OTHER;

				while (input_ptr<buffer_end && *input_ptr!='\n')
					input_ptr++;
				while (input_ptr<buffer_end && isspace(*input_ptr))
					input_ptr++;
				}

				switch (mode)
					{
					case 'P':
					case 'X':
					case 'Y':
						for (i=0; i<6; i++)
							op_str[i] = *input_ptr++;

						sscanf(op_str, "%6lx", &op);
						err = write_dsp_data(op);
						if (err != 0)
						   {
						   (void) fprintf (errOut, "Error writing to DSP. \n");
						   return(err);
						   }
						pc++;
						break;

					case OTHER:
					default:
						while ( input_ptr<buffer_end && (*input_ptr!='_' || *(input_ptr-1)!='\n') )
							input_ptr++;
						break;
					}

			while (input_ptr<buffer_end && isspace(*input_ptr))
				input_ptr++;
			}

		err = set_dsp_write_ptr(P, process_stereo_chunk);
		if (err != 0)
		   {
		   (void) fprintf (errOut, "Error writing to DSP. \n");
		   return(err);
		   }
		err = write_dsp_data(NOP);
		if (err != 0)
		   {
		   (void) fprintf (errOut, "Error writing to DSP. \n");
		   return(err);
		   }

		}

/*
	(void) fprintf(errOut, "\n   #          SYMBOL name  address \n");
	for (i=0; i<SYMBOL_TABLE_SIZE; i++)
		{
		if (symbol_hash_by_name_table[i].address >= 0)
			(void) fprintf(errOut, "%4d %20s  %06lX \n", i, symbol_hash_by_name_table[i].name, symbol_hash_by_name_table[i].address);
		}

	for (mem_space=eXSpace; mem_space<=eNullSpace; mem_space++)
		{
		(void) fprintf(errOut, "\n%2d #          SYMBOL name  address \n", mem_space);
		for (i=0; i<SYMBOL_TABLE_SIZE; i++)
			{
			if (symbol_hash_by_addr_table[i][mem_space].address >= 0)
				(void) fprintf(errOut, "%4d %20s  %06lX \n", i, symbol_hash_by_addr_table[i][mem_space].name, symbol_hash_by_addr_table[i][mem_space].address);
			}
		}
*/

	return(0);
	}


int load_symbol_file(char *app_file)
	{
	FILE *input;
	long input_size;
	char *input_buffer;

	if (strcmp( app_file+(strlen(app_file)-4), ".lod") != 0)
		{
		(void) fprintf(errOut, "application file, %s, is not .lod . \n", app_file);
		return(FILE_ERROR);
		}

	if ((input_buffer = (char *)malloc(32767)) == NULL)
		{
		(void) fprintf(errOut, "load_symbol_file() malloc error.\n");
		return(MALLOC_ERROR);
		}

	if ((input = fopen(app_file, "r")) == NULL)
		{
		(void) fprintf(errOut, "unable to open application file: %s \n", app_file);
		return(FILE_ERROR);
		}

	input_size = fread(input_buffer, 1, 32767, input);

	fclose(input);

	load_symbols(input_buffer, input_size);

	free(input_buffer);
	return(0);
	}


int load_symbols(char *input_buffer, int input_size)
	{
	long op;
	unsigned long pc, mem_space, mem_address;
	register int i, hash;
	register char *input_ptr;
	char *buffer_end;
	char mode;
	char symbol_name[SYMBOL_SIZE];
	int symbol_name_length;

	if ( input_size> 0)
		{

		input_ptr = input_buffer;
		buffer_end = input_buffer + (int)input_size;
		mode = OTHER;

		while (input_ptr<buffer_end && isspace(*input_ptr))
			input_ptr++;

		while (input_ptr < buffer_end)
			{
			if (*input_ptr == '_')
				{
				if (strncmp(input_ptr, "_DATA ", 6) == 0)
					{
					input_ptr += 6;
					mode = *input_ptr++;

					if (mode == 'P' || mode == 'X' || mode == 'Y')
						{
						while (input_ptr<buffer_end && isspace(*input_ptr))
							input_ptr++;
						sscanf(input_ptr, "%4lx", &pc);
						}
					  else
						{
						fprintf(errOut, "ERROR - unknown _DATA block type: %c\n", mode);
						mode = OTHER;
						}
					}
				  else if (strncmp(input_ptr, "_SYMBOL ", 8) == 0)
					{
					input_ptr += 8;
					mode = *input_ptr++;
					
					if (mode == 'P')
						{
						mem_space = ePSpace;
						mode = SYMBOL;
						}
					  else if (mode == 'X')
						{
						mem_space = eXSpace;
						mode = SYMBOL;
						}
					  else if (mode == 'Y')
						{
						mem_space = eYSpace;
						mode = SYMBOL;
						}
					  else if (mode == 'L')
						{
						mem_space = eLSpace;
						mode = SYMBOL;
						}
					  else if (mode == 'N')
						{
						mem_space = eNullSpace;
						mode = SYMBOL;
						}
					  else
						mode = OTHER;
					}
				  else
					mode = OTHER;

				while (input_ptr<buffer_end && *input_ptr!='\n')
					input_ptr++;
				while (input_ptr<buffer_end && isspace(*input_ptr))
					input_ptr++;
				}

				switch (mode)
					{
					case SYMBOL:
						if (symbol_names == NULL)
							init_symbol_table();

						if (symbol_names != NULL)
							{
							i = 0;
							while (!isspace(*input_ptr) && i<SYMBOL_SIZE-1)
								symbol_name[i++] = *(input_ptr++);
							symbol_name[i++] = '\0';
							symbol_name_length = i;
							while (*input_ptr != '\n')
								{
								if (strncmp(input_ptr, " I ", 3) == 0)
									{
									strcpy(symbol_names+symbol_names_index, (const char *)symbol_name);

									input_ptr += 3;
									sscanf(input_ptr, "%6lx", &mem_address);
									mem_address &= 0x0000FFFF;
#ifdef HASH_BY_NAME
									hash = 0;
									i = 0;
									while (symbol_name[i] != '\0')
										hash += (int)symbol_name[i++];
									hash &= (SYMBOL_TABLE_SIZE-1);
									i = 0;
									while ( symbol_hash_by_name_table[hash].address>=0 && i<SYMBOL_TABLE_SIZE )
										{
										hash++;
										hash &= (SYMBOL_TABLE_SIZE-1);
										i++;
										}
									if (i < SYMBOL_TABLE_SIZE)
										{
										symbol_hash_by_name_table[hash].name = symbol_names+symbol_names_index;
										symbol_hash_by_name_table[hash].address = ((mem_space<<16) + mem_address)&0x007FFFFFL;
										}
									  else
										fprintf (errOut, "symbol_hash_by_name_table full. \n");
#endif
									hash = (int)((mem_address + (mem_address/SYMBOL_TABLE_SIZE))&(SYMBOL_TABLE_SIZE-1));
									i = 0;
									while ( symbol_hash_by_addr_table[hash][mem_space&0x07].address>=0 && i<SYMBOL_TABLE_SIZE )
										{
										hash++;
										hash &= (SYMBOL_TABLE_SIZE-1);
										i++;
										}
									if (i < SYMBOL_TABLE_SIZE)
										{
										symbol_hash_by_addr_table[hash][mem_space&0x07].name = symbol_names+symbol_names_index;
										symbol_hash_by_addr_table[hash][mem_space&0x07].address = ((mem_space<<16) + mem_address)&0x007FFFFFL;
										}
									  else
										fprintf (errOut, "symbol_hash_by_addr_table full. \n");

									symbol_names_index += symbol_name_length;
									if (symbol_names_index > SYMBOL_NAMES_TABLE_SIZE-32)
										{
										fprintf (errOut, "symbol_names table full. \n");
										symbol_names_index = SYMBOL_NAMES_TABLE_SIZE-32;
										}
									}
								input_ptr++;
								}
							}

						while (input_ptr<buffer_end && *input_ptr!='\n')
							input_ptr++;
						while (input_ptr<buffer_end && isspace(*input_ptr))
							input_ptr++;
						break;

					case OTHER:
					default:
						while ( input_ptr<buffer_end && (*input_ptr!='_' || *(input_ptr-1)!='\n') )
							input_ptr++;
						break;
					}

			while (input_ptr<buffer_end && isspace(*input_ptr))
				input_ptr++;
			}
		}

/*
	(void) fprintf(errOut, "\n   #          SYMBOL name  address \n");
	for (i=0; i<SYMBOL_TABLE_SIZE; i++)
		{
		if (symbol_hash_by_name_table[i].address >= 0)
			(void) fprintf(errOut, "%4d %20s  %06lX \n", i, symbol_hash_by_name_table[i].name, symbol_hash_by_name_table[i].address);
		}

	for (mem_space=eXSpace; mem_space<=eNullSpace; mem_space++)
		{
		(void) fprintf(errOut, "\n%2d #          SYMBOL name  address \n", mem_space);
		for (i=0; i<SYMBOL_TABLE_SIZE; i++)
			{
			if (symbol_hash_by_addr_table[i][mem_space].address >= 0)
				(void) fprintf(errOut, "%4d %20s  %06lX \n", i, symbol_hash_by_addr_table[i][mem_space].name, symbol_hash_by_addr_table[i][mem_space].address);
			}
		}
*/

	return(0);
	}


int init_symbol_table()
	{
	int i,mem_space;

		symbol_names = malloc(SYMBOL_NAMES_TABLE_SIZE);
		if (symbol_names == NULL)
		   {
		   (void) fprintf (errOut, "Could not malloc symbol table. \n");
		   return(INIT_SYMBOL_TABLE_ERROR);
		   }

		for (i=0; i<SYMBOL_NAMES_TABLE_SIZE; i++)
			{
			symbol_names[i] = '\0';
			}
		symbol_names_index = 0;

#ifdef HASH_BY_NAME
		for (i=0; i<SYMBOL_TABLE_SIZE; i++)
			{
			symbol_hash_by_name_table[i].name = NULL;
			symbol_hash_by_name_table[i].address = -1L;
			}
#endif
		for (mem_space=eXSpace; mem_space<=eNullSpace; mem_space++)
			{
			for (i=0; i<SYMBOL_TABLE_SIZE; i++)
				{
				symbol_hash_by_addr_table[i][mem_space].name = NULL;
				symbol_hash_by_addr_table[i][mem_space].address = -1L;
				}
			}
	return(0);
	}

