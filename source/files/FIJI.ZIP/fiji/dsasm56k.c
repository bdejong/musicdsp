/*********************************************************************
*                                                                    *
*              Wave Mechanincs                                       *
*              P.O. Box 1863                                         *	
*              Montclair, NJ 07042                                   *
*                                                                    *
*              Copyright � 1993 Robert Bristow-Johnson               *
*              Copyright � 1994, 1995 crescent engineering           *
*              Copyright � 1996 Wave Mechanics                       *
*                                                                    *
*********************************************************************/

#include <ctype.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "util56k.h"

#define FILE_ERROR -5
#define MALLOC_ERROR -6
#define HASH_SYMBOL_ERROR -7
#define INIT_SYMBOL_TABLE_ERROR -8
#define SYMBOL_TABLE_FULL_ERROR -9

int init_symbol_table(void);
int load_symbol_file(char *app_file);
int load_symbols(char *input_buffer, int input_size);

#ifdef HASH_BY_NAME
symbol_entry symbol_hash_by_name_table[SYMBOL_TABLE_SIZE];
#endif
symbol_entry symbol_hash_by_addr_table[SYMBOL_TABLE_SIZE][(eNullSpace+1)];

char *symbol_names = NULL;
int symbol_names_index = 0;


void main(void)
	{
	long op, op2;
	int input_size;
	long pc, mem_space, mem_address;
	register int i, hash;
#define num_ops hash	/* why waste a register ? */
	register char *input_ptr;
	char *buffer_end, *input_buffer, output_string[64], op_str[8], op2_str[8];
	char mode;
	char file_name[64], symbol_name[256];
	FILE *ifile, *ofile;
	int asm_flag;
	
	
	
	fprintf (stderr, "enter input .lod file name:");
	scanf ("%s", &file_name);

	if (strcmp( file_name+(strlen(file_name)-4), ".lod") != 0)
		{
		fprintf(stderr, "input file is not .lod . \n");
		return;
		}
	
	if ( ( ifile = fopen( file_name, "r" ) ) == NULL )
		{
		printf( "cannot open input file %s\n", file_name );
		return;
		}

	asm_flag = 0;
	symbol_names_index = 0;
	
	fprintf(stderr, "enter output .lst file name:");
	scanf ("%s", &file_name);
	
	if (strcmp( file_name+(strlen(file_name)-4), ".asm") == 0)
		asm_flag = 1;

	if ( ( ofile = fopen( file_name, "w" ) ) == NULL )
		{
		printf( "cannot open output file %s\n", file_name );
		fclose(ifile);
		return;
		}
	
	
	op_str[6] = op2_str[6] = '\0';
	
	if ((input_buffer = (char *)malloc(32767)) == NULL)
		{
		fprintf(stderr, "malloc error.\n");
		fclose(ifile);
		fclose(ofile);
		return;
		}

	input_size = fread(input_buffer, 1, 32767, ifile);

	fclose(ifile);

	if ( input_size > 0)
		{
		init_symbol_table();

		load_symbols(input_buffer, input_size);

		input_ptr = input_buffer;
		buffer_end = input_buffer + input_size;
		mode = OTHER;

		while (input_ptr<buffer_end && isspace(*input_ptr))
			input_ptr++;

		while (input_ptr < buffer_end)
			{
			if (*input_ptr == '_')
				{
				if (strncmp(input_ptr, "_DATA ", 6) == 0)
					{
					input_ptr += 6;
					mode = *input_ptr++;

					if (mode == 'P' || mode == 'X' || mode == 'Y' || mode == 'L')
						{
						while (input_ptr<buffer_end && isspace(*input_ptr))
							input_ptr++;
						sscanf(input_ptr, "%4lx", &pc);
						if (asm_flag)
							fprintf(ofile, "\n        org       %c:$%lx\n", mode+('a'-'A'), pc);
						  else
							fprintf(ofile, "\n                                org       %c:$%lx\n", mode+('a'-'A'), pc);
						}
					  else
						{
						fprintf(stderr, "ERROR - unknown _DATA block type: %c\n", mode);
						mode = OTHER;
						}

					if (mode == 'P')
						{
						mem_space = ePSpace;
						}
					  else if (mode == 'X')
						{
						mem_space = eXSpace;
						}
					  else if (mode == 'Y')
						{
						mem_space = eYSpace;
						}
					  else if (mode == 'L')
						{
						mem_space = eLSpace;
						}
					  else if (mode == 'N')
						{
						mem_space = eNullSpace;
						}
					  else
						mode = OTHER;
					}
				  else
					mode = OTHER;

				while (input_ptr<buffer_end && *input_ptr!='\n')
					input_ptr++;
				while (input_ptr<buffer_end && isspace(*input_ptr))
					input_ptr++;
				}

			switch (mode)
				{
				case OTHER:
					while (input_ptr<buffer_end && (*input_ptr!='_' || *(input_ptr-1)!='\n'))
						input_ptr++;
					break;

				case 'P':
					for (i=0; i<6; i++)
						op_str[i] = *input_ptr++;

					sscanf(op_str, "%6lx", &op);

					while (input_ptr<buffer_end && isspace(*input_ptr))
						input_ptr++;

					for (i=0; i<6; i++)
						op2_str[i] = *(input_ptr + i);

					sscanf(op2_str, "%6lx", &op2);
					
					num_ops = Disassemble(op, op2, output_string);
					
					i = FindSymbol(ePSpace, pc, symbol_name);
					if (i >= 0)
						{
						symbol_hash_by_addr_table[i][ePSpace].address |= 0x01000000;
						if (asm_flag)
							fprintf(ofile, "%s\n", symbol_name);
						  else
							fprintf(ofile, "                        %s\n", symbol_name);
						}
					
					if (num_ops > 1)
						{
						if (asm_flag)
							fprintf(ofile, "        %s\n", output_string);
						  else
							fprintf(ofile, "p:%4lX  %s  %s          %s\n", pc, op_str, op2_str, output_string);
						input_ptr += 6;
						pc += 2;
						}
					  else
						{
						if (asm_flag)
							fprintf(ofile, "        %s\n", output_string);
						  else
							fprintf(ofile, "p:%4lX  %s                  %s\n", pc, op_str, output_string);
						pc++;
						}
					
					break;
				
				case 'X':
					for (i=0; i<6; i++)
						op_str[i] = *input_ptr++;
					sscanf(op_str, "%6lx", &op);
					
					i = FindSymbol(eXSpace, pc, symbol_name);
					if (i >= 0)
						{
						symbol_hash_by_addr_table[i][eXSpace].address |= 0x01000000;
						if (asm_flag)
							fprintf(ofile, "%s\n", symbol_name);
						  else
							fprintf(ofile, "                        %s\n", symbol_name);
						}

					if (asm_flag)
						fprintf(ofile, "        dc        $%lx\n", op);
					  else
						fprintf(ofile, "x:%4lX  %s                  dc        $%lx\n", pc, op_str, op);
					pc++;
					break;

				case 'Y':
					for (i=0; i<6; i++)
						op_str[i] = *input_ptr++;
					sscanf(op_str, "%6lx", &op);

					i = FindSymbol(eYSpace, pc, symbol_name);
					if (i >= 0)
						{
						symbol_hash_by_addr_table[i][eYSpace].address |= 0x01000000;
						if (asm_flag)
							fprintf(ofile, "%s\n", symbol_name);
						  else
							fprintf(ofile, "                        %s\n", symbol_name);
						}
			
					if (asm_flag)
						fprintf(ofile, "        dc        $%lx\n", op);
					  else
						fprintf(ofile, "y:%4lX  %s                  dc        $%lx\n", pc, op_str, op);
					pc++;
					break;
				}
			while (input_ptr<buffer_end && isspace(*input_ptr))
				input_ptr++;
			}
		
#define pad_length hash
		fprintf(ofile, "\n");
		for (mem_space=eXSpace; mem_space<eNullSpace; mem_space++)
			{
			pc = -1;
			for (i=0; i<SYMBOL_TABLE_SIZE; i++)
				{
				mem_address = symbol_hash_by_addr_table[i][mem_space].address;
				if ( (mem_address & 0x81000000) == 0x00000000)
					{
					mem_address &= 0x0000FFFF;
					pad_length = 24 - strlen(symbol_hash_by_addr_table[i][mem_space].name);
					if (asm_flag)
						{
						if (pc != mem_address)
							fprintf(ofile, "        org %c:$%lx\n", "xypln"[mem_space], mem_address);
						fprintf(ofile, "%s", symbol_hash_by_addr_table[i][mem_space].name);
						}
					  else
						{
						if (pc != mem_address)
							fprintf(ofile, "                        org %c:$%lx\n", "xypln"[mem_space], mem_address);
						fprintf(ofile, "                %s", symbol_hash_by_addr_table[i][mem_space].name);
						}
					while (pad_length-- > 0)
						fprintf(ofile, " ");
					fprintf(ofile, "ds      1\n");
					pc = mem_address+1;
					}
				}
			}
		fprintf(ofile, "\n");
		for (i=0; i<SYMBOL_TABLE_SIZE; i++)
			{
			mem_address = symbol_hash_by_addr_table[i][eNullSpace].address;
			if ( (mem_address & 0x81000000) == 0x00000000)
				{
				mem_address &= 0x0000FFFF;
				pad_length = 24 - strlen(symbol_hash_by_addr_table[i][eNullSpace].name);
				if (asm_flag)
					{
					fprintf(ofile, "%s", symbol_hash_by_addr_table[i][eNullSpace].name);
					}
				  else
					{
					fprintf(ofile, "                %s", symbol_hash_by_addr_table[i][eNullSpace].name);
					}
				while (pad_length-- > 0)
					fprintf(ofile, " ");
				fprintf(ofile, "equ     %lx\n", mem_address);
				}
			}
		}
	
	  else
		{
		fprintf (stderr, "input file read error. \n");
		}
	
	free(input_buffer);
	
#ifdef _DEBUG
	fprintf(stderr, "\n symbol_hash_by_name_table\n   #	      SYMBOL name  address \n");
	for (i=0; i<SYMBOL_TABLE_SIZE; i++)
		{
		if (symbol_hash_by_name_table[i].address >= 0)
			fprintf(ofile, "%4d %20s  %06lX \n", i, symbol_hash_by_name_table[i].name, symbol_hash_by_name_table[i].address);
		}

	fprintf(stderr, "\n symbol_hash_by_addr_table\n   #       SYMBOL name  address \n");
	for (mem_space=eXSpace; mem_space<=eNullSpace; mem_space++)
		{
		for (i=0; i<SYMBOL_TABLE_SIZE; i++)
			{
			if (symbol_hash_by_addr_table[i][mem_space].address >= 0)
				fprintf(ofile, "%4d %20s  %06lX \n", i, symbol_hash_by_addr_table[i][mem_space].name, symbol_hash_by_addr_table[i][mem_space].address);
			}
		}
#endif
	
	fclose( ofile );
	}

int load_symbol_file(char *app_file)
	{
	FILE *input;
	long input_size;
	char *input_buffer;

	if (strcmp( app_file+(strlen(app_file)-4), ".lod") != 0)
		{
		(void) fprintf(stderr, "application file, %s, is not .lod . \n", app_file);
		return(FILE_ERROR);
		}

	if ((input_buffer = (char *)malloc(32767)) == NULL)
		{
		(void) fprintf(stderr, "load_symbol_file() malloc error.\n");
		return(MALLOC_ERROR);
		}

	if ((input = fopen(app_file, "r")) == NULL)
		{
		(void) fprintf(stderr, "unable to open application file: %s \n", app_file);
		return(FILE_ERROR);
		}

	input_size = fread(input_buffer, 1, 32767, input);

	fclose(input);

	load_symbols(input_buffer, input_size);

	free(input_buffer);
	return(0);
	}


int load_symbols(char *input_buffer, int input_size)
	{
	long op;
	unsigned long pc, mem_space, mem_address;
	register int i, hash;
	register char *input_ptr;
	char *buffer_end;
	char mode;
	char symbol_name[SYMBOL_SIZE];
	int symbol_name_length;

	if ( input_size> 0)
		{

		input_ptr = input_buffer;
		buffer_end = input_buffer + (int)input_size;
		mode = OTHER;

		while (input_ptr<buffer_end && isspace(*input_ptr))
			input_ptr++;

		while (input_ptr < buffer_end)
			{
			if (*input_ptr == '_')
				{
				if (strncmp(input_ptr, "_DATA ", 6) == 0)
					{
					input_ptr += 6;
					mode = *input_ptr++;

					if (mode == 'P' || mode == 'X' || mode == 'Y')
						{
						while (input_ptr<buffer_end && isspace(*input_ptr))
							input_ptr++;
						sscanf(input_ptr, "%4lx", &pc);
						}
					  else
						{
						fprintf(stderr, "ERROR - unknown _DATA block type: %c\n", mode);
						mode = OTHER;
						}
					}
				  else if (strncmp(input_ptr, "_SYMBOL ", 8) == 0)
					{
					input_ptr += 8;
					mode = *input_ptr++;
					
					if (mode == 'P')
						{
						mem_space = ePSpace;
						mode = SYMBOL;
						}
					  else if (mode == 'X')
						{
						mem_space = eXSpace;
						mode = SYMBOL;
						}
					  else if (mode == 'Y')
						{
						mem_space = eYSpace;
						mode = SYMBOL;
						}
					  else if (mode == 'L')
						{
						mem_space = eLSpace;
						mode = SYMBOL;
						}
					  else if (mode == 'N')
						{
						mem_space = eNullSpace;
						mode = SYMBOL;
						}
					  else
						mode = OTHER;
					}
				  else
					mode = OTHER;

				while (input_ptr<buffer_end && *input_ptr!='\n')
					input_ptr++;
				while (input_ptr<buffer_end && isspace(*input_ptr))
					input_ptr++;
				}

				switch (mode)
					{
					case SYMBOL:
						if (symbol_names == NULL)
							init_symbol_table();

						if (symbol_names != NULL)
							{
							i = 0;
							while (!isspace(*input_ptr) && i<SYMBOL_SIZE-1)
								symbol_name[i++] = *(input_ptr++);
							symbol_name[i++] = '\0';
							symbol_name_length = i;
							while (*input_ptr != '\n')
								{
								if (strncmp(input_ptr, " I ", 3) == 0)
									{
									strcpy(symbol_names+symbol_names_index, (const char *)symbol_name);

									input_ptr += 3;
									sscanf(input_ptr, "%6lx", &mem_address);
									mem_address &= 0x0000FFFF;
#ifdef HASH_BY_NAME
									hash = 0;
									i = 0;
									while (symbol_name[i] != '\0')
										hash += (int)symbol_name[i++];
									hash &= (SYMBOL_TABLE_SIZE-1);
									i = 0;
									while ( symbol_hash_by_name_table[hash].address>=0 && i<SYMBOL_TABLE_SIZE )
										{
										hash++;
										hash &= (SYMBOL_TABLE_SIZE-1);
										i++;
										}
									if (i < SYMBOL_TABLE_SIZE)
										{
										symbol_hash_by_name_table[hash].name = symbol_names+symbol_names_index;
										symbol_hash_by_name_table[hash].address = ((mem_space<<16) + mem_address)&0x007FFFFFL;
										}
									  else
										fprintf (stderr, "symbol_hash_by_name_table full. \n");
#endif
									hash = (int)((mem_address + (mem_address/SYMBOL_TABLE_SIZE))&(SYMBOL_TABLE_SIZE-1));
									i = 0;
									while ( symbol_hash_by_addr_table[hash][mem_space&0x07].address>=0 && i<SYMBOL_TABLE_SIZE )
										{
										hash++;
										hash &= (SYMBOL_TABLE_SIZE-1);
										i++;
										}
									if (i < SYMBOL_TABLE_SIZE)
										{
										symbol_hash_by_addr_table[hash][mem_space&0x07].name = symbol_names+symbol_names_index;
										symbol_hash_by_addr_table[hash][mem_space&0x07].address = ((mem_space<<16) + mem_address)&0x007FFFFFL;
										}
									  else
										fprintf (stderr, "symbol_hash_by_addr_table full. \n");

									symbol_names_index += symbol_name_length;
									if (symbol_names_index > SYMBOL_NAMES_TABLE_SIZE-32)
										{
										fprintf (stderr, "symbol_names table full. \n");
										symbol_names_index = SYMBOL_NAMES_TABLE_SIZE-32;
										}
									}
								input_ptr++;
								}
							}

						while (input_ptr<buffer_end && *input_ptr!='\n')
							input_ptr++;
						while (input_ptr<buffer_end && isspace(*input_ptr))
							input_ptr++;
						break;

					case OTHER:
					default:
						while ( input_ptr<buffer_end && (*input_ptr!='_' || *(input_ptr-1)!='\n') )
							input_ptr++;
						break;
					}

			while (input_ptr<buffer_end && isspace(*input_ptr))
				input_ptr++;
			}
		}

/*
	(void) fprintf(stderr, "\n   #          SYMBOL name  address \n");
	for (i=0; i<SYMBOL_TABLE_SIZE; i++)
		{
		if (symbol_hash_by_name_table[i].address >= 0)
			(void) fprintf(stderr, "%4d %20s  %06lX \n", i, symbol_hash_by_name_table[i].name, symbol_hash_by_name_table[i].address);
		}

	for (mem_space=eXSpace; mem_space<=eNullSpace; mem_space++)
		{
		(void) fprintf(stderr, "\n%2d #          SYMBOL name  address \n", mem_space);
		for (i=0; i<SYMBOL_TABLE_SIZE; i++)
			{
			if (symbol_hash_by_addr_table[i][mem_space].address >= 0)
				(void) fprintf(stderr, "%4d %20s  %06lX \n", i, symbol_hash_by_addr_table[i][mem_space].name, symbol_hash_by_addr_table[i][mem_space].address);
			}
		}
*/

	return(0);
	}


int init_symbol_table()
	{
	int i,mem_space;

		symbol_names = malloc(SYMBOL_NAMES_TABLE_SIZE);
		if (symbol_names == NULL)
		   {
		   (void) fprintf (stderr, "Could not malloc symbol table. \n");
		   return(INIT_SYMBOL_TABLE_ERROR);
		   }

		for (i=0; i<SYMBOL_NAMES_TABLE_SIZE; i++)
			{
			symbol_names[i] = '\0';
			}
		symbol_names_index = 0;

#ifdef HASH_BY_NAME
		for (i=0; i<SYMBOL_TABLE_SIZE; i++)
			{
			symbol_hash_by_name_table[i].name = NULL;
			symbol_hash_by_name_table[i].address = -1L;
			}
#endif
		for (mem_space=eXSpace; mem_space<=eNullSpace; mem_space++)
			{
			for (i=0; i<SYMBOL_TABLE_SIZE; i++)
				{
				symbol_hash_by_addr_table[i][mem_space].name = NULL;
				symbol_hash_by_addr_table[i][mem_space].address = -1L;
				}
			}
	return(0);
	}

