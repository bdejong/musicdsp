/*********************************************************************
*                                                                    *
*              Wave Mechanincs                                       *
*              P.O. Box 1863                                         *	
*              Montclair, NJ 07042                                   *
*                                                                    *
*              Copyright � 1993 Robert Bristow-Johnson               *
*              Copyright � 1994, 1995 crescent engineering           *
*              Copyright � 1996 Wave Mechanics                       *
*                                                                    *
*********************************************************************/

#include "fiji.h"
#include "util56k.h"


#ifdef HASH_BY_NAME
extern symbol_entry symbol_hash_by_name_table[];
#endif
extern symbol_entry symbol_hash_by_addr_table[][(eNullSpace+1)];

extern char symbol_names[][20];


#define NUMREG 42
#define NUMBRK 10
#define USTK 2*(NUMREG+NUMBRK)

#define _reg(n) (reg[n]==reg[NUMREG+n]?' ':'*'),reg[n]

#define R0 _reg(0)
#define R1 _reg(1)
#define R2 _reg(2)
#define R3 _reg(3)
#define R4 _reg(4)
#define R5 _reg(5)
#define R6 _reg(6)
#define R7 _reg(7)
#define N0 _reg(8)
#define N1 _reg(9)
#define N2 _reg(10)
#define N3 _reg(11)
#define N4 _reg(12)
#define N5 _reg(13)
#define N6 _reg(14)
#define N7 _reg(15)
#define M0 _reg(16)
#define M1 _reg(17)
#define M2 _reg(18)
#define M3 _reg(19)
#define M4 _reg(20)
#define M5 _reg(21)
#define M6 _reg(22)
#define M7 _reg(23)
#define X0 _reg(24)
#define X1 _reg(25)
#define Y0 _reg(26)
#define Y1 _reg(27)
#define A2 _reg(28)&0xFF
#define A1 _reg(29)
#define A0 _reg(30)
#define B2 _reg(31)&0xFF
#define B1 _reg(32)
#define B0 _reg(33)
#define PC _reg(34)
#define SR _reg(35)
#define OMR _reg(36)
#define LA _reg(37)
#define LC _reg(38)
#define SP _reg(39)
#define BCR _reg(40)
#define IPR _reg(41)




/*
           X1= 000000 X0= 000000  R7= 0000  N7= 0000  M7= FFFF
           Y1= 000000 Y0= 000000  R6= 0000  N6= 0000  M6= FFFF
 A2= 00    A1= 000000 A0= 000000  R5= 0000  N5= 0000  M5= FFFF
 B2= 00    B1= 000000 B0= 000000  R4= 0000  N4= 0000  M4= FFFF
                                  R3= 0000  N3= 0000  M3= FFFF
 PC=*0040  SR= 0300  OMR= 02      R2= 0000  N2= 0000  M2= FFFF
 LA= 0000  LC= 0000   SP= 00      R1= 0000  N1= 0000  M1= FFFF
          BCR= 0000  IPR= 000000  R0= 0000  N0= 0000  M0= FFFF
*/


int Disassemble(unsigned long, unsigned long, char *);


void display_reg(long *reg, long REGBASE)
{
	register short i;
	long data, op, op2, pc;
	char output_string[64];
	int num_ops, n;
	static char previous_instruction[80] = {'\0'};
	char symbol_name[64];
	

	(void) set_dsp_read_ptr(P, REGBASE);

	for (i=0; i<0x89; i++)
		{
		(void) read_dsp_data(&data);
		reg[i] = data&0x00FFFFFFL;
/*
(void) fprintf(stderr, "reg[%02lX] = %06lX \n", i, reg[i]);
*/
		}
	(void) fprintf(stderr, "           x1=%c%06lX x0=%c%06lX  r7=%c%04lX  n7=%c%04lX  m7=%c%04lX\n", X1, X0, R7, N7, M7);
	(void) fprintf(stderr, "           y1=%c%06lX y0=%c%06lX  r6=%c%04lX  n6=%c%04lX  m6=%c%04lX\n", Y1, Y0, R6, N6, M6);
	(void) fprintf(stderr, " a2=%c%02lX    a1=%c%06lX a0=%c%06lX  r5=%c%04lX  n5=%c%04lX  m5=%c%04lX\n", A2, A1, A0, R5, N5, M5);
	(void) fprintf(stderr, " b2=%c%02lX    b1=%c%06lX b0=%c%06lX  r4=%c%04lX  n4=%c%04lX  m4=%c%04lX\n", B2, B1, B0, R4, N4, M4);
	(void) fprintf(stderr, "                                  r3=%c%04lX  n3=%c%04lX  m3=%c%04lX\n", R3, N3, M3);
	(void) fprintf(stderr, " pc=%c%04lX  sr=%c%04lX  omr=%c%02lX      r2=%c%04lX  n2=%c%04lX  m2=%c%04lX\n", PC, SR, OMR, R2, N2, M2);
	(void) fprintf(stderr, " la=%c%04lX  lc=%c%04lX   sp=%c%02lX      r1=%c%04lX  n1=%c%04lX  m1=%c%04lX\n", LA, LC, SP, R1, N1, M1);
	(void) fprintf(stderr, "          bcr=%c%04lX  ipr=%c%06lX  r0=%c%04lX  n0=%c%04lX  m0=%c%04lX\n", BCR, IPR, R0, N0, M0);

	
	(void) fprintf(stderr, "\n");
	
	if (*previous_instruction != '\0')
		(void) fprintf(stderr, "%s", previous_instruction);
	
	
	pc = reg[34];

	(void) set_dsp_read_ptr(P, pc);
	(void) read_dsp_data(&op);
	(void) read_dsp_data(&op2);
	
	op  &= 0x00FFFFFFL;
	op2 &= 0x00FFFFFFL;
	
	num_ops = Disassemble(op, op2, output_string);
	
	i = FindSymbol(ePSpace, pc, symbol_name);					
	if (i >= 0)
		{
		(void) fprintf(stderr, "                  %s\n", symbol_name);
		}
	
	if (num_ops > 1)
		{
		(void) sprintf(previous_instruction, " p:%04lX  %06lX %06lX    %s\n", pc, op, op2, output_string);
		(void) fprintf(stderr,               ">p:%04lX  %06lX %06lX   >%s\n", pc, op, op2, output_string);
		pc += 2;
		}
	  else
		{
		(void) sprintf(previous_instruction, " p:%04lX  %06lX           %s\n", pc, op, output_string);
		(void) fprintf(stderr,               ">p:%04lX  %06lX          >%s\n", pc, op, output_string);
		pc++;
		}
	
	for (n=0; n<6; n++)
		{	
		(void) set_dsp_read_ptr(P, pc);
		(void) read_dsp_data(&op);
		(void) read_dsp_data(&op2);
		
		op  &= 0x00FFFFFFL;
		op2 &= 0x00FFFFFFL;
		
		num_ops = Disassemble(op, op2, output_string);
		
		i = FindSymbol(ePSpace, pc, symbol_name);
		if (i >= 0)
			{
			fprintf(stderr,        "                  %s\n", symbol_name);
			}
		
		if (num_ops > 1)
			{
			(void) fprintf(stderr, " p:%04lX  %06lX %06lX    %s\n", pc, op, op2, output_string);
			pc += 2;
			}
		  else
			{
			(void) fprintf(stderr, " p:%04lX  %06lX           %s\n", pc, op, output_string);
			pc++;
			}
		}
	
	(void) fprintf(stderr, "\n");
	
	}

void dspbugger(char cmd)
	{
	long i, reg[0x89], n;
	char input_buffer[1020], char0, char1;
	static long REGBASE=0;

	long data, mem_address = 0;
	char mem_space = 'p', a_char;
	int num_words = 16, memSpace;
	

	char symbol_name[64];
	long op, op2;
	char output_string[64];
	long pc;
	int num_ops;


	int ISR, oldISR;

	const char reg_name[] = "r0r1r2r3r4r5r6r7n0n1n2n3n4n5n6n7m0m1m2m3m4m5m6m7x0x1y0y1a2a1a0b2b1b0pcsromlalcspbcip";

/*	include this code to read and write to various DSP locations */

	
	if (REGBASE == 0)
		{
		#define STACK_ERROR 0x0002
		set_dsp_read_ptr(P, (STACK_ERROR+1));
		read_dsp_data(&REGBASE);
		REGBASE += 0x0002;
		}

	if ( (cmd == 'w') || (cmd == 'r')  || (cmd == 'c')  || (cmd == 'b') )
		cmd = ' ';

	ISR = inp(isrRegister);
	if ( (ISR&HF2) && (cmd != 'g') && (cmd != 't') )
		{
		(void) fprintf(stderr, "   **DSP halted**\n");
		cmd = 's';
		}

	if (cmd != ' ')
		{
		do
			{
			oldISR = ISR;
			switch (cmd)
				{
				case 'w':
				(void) sscanf(input_buffer, "w %c %lx", &mem_space, &mem_address);

				if (mem_space == 'p' || mem_space == 'P')
					(void) set_dsp_write_ptr(P, mem_address);
				  else if (mem_space == 'y' || mem_space == 'Y')
					(void) set_dsp_write_ptr(Y, mem_address);
				  else if (mem_space == 'x' || mem_space == 'X')
					(void) set_dsp_write_ptr(X, mem_address);
				  else
					break;

				(void) fprintf(stderr, "enter data: $");
				(void) fflush(stderr);
				(void) gets(input_buffer);
				(void) sscanf(input_buffer, "%lx", &data);
	
				(void) write_dsp_data(data);
				break;
	
				case 'r':
				(void) sscanf(input_buffer, "r %c %lx %x", &mem_space, &mem_address, &num_words);

				if (num_words < 1)
					num_words = 1;

				if (mem_space == 'p' || mem_space == 'P')
					(void) set_dsp_read_ptr(P, mem_address);
				  else if (mem_space == 'y' || mem_space == 'Y')
					(void) set_dsp_read_ptr(Y, mem_address);
				  else if (mem_space == 'x' || mem_space == 'X')
					(void) set_dsp_read_ptr(X, mem_address);
				  else
					break;

				(void) fprintf(stderr, " %c:%04lX\n", mem_space, mem_address);

				for (n=0; n<num_words; n+=8)
					{
					for (i=0; i<8; i++)
						{
						(void) read_dsp_data(&data);
						(void) fprintf(stderr, " %06lX", data&0x00FFFFFFL);
						}
					(void) fprintf(stderr, "\n");
					}
				break;

				case 'd':
				(void) sscanf(input_buffer, "d %c %lx", &mem_space, &mem_address);

				if (mem_space == 'p' || mem_space == 'P')
					{
					(void) set_dsp_read_ptr(P, mem_address);
					memSpace = ePSpace;
					}
				  else if (mem_space == 'y' || mem_space == 'Y')
					{
					(void) set_dsp_read_ptr(Y, mem_address);
					memSpace = eYSpace;
					}
				  else if (mem_space == 'x' || mem_space == 'X')
					{
					(void) set_dsp_read_ptr(X, mem_address);
					memSpace = eXSpace;
					}
				  else
					break;

				for (n=0; n<12; n++)
					{
					(void) read_dsp_data(&data);
					i = FindSymbol(memSpace, mem_address, symbol_name);
					if (i >= 0)
						{
						(void) fprintf(stderr, "%s\n", symbol_name);
						}

					if (data < 0)
						(void) fprintf(stderr, " %c:%04lX  %06lX  %2.8lf\n", mem_space, mem_address, data&0x00FFFFFFL, (double)data/8388608.0);
					  else
						(void) fprintf(stderr, " %c:%04lX  %06lX   %2.8lf\n", mem_space, mem_address, data&0x00FFFFFFL, (double)data/8388608.0);

					mem_address++;
					}
				break;

				case 's':
				ISR = inp(isrRegister);
				if (!(ISR&HF2))
					(void) host_command(NMI_CMD);
	
				while (!(ISR&HF2))
					ISR = inp(isrRegister);

				(void) display_reg(reg, REGBASE);

				oldISR = ISR;
				break;

				case 'l':
				(void) sscanf(input_buffer, "l %lx", &pc);
				for (n=0; n<16; n++)
					{
					(void) set_dsp_read_ptr(P, pc);
					(void) read_dsp_data(&op);
					(void) read_dsp_data(&op2);
					op  &= 0x00FFFFFFL;
					op2 &= 0x00FFFFFFL;
					num_ops = Disassemble(op, op2, output_string);

					i = FindSymbol(ePSpace, pc, symbol_name);
					if (i >= 0)
						{
						(void) fprintf(stderr,        "                  %s\n", symbol_name);
						}

					if (num_ops > 1)
						{
						(void) fprintf(stderr, " p:%04lX  %06lX %06lX    %s\n", pc, op, op2, output_string);
						pc += 2;
						}
					  else
						{
						(void) fprintf(stderr, " p:%04lX  %06lX           %s\n", pc, op, output_string);
						pc++;
						}
					}
				break;

				case 't':
				ISR = inp(isrRegister);
				if (ISR&HF2)
					{
					(void) host_command(TRACE_CMD);

					for (i=0; i<100000L; i++)
						;

					(void) display_reg(reg, REGBASE);
					}
				break;

				case 'g':
				ISR = inp(isrRegister);
				if (ISR&HF2)
					{
					(void) set_dsp_write_ptr(P, (REGBASE + 0x0054L));
					(void) write_dsp_data(0);

					(void) host_command(NMI_CMD);

					for (i=0; i<100000L; i++)
						;
					oldISR = 0;
					}
				break;


				case 'c':
				ISR = inp(isrRegister);
				if (ISR&HF2)
					{
					input_buffer[4] = ' ';
					(void) sscanf(input_buffer, "c %c%c %lx", &char0, &char1, &data);

					n = -1;
					for (i=0; i<NUMREG; i++)
						{
						if ( ((long)char0 == reg_name[2*(int)i]) && ((long)char1 == reg_name[2*(int)i+1]) )
							n = i;
						}

					if (n > 0)
						{
						reg[(int)n] = data;
						(void) set_dsp_write_ptr(P, (REGBASE + n));
						(void) write_dsp_data(data);
						}
					  else
						(void) fprintf(stderr, "register name invalid\n");
					}
				break;

				case 'u':
				ISR = inp(isrRegister);
				if (ISR&HF2)
					{
					if (reg[39] == 0)
						(void) fprintf(stderr, "empty stack\n");
					  else
						{
						for (i=0; i<15; i++)
							{
							if (15-i == reg[39])
								(void) fprintf(stderr, "sp-> %04lX  %04lX\n", reg[2*(int)i+USTK], reg[2*(int)i+USTK+1]);
							  else if (15-i < reg[39])
								(void) fprintf(stderr, "     %04lX  %04lX\n", reg[2*(int)i+USTK], reg[2*(int)i+USTK+1]);
							}
						}
					}
				break;

				case 'b':
				(void) sscanf(input_buffer, "b %lx", &data);

				ISR = inp(isrRegister);
				if (ISR&HF2)
					{								/* DSP stopped */
					(void) set_dsp_write_ptr(P, (REGBASE + 0x0054L));
					(void) write_dsp_data(data);

					(void) host_command(NMI_CMD);

					for (i=0; i<100000L; i++)
						;
					oldISR = 0;
					}
				 else
					{									/* DSP running */
					(void) set_dsp_read_ptr(P, data);
					(void) read_dsp_data(&op);			/* get opcode */
					(void) set_dsp_write_ptr(P, (REGBASE + 0x0054L + NUMBRK));
					(void) write_dsp_data(op);			/* put opcode into breakpoint opcode table */
					(void) set_dsp_write_ptr(P, (REGBASE + 0x0054L));
					(void) write_dsp_data(data);		/* put address of opcode into breakpoint address table */
					(void) set_dsp_write_ptr(P, data);
					(void) write_dsp_data(SWI);			/* install breakpoint */
					}
				break;

				case '?':
				(void) fprintf(stderr, " >r x|y|p <addr> <nwords>  read DSP memory (nwords optional)\n");
				(void) fprintf(stderr, " >d x|y|p <addr>           display DSP data in hex and float\n");
				(void) fprintf(stderr, " >w x|y|p <addr>           write DSP memory\n");
				(void) fprintf(stderr, " >s                        stop DSP and display user registers\n");
				(void) fprintf(stderr, " >l <addr>                 list disassembled DSP code at <addr>\n");
				(void) fprintf(stderr, " >c <reg> <value>          change user registers\n");
				(void) fprintf(stderr, " >u                        display user stack\n");
				(void) fprintf(stderr, " >t                        trace 1 instruction (resume)\n");
				(void) fprintf(stderr, " >b <addr>                 set breakpoint and go (resume)\n");
				(void) fprintf(stderr, "                             or stop DSP at <addr>\n");
				(void) fprintf(stderr, " >g                        go (resume)\n");
				(void) fprintf(stderr, " >e                        exit debugger\n");
				(void) fprintf(stderr, " >?                        display debugger commands\n");
				break;
				}


			(void) fprintf(stderr, ">");
			(void) fflush(stderr);


			if ( !(oldISR&HF2) )
				{
				while (!kbhit())
					{
					ISR = inp(isrRegister);
					if ( (ISR&HF2) )
						{
						(void) fprintf(stderr, "  **DSP halted**\n");
						(void) display_reg(reg, REGBASE);
						(void) fprintf(stderr, ">");
						(void) fflush(stderr);
						goto out;
						}
					}
				}

		out:
			a_char = '\n';
			(void) gets(input_buffer);
			(void) sscanf(input_buffer, "%c", &a_char);
			if (a_char != '\n')
				cmd = a_char;

			} while (cmd != 'e');
		}
	}

