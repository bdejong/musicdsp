/*
 *
 *		fiji.h
 *
 *              #include file for all tahiti applications
 *
 */

#ifndef _FIJI_
#define _FIJI_



#include <conio.h>
#include <stdio.h>
#include <fcntl.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>
#include <math.h>

#ifdef	__cplusplus		
extern "C" {
#endif


/* DSP56 Host Port Addresses */

#define resetRegister fiji_io_address+4
#define DSPRESET_ON	0
#define DSPRESET_OFF 2

#define icrRegister	fiji_io_address+0
#define cvrRegister	fiji_io_address+1
#define isrRegister	fiji_io_address+2
#define txhRegister	fiji_io_address+5
#define txmRegister	fiji_io_address+6
#define txlRegister	fiji_io_address+7
#define rxhRegister	fiji_io_address+5
#define rxmRegister	fiji_io_address+6
#define rxlRegister	fiji_io_address+7



#define OTHER 0
#define SYMBOL 'S'
#define NOP 0x000000
#define RTI 0x000004
#define RTS 0x00000C
#define SWI 0x000006

#define process_stereo_chunk 0x003F
#define chunk_period 0x003F
#define CHUNK_SIZE 4.0
#define MIPS 22.56e6

#define RREQ 0x01
#define TREQ 0x02
#define HF0 0x08
#define HF1 0x10
#define HM0 0x20
#define HM1 0x40
#define INIT 0x80

#define HC 0x80

#define RXDF 0x01
#define TXDE 0x02
#define TRDY 0x04
#define HF2 0x08
#define HF3 0x10
#define DMA 0x40
#define HREQ 0x80


/*
	mem_space equates
*/
#define X 0x000000L
#define Y 0x010000L
#define P 0x020000L

#define READ_DSP	0x000000L
#define WRITE_DSP	0x800000L

#define RESET_CMD 0x00
#define TRACE_CMD 0x02
#define SWI_CMD 0x06
#define NMI_CMD 0x0F
#define SET_PTR_HOST_CMD 0x12
#define SET_INPUT_GAIN_HOST_CMD 0x13
#define SET_AUX_GAIN_HOST_CMD 0x14
#define SET_MIC_GAIN_HOST_CMD 0x15
#define SET_ANALOG_IN_HOST_CMD 0x16
#define SET_DIGITAL_IN_HOST_CMD 0x17

#define INT_SR_REGISTER 0xFFC0
#define	sr44kHz 0x000B
#define sr22kHz 0x000A
#define sr11kHz 0x0009
#define sr05kHz 0x0008
#define	sr48kHz 0x0007
#define sr24kHz 0x0006
#define sr12kHz 0x0005
#define sr06kHz 0x0004
#define	sr32kHz 0x0003
#define sr16kHz 0x0002
#define sr08kHz 0x0001



#define DSP_HC_TIMEOUT -1
#define DSP_READ_TIMEOUT -2
#define DSP_WRITE_TIMEOUT -3
#define DSP_ADDRESS_ERROR -4
#define DSP_READ_ENABLE_ERROR -5
#define	DSP_WRITE_ENABLE_ERROR -6
#define FILE_ERROR -7
#define MALLOC_ERROR -8
#define HASH_SYMBOL_ERROR -9
#define INIT_SYMBOL_TABLE_ERROR -10
#define SYMBOL_TABLE_FULL_ERROR -11

#define HASH_BY_NAME

#define set_dsp_read_ptr(mem_space, ptr) set_dsp_read_write_ptr((READ_DSP+mem_space) + ptr)

#define set_dsp_write_ptr(mem_space, ptr) set_dsp_read_write_ptr((WRITE_DSP+mem_space) + ptr)

#define put_long(value) (void)write_dsp_data(value)

void fiji_set_io_address(int newAddress);

void redirect_dsp_err(FILE *newErrOut);

int set_dsp_read_write_ptr(register long mode_plus_ptr);

int host_command(register unsigned int cmd);

int write_dsp_data(register long data);

int read_dsp_data(long *data_ptr);

long hash_symbol(char *symbol_name);

int get_at_label(char *symbol_name, int offset);
int put_at_label(char *symbol_name, int offset);

long get_long(void);

long read_long(char *symbol_name);

void write_long(char *symbol_name, long value);

double get_double(void);

void put_double(double value);

double read_double(char *symbol_name);

void write_double(char *symbol_name, double value);

void set_mic_pot_gain(double dBr_left, double dBr_right);
void set_input_pot_gain(double dBr_left, double dBr_right);
void set_aux_pot_gain(double dBr_left, double dBr_right);

void set_analog_input(void);
void set_digital_input(void);

void set_sample_rate(double samp_rate);
double sample_rate(void);

int boot_dsp(char *boot_file);
int upload_bootcode(char *input_buffer, long input_size);

int load_dsp_application(char *app_file);
int upload_program(char *input_buffer, long input_size);

int init_symbol_table(void);
int load_symbol_file(char *app_file);
int load_symbols(char *input_buffer, int input_size);

extern int fiji_io_address;

void dspbugger(char cmd);

#ifdef	__cplusplus
	}
#endif



#endif

