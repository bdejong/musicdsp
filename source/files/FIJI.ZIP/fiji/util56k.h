/*
	File:		Utility56k.h

	Contains:	This file contains prototypes for DSP utility functions

	Written by:	Stephen A. Davis, sadman@ccrma.stanford.edu

 	Copyright:	� 1994-1995 by Stephen A. Davis

	This program is free software; you can redistribute it and/or modify
	it under the terms of the GNU General Public License as published by
	the Free Software Foundation; either version 2 of the License, or
	(at your option) any later version.

	This program is distributed in the hope that it will be useful,
	but WITHOUT ANY WARRANTY; without even the implied warranty of
	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
	GNU General Public License for more details.

	You should have received a copy of the GNU General Public 
	along with this program; if not, write to the Free Software
	Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
*/

#ifndef __UTILITY56K_H
#define __UTILITY56K_H

#ifdef __cplusplus
extern "C" {
#endif

/* device types of the 56k family */
enum {
	DSP56000,
	DSP56001,
	DSP56002,
	DSP56003,
	DSP56004,
	DSP56005,
	DSP56007
};

/* Chip Revision for 56001 chips to make certain instructions legal: default = REVC */
enum {
	REVB,
	REVC
};

/* memory spaces, order changed by RBJ.  added eXYLPNSearch and eYXLPNSearch */
enum {
	eXSpace = 0x0,			/* xxxxx000 */
	eYSpace,				/* xxxxx001 */
	ePSpace,				/* xxxxx010 */
	eLSpace,				/* xxxxx011 */
	eNullSpace,				/* xxxxx100, neither X: nor Y: nor P:  */
	eXPeriphSpace = 0x8,	/* xxxxx000 */
	eYPeriphSpace,			/* xxxxx001 */
	
	eXYLPNSearch = 0x10,	/* not an actual space but a search path specifier */
	eYXLPNSearch
};

/* random defines */
#define kSrcOp	((int) 1)
#define kDstOp	((int) 0)

/* function declarations */
int SetDevice(int dspDevice, int dspRev);

int Disassemble(unsigned long opcodeWord, unsigned long extensionWord, char *outCodeBuf);

int FindSymbol(int memSpace, unsigned long memLocation, char *outAddrBuf);

#define OTHER 0
#define SYMBOL 'S'

#define SYMBOL_NAMES_TABLE_SIZE (SYMBOL_TABLE_SIZE*20)		/* average of 20-1 chars per symbol name */
#define SYMBOL_SIZE			256
#define SYMBOL_TABLE_SIZE	512		/* must be a power of 2 */

typedef struct
	{
	char *name;			/* pointer to '\0' terminated text string */
	long address;		/* symbol address in low 16 bits, space encoded in bits 16-23 */
	} symbol_entry;

#ifdef __cplusplus
}
#endif

#endif

/*
	Change History (most recent first):
		
		 <8>	 6/26/95	RBJ		added stuff used in DisAsm56k.c and Support56k.c
		 <7>	 6/19/95	SAD		clean up
		 <6>	 6/18/95	SAD		Change some names to clear things up. Add copyright.
		 <5>	 4/16/95	SAD		Change some types to ints since we don't care. Change some
									#defines to enums.
		 <4>	 4/6/95		SAD		Add X and Y peripheral memory space enumerations.
		 <3>	 2/19/95	SAD		Remove C++ style comments.
		 <2>	12/18/94	SAD		Add enum dspMemorySpace.  Update prototypes.
*/
