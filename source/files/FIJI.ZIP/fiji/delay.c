/*********************************************************************
*                                                                    *
*              Wave Mechanincs                                       *
*              P.O. Box 1863                                         *	
*              Montclair, NJ 07042                                   *
*                                                                    *
*              Copyright � 1993 Robert Bristow-Johnson               *
*              Copyright � 1994, 1995 crescent engineering           *
*              Copyright � 1996 Wave Mechanics                       *
*                                                                    *
*********************************************************************/

/*
 *	Host code for simple delay line example.  (Borland C)
 */


#include "fiji.h"

#define BUFFER_SIZE (double)0x4000			/* same definitions in delay.asm */

main()
	{
	char input_buffer[1020], paramID;
	
	double x, delay_amount=0.2;

	fiji_set_io_address(0x290);				/* set fiji DSP register address in I/O space */

	boot_dsp("fiji.lod");					/* load boot code */

	load_dsp_application("debug.lod");		/* load debugger */

	load_dsp_application("delay.lod");		/* load application */

	set_input_pot_gain(0.0, 0.0);
	set_aux_pot_gain(-100.0, -100.0);
	set_mic_pot_gain(-100.0, -100.0);

//	set_digital_input();					/* uncomment this if you want the input taken from S/PDIF */

	do	{

		if (delay_amount < 0.0)
			delay_amount = 0.0;				/* delay amount should never be less than zero */

		if (delay_amount > (BUFFER_SIZE-CHUNK_SIZE)/sample_rate())
			delay_amount = (BUFFER_SIZE-CHUNK_SIZE)/sample_rate();		/* delay amount (+ CHUNK_SIZE) should never be as large as the delay buffer size */

		write_long("delay_amt", (long)floor(sample_rate()*delay_amount + 0.5));	/* send number of samples of delay to DSP at delay_amt label */

		fprintf(stderr, "measured sampling rate = %lf Hz.\n", sample_rate());
		fprintf(stderr, "[d]elay_amount = %lf seconds.\n", delay_amount);
		fprintf(stderr, "enter param ID (d) and '=' <value> or de[b]ugger, [q]uit:\n");
		
		while (!kbhit())
			dspbugger(' ');					/* in case DSP hits a breakpoint or stops for other reason */
		
		gets(input_buffer);
		fprintf(stderr, "\n");
		
		sscanf(input_buffer, "%c=%lf", &paramID, &x);

		paramID = tolower(paramID);			/* in case someone left the Caps Lock key on. */
		
		if (paramID == 'd')
			delay_amount = x;
		
		if (paramID == 'b')
			dspbugger('?');					/* if 'b' was entered for parameter ID, go to debugger. */
		
		} while (paramID != 'q');
	}


