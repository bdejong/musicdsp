/*
	File:		Support56k.c

	Contains:	This file contains support functions for the disassembler
				and assembler (hah).
				
	Written by:	Stephen A. Davis, sadman@ccrma.stanford.edu

 	Copyright:	� 1994-1995 by Stephen A. Davis

	This program is free software; you can redistribute it and/or modify
	it under the terms of the GNU General Public License as published by
	the Free Software Foundation; either version 2 of the License, or
	(at your option) any later version.

	This program is distributed in the hope that it will be useful,
	but WITHOUT ANY WARRANTY; without even the implied warranty of
	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
	GNU General Public License for more details.

	You should have received a copy of the GNU General Public 
	along with this program; if not, write to the Free Software
	Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
*/

#include "util56k.h"
#include <string.h>
#include <stdio.h>

int SearchHashTable(int mem_space, unsigned long mem_address, char *outAddrBuf);


/* globals */
int	gDevice = DSP56002;		/* Which 56K chip -> 56001,56002,56004,etc. */
int	gChipRev = REVC;		/* Revision mask of 56001 -> >0 = Rev. C or beyond */

#ifdef HASH_BY_NAME
extern symbol_entry symbol_hash_by_name_table[];
#endif
extern symbol_entry symbol_hash_by_addr_table[][(eNullSpace+1)];

extern char symbol_names[][20];

/*
	---------------------------------------------------------------------------
	� SetDevice
	---------------------------------------------------------------------------
	Set the appropriate chip device (56001, 56002, 56004, etc.) for decoding
		and assembling purposes.  Also set the chip revision for 56001's.
*/
int SetDevice(int dspDevice, int dspRev)
	{
	/* check for the original DSP types */
	if ((dspDevice == DSP56000) || (dspDevice == DSP56001))
		{
		gDevice = dspDevice;
		gChipRev = dspRev;
		if ((dspRev != REVB) && (dspRev != REVC))
			return -1;
		else
			return 0;
		}
	
	/* check for the newer 56k family common core processors */
	if ((dspDevice >= DSP56002) && (dspDevice <= DSP56007))
		{
		gDevice = dspDevice;
		gChipRev = 0;
		return 0;
		}
	
	/* return error for unknown types */
	return -1;
	}



int SearchHashTable(int mem_space, unsigned long mem_address, char *outAddrBuf)
	{
	register int i, hash;
	int return_value = -1;
	
	if (mem_space>=eXSpace && mem_space<=eNullSpace)
		{
		mem_address &= 0x0000FFFF;
		hash = (mem_address + (mem_address/SYMBOL_TABLE_SIZE))&(SYMBOL_TABLE_SIZE-1);
		i = 0;
		while ( ((symbol_hash_by_addr_table[hash][mem_space].address)&0x0000FFFF)!=(long)mem_address && i<SYMBOL_TABLE_SIZE )
			{
			hash++;
			hash &= (SYMBOL_TABLE_SIZE-1);
			i++;
			}
		
		if ( ((symbol_hash_by_addr_table[hash][mem_space].address)&0x0000FFFF) == (long)mem_address && (symbol_hash_by_addr_table[hash][mem_space].address != -1) )
			{
			return_value = hash;
			strcpy((char *)outAddrBuf, (const char *)(symbol_hash_by_addr_table[hash][mem_space].name));
			}
		}
	return return_value;
	}

/*
	---------------------------------------------------------------------------
	� FindSymbol
	---------------------------------------------------------------------------
	Find a symbol for the given memory space and address extension word
	- the 56k will ignore the upper 8 bits in the address extension word so
		we mask it off so things don't look funny.
*/
int FindSymbol(int memSpace, unsigned long memLocation, char *outAddrBuf)
	{
	int return_value;
	/* make sure the output buffer is okay */
	if (outAddrBuf == NULL)
		return -3;
	
	return_value = -1;
	sprintf(outAddrBuf, "$%04lX", (memLocation & 0x00FFFFul));	/* default, in case not symbol is found */
	/* figure out which memory space we're in */
	switch (memSpace)
	{
		case eXYLPNSearch:
				return_value = SearchHashTable(eXSpace, memLocation, outAddrBuf);
			if (return_value < 0)
				return_value = SearchHashTable(eYSpace, memLocation, outAddrBuf);
			if (return_value < 0)
				return_value = SearchHashTable(eLSpace, memLocation, outAddrBuf);
			if (return_value < 0)
				return_value = SearchHashTable(ePSpace, memLocation, outAddrBuf);
			if (return_value < 0)
				return_value = SearchHashTable(eNullSpace, memLocation, outAddrBuf);
			break;
					
		case eYXLPNSearch:
				return_value = SearchHashTable(eYSpace, memLocation, outAddrBuf);
			if (return_value < 0)
				return_value = SearchHashTable(eXSpace, memLocation, outAddrBuf);
			if (return_value < 0)
				return_value = SearchHashTable(eLSpace, memLocation, outAddrBuf);
			if (return_value < 0)
				return_value = SearchHashTable(ePSpace, memLocation, outAddrBuf);
			if (return_value < 0)
				return_value = SearchHashTable(eNullSpace, memLocation, outAddrBuf);
			break;
		
		case ePSpace:
		case eXSpace:
		case eYSpace:
		case eLSpace:
		case eXPeriphSpace:
		case eYPeriphSpace:
		case eNullSpace:
			return_value = SearchHashTable(memSpace, memLocation, outAddrBuf);
			break;
		
		default:
			break;
		}
	return return_value;
	}

/*
	Change History (most recent first):

		<11>	10/19/95	RBJ		Fixed little obscure bug in  SearchHashTable().
		<10>	 8/27/95	RBJ		Added hash tables to put _SYMBOLs in and modified
									FindSymbol() to find a symbol if it can.					
		 <9>	 8/26/95	RBJ		Added eXYLPNSearch and eYXLPNSearch to memSpace alternatives.
		 <8>	 6/18/95	SAD		Clear up some names. Default = DSP56002. Move change history to
									end of file. Add copyright stuff.
		 <7>	 4/16/95	SAD		Add X and Y peripheral memory space enumerations to
									FindSymbol(). Change some types to ints.
		 <6>	 2/28/95	SAD		Change FindSymbol() to lower case memory spaces.
		 <5>	 2/24/95	SAD		Change FindSymbol() so it doesn't always use 6 digits.
		 <4>	 2/19/95	SAD		Remove C++ style comments.
		 <3>	12/18/94	SAD		Update FindSymbol().
		 <2>	11/20/94	SAD		More FindSymbol().
*/
