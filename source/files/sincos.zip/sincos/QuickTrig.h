// Copyright (c) 1999-2003 Robin Davies.
// Placed into the public domain. 
// All uses permitted without attribution.

#include "SfxxRound.h"

struct TSinCos { 
    float m_sin, m_cos;
};

class CQuickTrigConsts {
public:
	enum { 
        kMSBits = 10,
        kLSBits = 10,
        kMsTableSize = 1 << kMSBits,
        kLsTableSize = 1 << kLSBits,
        kBits = kMSBits + kLSBits,
		kPowBits = 8,
    };
	enum { 
		kMaxValidIndex = (2 << 20),
	};

protected:
    static TSinCos m_MsBitsTable[kMsTableSize+1];
    static TSinCos m_LsBitsTable[kMsTableSize+1];

protected:
    static void Initialize();
};


class CQuickTrig
: public CImplementsRounding , public CQuickTrigConsts 
{
public:

    FORCEINLINE double QuickSinQ(int nIndex) const {
        // Based on the identity sin(u+v) = sinu cosv + cosu sinv
        TSinCos *pscu = m_MsBitsTable +( (nIndex >> kLSBits) & (kMsTableSize-1));
        TSinCos *pscv = m_LsBitsTable + ( (nIndex) & (kLsTableSize-1));
        return pscu->m_sin * pscv->m_cos + pscu->m_cos * pscv->m_sin;
    };
    FORCEINLINE double QuickSin(double dAngle) const // Returns sin with 20 bits of precision.
    {
        return QuickSinQ(Round(dAngle*(kMsTableSize*kLsTableSize/(2*PI))) );
    }
    FORCEINLINE double QuickCosQ(int nIndex) const {
        // based on the identity cos(u+v) = cosu cosv + sinu sinv
        TSinCos *pscu = m_MsBitsTable +( (nIndex >> kLSBits) & (kMsTableSize-1));
        TSinCos *pscv = m_LsBitsTable + ( (nIndex) & (kLsTableSize-1));
        return pscu->m_cos * pscv->m_cos - pscu->m_sin * pscv->m_sin;
    };

    FORCEINLINE double QuickCos(double dAngle) const // Returns cos with 20 bits of precision.
    {
        return QuickCosQ(Round(dAngle*(kMsTableSize*kLsTableSize/(2*PI))) );
    }

    FORCEINLINE void QuickSinCosQ(int nIndex, double &dSin, double &dCos)const  {
        // based on the identity cos(u+v) = cosu cosv + sinu sinv
        TSinCos *pscu = m_MsBitsTable +( (nIndex >> kLSBits) & (kMsTableSize-1));
        TSinCos *pscv = m_LsBitsTable + ( (nIndex) & (kLsTableSize-1));
        dCos = pscu->m_cos * pscv->m_cos - pscu->m_sin * pscv->m_sin;
        dSin = pscu->m_sin * pscv->m_cos + pscu->m_cos * pscv->m_sin;
    };


    FORCEINLINE void QuickSinCos(double dAngle, double &dSin, double &dCos) const // Returns cos with 20 bits of precision.
    {
        QuickSinCosQ(Round(dAngle*(kMsTableSize*kLsTableSize/(2*PI))) , dSin, dCos);
    }


};
