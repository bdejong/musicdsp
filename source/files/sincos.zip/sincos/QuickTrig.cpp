#include "QuickTrig.h"

void CQuickTrigConsts::Initialize()
{
   int i;
    for (i = 0; i <= kMsTableSize; ++i) {
        double phi = (2*PI*i/kMsTableSize);
        m_MsBitsTable[i].m_sin = (float)sin(phi);
        m_MsBitsTable[i].m_cos = (float)cos(phi);
    }
    for (i = 0; i <= kLsTableSize; ++i) {
        double phi = (2*PI*i/(kMsTableSize*1.0*kLsTableSize));
        m_LsBitsTable[i].m_sin = (float)sin(phi);
        m_LsBitsTable[i].m_cos = (float)cos(phi);
    }
}

// Initialize QuickTrig constants with a global constructor.

class CQuickTrigInitialize: CQuickTrigConsts {
public:
    CQuickTrigInitialize() {
           CQuickTrigConsts::Initialize();
    }
};
CQuickTrigInitialize gQuickTrigInitialize;
