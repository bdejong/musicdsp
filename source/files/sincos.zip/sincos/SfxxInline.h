#ifndef SFXXINLINE_H
#define SFXXINLINE_H

#ifdef _MSC_VER
#define FORCEINLINE  __forceinline
#else
#define FORCEINLINE inline
#endif
#endif