/*
GIGXPAND v1.0 - Expand GigaSampler .WA! compressed .WAV files
Copyright (C)2000 Paul Kellett (paul.kellett@mda-vst.com)

This library is free software; you can redistribute it and/or
modify it under the terms of the GNU Lesser General Public
License as published by the Free Software Foundation; either
version 2.1 of the License, or (at your option) any later version.

This library is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
Lesser General Public License for more details.

You should have received a copy of the GNU Lesser General Public
License along with this library; if not, write to the Free Software
Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA


Usage
-----
You are reading a .WA! file, or a .WA! file embedded in a .GIG file,
and you have just read the header of the data chunk to get it's length.
Now you call gigxpand(length, fi, fo), where:
  length = data chunk length
  fi = the .WA! file, positioned at the start of the data chunk
  fo = your output file, where the uncompressed PCM wave will be written

At the moment the code isn't great, it's just to demonstrate the method...


Method
------
The compression method is pretty simple: 8-bit "acceleration" is stored
instead of 16-bit "displacement", for blocks of the waveform where the
"acceleration" (the second derivative of the waveform) will fit into 8 bits.

First, two bytes are read holding the compression mode for each channel.
Then for each compressed channel, 16-bit values for x and dx are read
Then 2048 sample frames are calculated. Repeat for next waveform block.
*/


long gigxpand(long length, FILE *fi, FILE *fo)
{
  long  inbytes=0, outbytes=0, i;
  short mode, x, y, dx, dy, buf[2][2048];
  char  c;

  while(inbytes < length) //for each data block
  {
    fread(&mode, 2, 1, fi); //get compression mode
    
    switch(mode) //assumes file is stereo - I haven't seen a mono one
    {
      case 1: //left channel compressed
        inbytes += 6150; //6 byte header + 2048 frames of (8-bit | 16-bit)
        if(inbytes<length)
        {
          outbytes += 8192; //2048 frames of 16-bit stereo 
          fread(&x , 2, 1, fi);
          fread(&dx, 2, 1, fi);
        
          for(i=0; i<2048; i++)
          {
            fread(&c, 1, 1, fi);
            dx -= (short)c;
            x -= dx;
            fwrite(&x, 2, 1, fo);
     
             fread(&y, 2, 1, fi);
            fwrite(&y, 2, 1, fo);
          }
        }
        break;

      case 256: //right channel compressed
        inbytes += 6150; //6 byte header + 2048 frames of (16-bit | 8-bit)
        if(inbytes<length)
        {
          outbytes += 8192;
          fread(&y , 2, 1, fi);
          fread(&dy, 2, 1, fi);
        
          for(i=0; i<2048; i++)
          {
            fread(&x , 2, 1, fi);
            fwrite(&x, 2, 1, fo);
     
            fread(&c, 1, 1, fi);
            dy -= (short)c;
            y -= dy;
            fwrite(&y, 2, 1, fo);
          }
        }
        break;

      case 257: //both channels compressed
        inbytes += 4106; //10 byte header + 2048 frames of (8-bit | 8-bit)
        if(inbytes<length)
        {
          outbytes += 8192;
          fread(&x , 2, 1, fi);
          fread(&dx, 2, 1, fi);
          fread(&y , 2, 1, fi);
          fread(&dy, 2, 1, fi);
        
          for(i=0; i<2048; i++)
          {
            fread(&c, 1, 1, fi);
            dx -= (short)c;
            x -= dx;
            fwrite(&x, 2, 1, fo);
     
            fread(&c, 1, 1, fi);
            dy -= (short)c;
            y -= dy;
            fwrite(&y, 2, 1, fo);
          }
        }
        break;

      default: //uncompressed
        inbytes += 8194; //2 byte header + 2048 frames of (16-bit | 16-bit)
        if(inbytes<length)
        {
           fread(buf, 4096, 2, fi);
          fwrite(buf, 4096, 2, fo);
          outbytes += 8192;
        }
        break;
    }
  }

  return outbytes; //number of bytes written;
}
