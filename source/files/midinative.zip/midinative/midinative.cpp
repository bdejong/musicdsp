/*
 *  Copyright (c) 1999 by Niels Gorisse <niels@bonneville.nl>
 *
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU Library General Public License as published
 * by the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU Library General Public
 * License along with this program; if not, write to the Free Software
 * Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
 *
 */


// Example of MidiNative.h. MidiNative.h is a part of the 
// 'Wire' package (also under GNU license), a package which
// realizes midi in- and output for Java Sound on the MS Windows
// platform (http://www.bonneville.nl/software/Wire/).
//
// The file MidiNative.h includes all functions. It also has
// some comments at the top of the document. 
//
// This should work under every Windows compiler. With Borland,
// it is not '_kbhit()' but 'kbhit()', and perhaps it's 'sleep()'
// instead of 'Sleep()'.
// With Visual C++, you have to link 'winmm.lib' with (at
// Project - Settings - Link - General); this is not needed with
// Borland.
//
// Please mail me if you find a bug or if you are using these
// classes in an interesting project. 

#include "MidiNative.h" // class MidiNativeIn, MidiNativeOut
#include <iostream.h> // cout
#include <conio.h> // _kbhit();

class PrintInput : public MidiNativeIn
	{
	public:

void in(unsigned long data,unsigned long timestamp)
	{
	u.ulong=data;
	cout<<"MIDI input: "<<(unsigned int)u.uchars[0]<<" "<<(unsigned int)u.uchars[1]<<" "<<(unsigned int)u.uchars[2]<<" at "<<timestamp<<endl;
	}

void inlong(char*data,unsigned long length)
	{
	cout<<"MIDI input: sysex:";
	for (unsigned long x=0;x<length;x++)
		cout<<" "<<(unsigned int)data[x];
	cout<<endl;
	cout.flush();
	}

};


void main()
	{
	PrintInput input;
	MidiNativeOut output;
	char name[40];
	unsigned int x; // apart definition to keep it ANSI compatible (long live Microsoft Visual C++...<not>).

	cout<<"You have these MIDI input devices installed:\n";
	for (x=0;x<input.numberofdevices();x++)
		{
		input.devicename(x,name);
		cout<<x<<": "<<name<<endl;
		}

	cout<<"You have these MIDI output devices installed:\n";
	for (x=0;x<output.numberofdevices();x++)
		{
		output.devicename(x,name);
		cout<<x<<": "<<name<<endl;
		}

	unsigned int inport=6; // change here
	input.devicename(inport,name);
	cout<<"\n\nNow printing all input from port "<<inport<<" ("<<name<<").\n";
	cout<<"Press enter to break the loop.\n\n";
	cout.flush();

	input.setport(inport);
	input.open();
	while (!_kbhit()) Sleep(0);
	// deconstructors stop the input automatically
	}
