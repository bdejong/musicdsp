/*
 *  Copyright (c) 1999 by Niels Gorisse <niels@bonneville.nl>
 *
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU Library General Public License as published
 * by the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU Library General Public
 * License along with this program; if not, write to the Free Software
 * Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
 *
 */


/*

	EXPLANATION

This file should be pretty bug-less, since I've used it in several 
ways now. If you find a bug, please mail me. 

Most comments are Dutch.

The inner working is like demonstrated under here. MidiNative is 
the basic class, and says that a midi class should implement 
things like open() and close(). MidiNativeIn and MidiNativeOut have 
in() or out() functions which are exactly the oppositive of each 
other. I think this is pretty clear..

	class MidiNative
		{
		protected:
	bool running;
		public:
	virtual unsigned int numberofdevices() {return 0;}
	virtual void devicename(unsigned int,char*)=0;
	virtual void open()=0;
	virtual void close()=0;
	virtual void setport(unsigned int)=0;
		};

	class MidiNativeOut : public MidiNative
		{
		void out(char status,char data1,char data2);
		void outlong(char* what,unsigned long length);
		};

	class MidiNativeIn : public MidiNative
		{
		void in(unsigned long data,unsigned timestamp); // use only first three of 'data'
		void inlong(char*data,unsigned long length);
		};

Of course the classes contain a lot more functions (like resettimestamp())
but these are left out here. You should understand how to use these
classes by now.

*/

#ifndef MIDINATIVE
#define MIDINATIVE

#include <windows.h>
#include <stdio.h> // sprintf

// basic class
class MidiNative
	{
	protected:
bool running;
	public:
virtual unsigned int numberofdevices() {return 0;}
virtual void devicename(unsigned int,char*)=0;
virtual void open()=0;
virtual void close()=0;
virtual void setport(unsigned int)=0;

// JAVA: for independent I/O: these functions are left out.
	};



class MidiNativeOut : public MidiNative
	{
	MMRESULT resultaat;
	unsigned int DeviceID;
	void printErrorMessage(MMRESULT);
	HANDLE sysexhandle; // sysex handle
	HMIDIOUT device; // moet bewaard blijven voor sysex output
	MIDIHDR berichie; // midiheader voor sysex

protected:
	short closed; // 1: deze poort in gebruik en/of niet afgesloten.
    union	
		{
		DWORD ulong; // DWORD = unsigned long
		unsigned short ushorts[2]; // unsigned short = jchar
		unsigned char uchars[4]; // unsigned char = MIDI
		} u;
public:
	MidiNativeOut()
		{
		closed=0;
		sysexhandle = CreateEvent(NULL,TRUE,FALSE,NULL);
		if (MIDI_MAPPER<numberofdevices()) DeviceID=MIDI_MAPPER; else DeviceID=0;
		}
	virtual ~MidiNativeOut() 
		{
		close();
		if (sysexhandle!=0) CloseHandle(sysexhandle);
		}
	unsigned int numberofdevices() {return midiOutGetNumDevs();}
	void devicename(unsigned int whichone,char*vuller);
	void setport(unsigned int);
	void resettimestamp();
	void close();
	void open();
	void out(char status,char data1,char data2);
	void out(DWORD dwParam1);
	void outlong(char*what,unsigned long lengte);
};

void MidiNativeOut::devicename(unsigned int whichone,char*vuller)
	{
	if (whichone>midiOutGetNumDevs()) return;
	MIDIOUTCAPS outputCapacitiez;
	midiOutGetDevCaps(whichone,&outputCapacitiez,sizeof(MIDIOUTCAPS));
	sprintf(vuller,"%s",outputCapacitiez.szPname);
	}


void MidiNativeOut::setport(unsigned int DeviceID)
	{
	if (DeviceID>midiOutGetNumDevs()) return;
	this->DeviceID=DeviceID;
	if (closed) {close();open();} // indien we bezig zijn, stop&start
	}

void MidiNativeOut::open()
	{
	if (closed==1) return; // als we al lopen: laten lopen
	resultaat=midiOutOpen(&device,DeviceID,(DWORD)sysexhandle,(DWORD)NULL,CALLBACK_EVENT);
	if (resultaat!=MMSYSERR_NOERROR) {printErrorMessage(resultaat);return;}
	closed=1;
	}

void MidiNativeOut::resettimestamp()
	{if (midiOutReset(device)!=MMSYSERR_NOERROR) printErrorMessage(resultaat);}

void MidiNativeOut::close()
	{
	if (closed==0) return;
	if (midiOutReset(device)!=MMSYSERR_NOERROR) ;//printErrorMessage(resultaat);
	if (midiOutClose(device)!=MMSYSERR_NOERROR) ;//printErrorMessage(resultaat);
	// zenden van error message onderdrukt, anders begint windows te stijgeren aant einde
	closed=0;
	}

void MidiNativeOut::printErrorMessage(MMRESULT result)
	{
	close();
	char msg[256];
	midiOutGetErrorText(result, msg, 256);
	throw msg;
	}

void MidiNativeOut::out(DWORD dwParam1)
	{
	if (closed==0) throw "Sorry, first start this midiout device";
	resultaat=midiOutShortMsg(device,dwParam1);
	if (resultaat!=MMSYSERR_NOERROR) printErrorMessage(resultaat);
	}

void MidiNativeOut::out(char status,char data1,char data2)
	{
	if (closed==0) throw "Sorry, first start this midiout device";
	u.uchars[0]=BYTE(status);
	u.uchars[1]=BYTE(data1);
	u.uchars[2]=BYTE(data2);
	u.uchars[3]=0;
	resultaat=midiOutShortMsg(device,u.ulong);
	if (resultaat!=MMSYSERR_NOERROR) printErrorMessage(resultaat);	
	}


void MidiNativeOut::outlong(char*what,unsigned long lengte)
	{
	if (closed==0) throw "Sorry, first start this midiout device";
/*	cout<<"Writing sysex, length="<<lengte<<"....:\n";
	for (unsigned int x=0;x<lengte;x++) cout<<(int)what[x]<<"  ";
	cout<<endl;cout.flush();
*/
	berichie.lpData = what;
	berichie.dwBufferLength = lengte;
	berichie.dwBytesRecorded = lengte;
	berichie.dwFlags = 0;
	resultaat=midiOutPrepareHeader(device,&berichie,sizeof(MIDIHDR));
	if (resultaat!=MMSYSERR_NOERROR) {printErrorMessage(resultaat);return;}
	ResetEvent(sysexhandle);
	resultaat=midiOutLongMsg(device,&berichie,sizeof(MIDIHDR));
	if (resultaat!=MMSYSERR_NOERROR) {printErrorMessage(resultaat);return;}
	if (!(berichie.dwFlags & MHDR_DONE))
		{
		// wait for done signal
		if ((resultaat=WaitForSingleObject(sysexhandle,5*lengte))==WAIT_FAILED)
			{throw "sending sysex: out of time.";return;}
		// if we timed out, abort the write to reclaim ownership of the data buffer
		if (resultaat==WAIT_TIMEOUT) {midiOutReset(sysexhandle);}
		}
	resultaat= midiOutUnprepareHeader(device,&berichie,sizeof(MIDIHDR));
	}


class MidiNativeIn : public MidiNative
	{
	#define SYSEXBUFFERS 5 // 5 should be OK.
	MMRESULT resultaat;
	HMIDIIN device;
	unsigned int DeviceID;
	short closed;          // 1: er is een poort in gebruik en/of niet afgesloten.
	void printErrorMessage(MMRESULT);
	MIDIHDR mpc_midiInHeaders[SYSEXBUFFERS]; // sysex
	char mpc_inBuf[SYSEXBUFFERS][256]; // sysex. Size 256 also in open()
protected:
    union
		{
		DWORD ulong; // DWORD = unsigned long
		unsigned short ushorts[2]; // unsigned short = jchar
		unsigned char uchars[4]; // unsigned char = MIDI
		} u;
	virtual void in(unsigned long,unsigned long) = 0;
	virtual void inlong(char*data,unsigned long length) = 0;
public:
	MidiNativeIn();
	virtual ~MidiNativeIn();
	unsigned int numberofdevices() {return midiInGetNumDevs();}
	void setport(unsigned int);
	void resettimestamp();  // maybe betere manier, zou goed zijn voor tijdelijk sluiten
	void open();
	void close();
	void PrepareSysex(DWORD dwParam1,DWORD timestamp);
	void devicename(unsigned int whichone,char*vuller);
	void setbuffersize(unsigned int buffersize) {}
	static void CALLBACK handlemidi(HMIDIIN hMidiIn,UINT inputStatus,DWORD instancePtr,DWORD midiMessage,DWORD timestamp);
virtual void handleMidiClass(UINT inputStatus, unsigned long midiMessage,unsigned long timestamp)
	{
	switch (inputStatus)
	   	{
		case MIM_MOREDATA:
		case MIM_DATA:
			in(midiMessage,timestamp);break;
		case MIM_LONGDATA:
			PrepareSysex(midiMessage,timestamp);break;
		default:   ;
   		} // end of switch
	}

};

void CALLBACK MidiNativeIn::handlemidi(HMIDIIN hMidiIn,UINT inputStatus,DWORD instancePtr,DWORD midiMessage,DWORD timestamp)
	{
	if (midiMessage==254) return; // remove active sensing at once
	if (midiMessage==248) return; // whatever it is
	((MidiNativeIn*)instancePtr)->handleMidiClass(inputStatus,midiMessage,timestamp);
	}

void MidiNativeIn::PrepareSysex(DWORD dwParam1,DWORD timestamp)
	{
		LPMIDIHDR headerData = (LPMIDIHDR)dwParam1;
		if(headerData->dwBytesRecorded>0)
			{
			inlong(headerData->lpData,headerData->dwBytesRecorded);
			headerData->dwFlags=0;
			resultaat= midiInPrepareHeader(device,headerData,sizeof(MIDIHDR));
			if (resultaat!=MMSYSERR_NOERROR) printErrorMessage(resultaat);
			resultaat= midiInAddBuffer(device,headerData,sizeof(MIDIHDR));
			if (resultaat!=MMSYSERR_NOERROR) printErrorMessage(resultaat);
			}
	}

MidiNativeIn::MidiNativeIn() 
	{
	closed=0;
	DeviceID=0;
	}

MidiNativeIn::~MidiNativeIn()
	{
	if (closed) close();
	}


void MidiNativeIn::devicename(unsigned int whichone,char*vuller)
	{
	if (whichone>midiInGetNumDevs()) return;
	MIDIINCAPS inputCapacitiez;
	midiInGetDevCaps(whichone,&inputCapacitiez,sizeof(MIDIINCAPS));
	sprintf(vuller,"%s",inputCapacitiez.szPname);
	}



void MidiNativeIn::setport(unsigned int DeviceID)
	{
	if (DeviceID>midiInGetNumDevs()) return;
	this->DeviceID=DeviceID;
	if (closed) {close();open();} // indien we bezig zijn, stop&start
	}

void MidiNativeIn::open()
	{
	if (closed) return; // als we lopen: laten lopen
	resultaat=midiInOpen(&device,DeviceID,(DWORD)&(handlemidi),(DWORD)(this),CALLBACK_FUNCTION|MIDI_IO_STATUS);
	if (resultaat!=MMSYSERR_NOERROR) printErrorMessage(resultaat);
	for(unsigned int i=0;i<SYSEXBUFFERS;i++)
		{
		mpc_midiInHeaders[i].dwFlags=0;
		mpc_midiInHeaders[i].lpData = mpc_inBuf[i];
		mpc_midiInHeaders[i].dwBufferLength = 256;
		mpc_midiInHeaders[i].dwUser = i;
		resultaat= midiInPrepareHeader(device,&mpc_midiInHeaders[i],sizeof(MIDIHDR));
		if (resultaat!=MMSYSERR_NOERROR) printErrorMessage(resultaat);
		resultaat= midiInAddBuffer(device,&mpc_midiInHeaders[i],sizeof(MIDIHDR));
		if (resultaat!=MMSYSERR_NOERROR) printErrorMessage(resultaat);
		}
	resultaat=midiInStart(device);
	if (resultaat!=MMSYSERR_NOERROR) printErrorMessage(resultaat);
	closed=1;
	}

void MidiNativeIn::resettimestamp()
	{
   resultaat=midiInReset(device);
//   if (resultaat!=MMSYSERR_NOERROR) printErrorMessage(resultaat);
   resultaat=midiInStart(device);
   if (resultaat!=MMSYSERR_NOERROR) printErrorMessage(resultaat);
   }


void MidiNativeIn::close()
	{
	if (closed==0) return;
	resultaat=midiInReset(device);
//	if (resultaat!=MMSYSERR_NOERROR) printErrorMessage(resultaat);
	resultaat=midiInClose(device);
	closed=0;
//	if (resultaat!=MMSYSERR_NOERROR) printErrorMessage(resultaat);
	}

void MidiNativeIn::printErrorMessage(MMRESULT result)
	{
	close();
	char msg[256];
	waveOutGetErrorText(result, msg, 256);
//	printf(msg,"\n");
	throw msg;
//	cout<<msg<<endl; // todo: iets van throw
	}


#endif // MIDINATIVE