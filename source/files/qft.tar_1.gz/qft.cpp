#include "stdafx.h"
//#include <stdlib.h>
//#include <math.h>
//#include "basic.hpp"
#include "qft.h"

QFT qft;

#define	sec1	0.5411961001461970
#define	sec2	0.70710678118654752
#define	sec3	1.3065629648763763

static const double Sec1=sec1;
static const double Sec2=sec2;
static const double Sec3=sec3;

SecantTable QFT::Secants(MaxQFT);

#define _USE_ASM

void QFT::Dct(float *x)
{
	if (lnh==2) {
#ifndef _USE_ASM
		const double t1=x[0]-x[4];
		const double t2=0.70710678118654*(x[1]-x[3]);
		const double t3=x[1]+x[3];
		const double t4=x[0]+x[4];
		const double t5=t4+x[2];
		x[0]=(float)(t5+t3);
		x[1]=(float)(t1+t2);
		x[2]=(float)(t4-x[2]);
		x[3]=(float)(t1-t2);
		x[4]=(float)(t5-t3);
#else
		_asm{
			mov	eax,x;
#define X(a) dword ptr [eax + (a*4)]
						//						{0			1			2			3			4			5			6			7			8}
			fld X(0);	//ld r1,X(0)			{																								r1}
			fld X(1);	//ld r2,X(1)			{																					r2,			r1}
			fld st(1);	//ld r4,r1				{																		r4,			r2,			r1}
			fxch st(2);	//						{																		r1,			r2,			r4}
			fsub X(4);	//r1-X(4)				{																		r1,			r2,			r4}
			fxch st(1);	//						{																		r2,			r1,			r4}
			fsub X(3);	//r2-X(3)				{																		r2,			r1,			r4}
			fxch st(2);	//						{																		r4,			r1,			r2}		
			fadd X(4);	//r4+X(4)				{																		r4,			r1,			r2}
			fld X(1);	//ld r3,X(1)			{															r3,			r4,			r1,			r2}
			fxch st(3);	//						{															r2,			r4,			r1,			r3}
			fmul Sec2;	//r2*1/sqrt2			{															r2,			r4,			r1,			r3}
			fld X(2);	//ld r5,X(2)			{												r5,			r2,			r4,			r1,			r3}
			fxch st(4);	//						{												r3,			r2,			r4,			r1,			r5}
			fadd X(3);	//r3+X(3)				{												r3,			r2,			r4,			r1,			r5}
			fxch st(4);	//						{												r5,			r2,			r4,			r1,			r3}
			fadd st(0),st(2);	//r5+r4			{												r5,			r2,			r4,			r1,			r3}
			fxch st(2);	//						{												r4,			r2,			r5,			r1,			r3}
			fsub X(2);	//r4-X[2]				{												r4,			r2,			r5,			r1,			r3}
			fld st(1);	//ld r6,r2				{									r6,			r4,			r2,			r5,			r1,			r3}
			fld st(5);	//ld r7,r3				{						r7,			r6,			r4,			r2,			r5,			r1,			r3}
			fxch st(1);	//						{						r6,			r7,			r4,			r2,			r5,			r1,			r3}
			fadd st(0),st(5);	//r6+r1			{						r6,			r7,			r4,			r2,			r5,			r1,			r3}
			fxch st(2);	//						{						r4,			r7,			r6,			r2,			r5,			r1,			r3}
			fstp X(2);	//from r4				{									r7,			r6,			r2,			r5,			r1,			r3}
			fadd st(0),st(3);	//r7+r5			{									r7,			r6,			r2,			r5,			r1,			r3}
			fxch st(2);	//						{									r2,			r6,			r7,			r5,			r1,			r3}
			fsubp st(4),st(0); //r1-r2			{												r6,			r7,			r5,			r1,			r3}
			fxch st(4);	//						{												r3,			r7,			r5,			r1,			r6}
			fsubp st(2),st(0); //r5-r3			{															r7,			r5,			r1,			r6}
			fxch st(3);	//						{															r6,			r5,			r1,			r7}
			fstp X(1);	//from r6				{																		r5,			r1,			r7}
			fxch st(2);	//						{																		r7,			r1,			r5}
			fstp X(0);	//from r7				{																					r1,			r5}
			fstp X(3);	//from r1				{																								r5}
			fstp X(4);	//from r5				{}
		}
#undef X
#endif
		return;
	}
	{
		const int l=(1<<lnh)+1;
		int n=l-1;
		const int h=n>>1;
		const int hp1=h+1;
		float *secants = Secants[lnh];
		float *x1=currentScratch;
		float *x2=x1+hp1;
		
		currentScratch=x2+hp1;
// */
#ifndef _USE_ASM
		int i;
		for (i=0;i<h;++i){
			x1[i]=x[i]+x[l-i-1];
			x2[i]=(x[i]-x[l-i-1])* secants[i];
		}
		x1[h]=x[h];
		x2[h]=0;
// */
#else
//		Note, the assembly language version of the loop is doubled (2 per iteration)
		_asm {
			mov edx,l;
			mov ebx,-4;
			mov esi,x;			//x is			esi
			lea edx,[edx*4];
			mov ecx,h;			//h*4 will be	[esp]
			mov eax,x1;			//x1 is			eax
			add ebx,esi;		//&x[l-i-1] is	ebx
			lea ecx,[ecx*4];
			mov	edi,x2;			//x2 is			edi
			add ebx,edx;
			mov edx, secants;	//secants		edx
			push ebp;
			mov ebp,ecx;
			xor ecx,ecx;		//i*4 is		ecx
#define rx esi
#define rh ebp
#define rx1 eax
#define rx2 edi
#define rxend ebx
#define i ecx
#define rsec edx
			fld dword ptr [rxend];	//ld r1,dword ptr [rxend]	{r1}
			fld dword ptr [rx];		//ld r2,dword ptr [rx]		{r2,r1}
back:;
			fld dword ptr [rxend-4];//ld r3,dword ptr [rxend-4]	{r3,r2,r1}
			fld dword ptr [rx+i+4];	//ld r4,dword ptr [rx+i+4]	{r4,r3,r2,r1}
			fld st(3);				//ld r5,r1					{r5,r4,r3,r2,r1}
			fsubr st(0),st(3);		//r2-r5						{r5,r4,r3,r2,r1}
			fxch st(3);				//							{r5,r4,r3,r2,r1}
			faddp st(4),st(0);		//r2+r1						{r4,r3,r5,r1}
			fld st(1);				//ld r2,r3					{r2,r4,r3,r5,r1}
			fsubr st(0),st(1);		//r4-r2						{r2,r4,r3,r5,r1}
			fxch st(3);				//							{r2,r4,r3,r5,r1}
			fmul dword ptr [rsec+i];//r5*dword ptr [rsec+i]		{r5,r4,r3,r2,r1}
			lea i,[i+8];
			lea rxend,[rxend-8];
			cmp i,rh;
			fld dword ptr [rsec+i-4];//ld r6,dword ptr [rsec+i-4]{r6,r5,r4,r3,r2,r1}
			fmulp st(4),st(0);		//r6*r2						{r5,r4,r3,r2,r1}
			fxch st(4);				//							{r5,r4,r3,r2,r1}
			fstp dword ptr[rx1+i-8];//from r1					{r4,r3,r2,r5}
			fxch st(3);				//							{r4,r3,r2,r5}
			fstp dword ptr[rx2+i-8];//from r5					{r3,r2,r4}
			fxch st(2);				//							{r3,r2,r4}
			faddp st(2),st(0);		//r4+r3						{r2,r3}
			fstp dword ptr[rx2+i-4];//from r2					{r3}
			fld dword ptr [rx+i];	//ld r2,dword ptr [rx+i]	{r2,r3}
			fld dword ptr [rxend];	//ld r1,dword ptr [rxend]	{r1,r2,r3}
			fxch st(2);				//							{r1,r2,r3}
			fstp dword ptr[rx1+i-4];//from r3					{r2,r1}
			jne back;

			fstp dword ptr [rx1+i];	//from r2					{r1}
			mov rx1,0;				//same bit pattern as 0.0f
			fsubp st(0),st(0);
			pop ebp;
			mov [rx2+i],rx1;//x2[h]=0;

#undef rx
#undef rh
#undef rx1
#undef rx2
#undef rxend
#undef i
#undef rsec 
		}
#endif
		--lnh;
		Dct(x1);	
		Dct(x2);	
		++lnh;

#ifndef _USE_ASM
		for (i=0;i<h;++i){
			*x++ = x1[i];
			*x++ = x2[i]+x2[i+1];
		}
		*x=x1[h];
#else

//		Note, the assembly language version of the loop is doubled (2 per iteration)

		_asm {
			mov edx,h;
			mov edi,x;
			mov esi,x1;
			mov ecx,0;
			mov ebx,x2;
			lea edx,[edx*4-16];
			fld dword ptr [ebx];//x2[0]

back2:;
			mov eax,[esi+ecx];
			fld dword ptr [ebx+ecx+4];	//x2[i+1] x2[i]
			fxch st(1);					//x2[i] x2[i+1] 
			fadd st(0),st(1);			//x2[i]+x2[i+1] x2[i+1] 
			mov [edi],eax;		

			

			fld dword ptr [ebx+ecx+8];	//x2[i+2] x2[i]+x2[i+1] x2[i+1] 
			fxch st(2);					//x2[i+1] x2[i]+x2[i+1] x2[i+2] 
			fadd st(0),st(2);			//x2[i+1]+x2[i+2] x2[i]+x2[i+1] x2[i+2] 
			mov eax,[esi+ecx+4];

			

			fld dword ptr [ebx+ecx+12];	//x2[i+3] x2[i+1]+x2[i+2] x2[i]+x2[i+1] x2[i+2] 
			fxch st(3);					//x2[i+2] x2[i+1]+x2[i+2] x2[i]+x2[i+1] x2[i+3] 
			fadd st(0),st(3);			//x2[i+2]+x2[i+3] x2[i+1]+x2[i+2] x2[i]+x2[i+1] x2[i+3] 
			fxch st(1);					//x2[i+1]+x2[i+2] x2[i+2]+x2[i+1] x2[i]+x2[i+1] x2[i+3] 
			fld dword ptr [ebx+ecx+16];	//x2[i+4] x2[i+1]+x2[i+2] x2[i+2]+x2[i+3] x2[i]+x2[i+1] x2[i+3] 
			fxch st(4);
			fadd st(0),st(4);			//x2[i+3]+x2[i+4] x2[i+1]+x2[i+2] x2[i+2]+x2[i+3] x2[i]+x2[i+1] x2[i+4] 
			fxch st(3);					//x2[i]+x2[i+1] x2[i+1]+x2[i+2] x2[i+2]+x2[i+3] x2[i+3]+x2[i+4] x2[i+4] 
			fstp [edi+4];				//x2[i+1]+x2[i+2] x2[i+2]+x2[i+3] x2[i+3]+x2[i+4] x2[i+4] 
			mov [edi+8],eax;		
			mov eax,[esi+ecx+8];


			fstp [edi+12];
			mov [edi+16],eax;		
			mov eax,[esi+ecx+12];


			fstp [edi+20];
			mov [edi+24],eax;		



			cmp ecx,edx;

			
			fstp [edi+28];
			


			lea ecx,[ecx+16];
			lea edi,[edi+32];


			jne back2;

			mov eax,[esi+ecx];
			

			fsubp st(0),st(0); 
			mov [edi],eax;		

		
		}
#endif
		currentScratch = x1;
	}
}



void QFT::Dst(float *x)
{
	if (lnh==3){
#ifndef _USE_ASM
		const float t=x[3];
		double x1_0,x1_1,x1_2;
		double x2_0,x2_1,x2_2;

		x1_0=x[0]-x[6];
		x2_0=(x[0]+x[6])* sec1;
		x1_1=x[1]-x[5];
		x2_1=(x[1]+x[5])* sec2;
		x1_2=x[2]-x[4];
		x2_2=(x[2]+x[4])* sec3;
		{
			const double t=0.70710678118654*(x1_0+x1_2);
			const double t2=x1_1;
			x1_1=x1_0-x1_2;
			x1_0=(float)(t+t2);
			x1_2=(float)(t-t2);
		}
		{
			const double t=0.70710678118654*(x2_0+x2_2);
			const double t2=x2_1;
			x2_1=x2_0-x2_2;
			x2_0=(float)(t+t2);
			x2_2=(float)(t-t2);
		}
		x[0]=float(t+x2_0);
		x[1]=(float)x1_0;

		x[2] = float(x2_0+x2_1-t);
		x[3] = (float)x1_1;

		x[4] = float(x2_1+x2_2+t);
		x[5] = (float)x1_2;

		x[6]=float(x2_2-t);
#else
		_asm{
			mov	eax,x;
#define X(a) dword ptr [eax + (a*4)]
			fld X(0);	//ld r1,X(0)		{r1}
			fld X(1);	//ld r2,X(1)		{r2,r1}
			fld st(1);	//ld r3,r1			{r3,r2,r1}
			fld X(2);	//ld r5,X(2)		{r5,r3,r2,r1}
			fld st(2);	//ld r4,r2			{r4,r5,r3,r2,r1}
			fld st(1);	//ld r6,r5			{r6,r4,r5,r3,r2,r1}
			fadd X(4);	//r6+X(4)			{r6,r4,r5,r3,r2,r1}
			fxch st(1);	//					{r6,r4,r5,r3,r2,r1}
			fadd X(5);	//r4+X(5)			{r4,r6,r5,r3,r2,r1}
			fxch st(3);	//					{r4,r6,r5,r3,r2,r1}
			fadd X(6);	//r3+X(6)			{r3,r6,r5,r4,r2,r1}
			fxch st(1);	//					{r3,r6,r5,r4,r2,r1}
			fmul Sec3;	//r6*Sec3			{r6,r3,r5,r4,r2,r1}
			fxch st(5);	//					{r6,r3,r5,r4,r2,r1}
			fsub X(6);	//r1-X(6)			{r1,r3,r5,r4,r2,r6}
			fxch st(3);	//					{r1,r3,r5,r4,r2,r6}
			fmul Sec2;	//r4*Sec2			{r4,r3,r5,r1,r2,r6}
			fld st(5);	//ld r7,r6			{r7,r4,r3,r5,r1,r2,r6}
			fxch st(5);	//					{r7,r4,r3,r5,r1,r2,r6}
			fsub X(5);	//r2-X(5)			{r2,r4,r3,r5,r1,r7,r6}
			fxch st(2);	//					{r2,r4,r3,r5,r1,r7,r6}
			fmul Sec1;	//r3*Sec1			{r3,r4,r2,r5,r1,r7,r6}
			fxch st(3);	//					{r3,r4,r2,r5,r1,r7,r6}
			fsub X(4);	//r5-X(4)			{r5,r4,r2,r3,r1,r7,r6}
			fld st(4);	//ld r8,r1			{r8,r5,r4,r2,r3,r1,r7,r6}
			fxch st(6);	//					{r8,r5,r4,r2,r3,r1,r7,r6}
			fadd st(0),st(4); //r7+r3		{r7,r5,r4,r2,r3,r1,r8,r6}
			fxch st(6);	//					{r7,r5,r4,r2,r3,r1,r8,r6}
			fadd st(0),st(1); //r8+r5		{r8,r5,r4,r2,r3,r1,r7,r6}
			fxch st(7);	//					{r8,r5,r4,r2,r3,r1,r7,r6}
			fsubp st(4),st(0); //r3-r6		{r5,r4,r2,r3,r1,r7,r8}
			fxch st(5);	//					{r5,r4,r2,r3,r1,r7,r8}
			fmul Sec2;	//r7*Sec2			{r7,r4,r2,r3,r1,r5,r8}
			fxch st(5);	//					{r7,r4,r2,r3,r1,r5,r8}
			fsubp st(4),st(0); //r1-r5		{r4,r2,r3,r1,r7,r8}
			fxch st(5);	//					{r4,r2,r3,r1,r7,r8}
			fmul Sec2;	//r8*Sec2			{r8,r2,r3,r1,r7,r4}
			fld st(5);	//ld r6,r4			{r6,r8,r2,r3,r1,r7,r4}
			fadd st(0),st(5); //r6+r7		{r6,r8,r2,r3,r1,r7,r4}
			fxch st(5);	//					{r6,r8,r2,r3,r1,r7,r4}
			fsubrp st(6),st(0); //r7-r4		{r8,r2,r3,r1,r6,r4}
			fld X(3);	//ld r7,X(3)		{r7,r8,r2,r3,r1,r6,r4}
			fld st(2);	//ld r5,r2			{r5,r7,r8,r2,r3,r1,r6,r4}
			fxch st(1);	//					{r5,r7,r8,r2,r3,r1,r6,r4}
			fadd st(0),st(6); //r7+r6		{r7,r5,r8,r2,r3,r1,r6,r4}
			fxch st(6);	//					{r7,r5,r8,r2,r3,r1,r6,r4}
			fadd st(0),st(4); //r6+r3		{r6,r5,r8,r2,r3,r1,r7,r4}
			fxch st(4);	//					{r6,r5,r8,r2,r3,r1,r7,r4}
			fadd X(3);	//r3+X(3)			{r3,r5,r8,r2,r6,r1,r7,r4}
			fxch st(1);	//					{r3,r5,r8,r2,r6,r1,r7,r4}
			fadd st(0),st(2); //r5+r8		{r5,r3,r8,r2,r6,r1,r7,r4}
			fxch st(2);	//					{r5,r3,r8,r2,r6,r1,r7,r4}
			fsubrp st(3),st(0); //r8-r2		{r3,r5,r2,r6,r1,r7,r4}
			fadd st(0),st(6); //r3+r4		{r3,r5,r2,r6,r1,r7,r4}
			fxch st(3);	//					{r3,r5,r2,r6,r1,r7,r4}
			fsub X(3);	//r6-X(3)			{r6,r5,r2,r3,r1,r7,r4}
			fxch st(5);	//					{r6,r5,r2,r3,r1,r7,r4}
			fstp X(0);	//from r7			{r5,r2,r3,r1,r6,r4}
			fxch st(5);	//					{r5,r2,r3,r1,r6,r4}
			fsub X(3);	//r4-X(3)			{r4,r2,r3,r1,r6,r5}
			fxch st(5);	//					{r4,r2,r3,r1,r6,r5}
			fstp X(1);	//from r5			{r2,r3,r1,r6,r4}
			fstp X(5);
			fstp X(4);
			fstp X(3);
			fstp X(2);
			fstp X(6);
#undef X
		}
#endif
		return;
	}else{
		const int l=(1<<lnh)-1;
		int n=l+1;
		const int h=n>>1;
		const int hm1=h-1;
		float *x1=currentScratch;
		float *x2=x1+hm1;
		float *secants = Secants[lnh]+1;

		currentScratch=x2+hm1;
#ifndef _USE_ASM
		int i;

		for (i=0;i<hm1;++i){
			x1[i]=x[i]-x[l-i-1];
			x2[i]=(x[i]+x[l-i-1])* *secants++;
		}
#else
		///* 		Note, the assembly language version of the loop is doubled (2 per iteration)
		_asm {
			mov edx,l;
			mov ebx,-4;
			mov esi,x;			//x is			esi
			lea edx,[edx*4];
			mov ecx,h;			//h*4 will be	[esp]
			mov eax,x1;			//x1 is			eax
			add ebx,esi;		//&x[l-i-1] is	ebx
			lea ecx,[ecx*4-8];
			mov	edi,x2;			//x2 is			edi
			add ebx,edx;
			mov edx, secants;	//secants		edx
			push ebp
			mov ebp,ecx;
			mov ecx,0;			//i*4 is		ecx
#define rx esi
#define rh ebp
#define rx1 eax
#define rx2 edi
#define rxend ebx
#define i ecx
#define rsec edx
			fld dword ptr [rxend];	//ld r1,dword ptr [rxend]	{[rxend]}
			fld dword ptr [rx];		//ld r2,dword ptr [rx]		{[rx],[rxend]}
back:;
			fld dword ptr [rxend-4];//ld r3,dword ptr [rxend-4]	{[rxend-4],[rx+i],[rxend]}
			fld dword ptr [rx+i+4];	//ld r4,dword ptr [rx+i+4]	{[rx+i+4],[rxend-4],[rx+i],[rxend]}
			fld st(3);				//ld r5,r1					{[rxend],[rx+i+4],[rxend-4],[rx+i],[rxend]}
			fadd st(0),st(3);		//r2+r5						{[rx+i]+[rxend],[rx+i+4],[rxend-4],[rx+i],[rxend]}
			fxch st(3);				//							{[rx+i],[rx+i+4],[rxend-4],[rx+i]+[rxend],[rxend]}
			fsubrp st(4),st(0);		//r2+r1	 					{[rx+i+4],[rxend-4],[rx+i]+[rxend],[rx+i]-[rxend]}
			fld st(1);				//ld r2,r3					{[rxend-4],[rx+i+4],[rxend-4],[rx+i]+[rxend],[rx+i]-[rxend]}
			fadd st(0),st(1);		//r4-r2						{[rxend-4]+[rx+i+4],[rx+i+4],[rxend-4],[rx+i]+[rxend],[rx+i]-[rxend]}
			fxch st(3);				//							{[rx+i]+[rxend],[rx+i+4],[rxend-4],[rxend-4]+[rx+i+4],[rx+i]-[rxend]}
			fmul dword ptr [rsec+i];//r5*dword ptr [rsec+i]		{sec[i]*([rx+i]+[rxend]),[rx+i+4],[rxend-4],[rxend-4]+[rx+i+4],[rx+i]-[rxend]}
			lea i,[i+8];
			lea rxend,[rxend-8];
			cmp i,rh;
			fld dword ptr [rsec+i-4];//ld r6,dword ptr [rsec+i-4]{sec[i+4],sec[i]*([rx+i]+[rxend]),[rx+i+4],[rxend-4],[rxend-4]+[rx+i+4],[rx+i]-[rxend]}
			fmulp st(4),st(0);		//r6*r2						{sec[i]*([rx+i]+[rxend]),[rx+i+4],[rxend-4],sec[i+4]*([rxend-4]+[rx+i+4]),[rx+i]-[rxend]}
			fxch st(4);				//							{[rx+i]-[rxend],[rx+i+4],[rxend-4],sec[i+4]*([rxend-4]+[rx+i+4]),sec[i]*([rx+i]+[rxend])}
			fstp dword ptr[rx1+i-8];//from r1					{[rx+i+4],[rxend-4],sec[i+4]*([rxend-4]+[rx+i+4]),sec[i]*([rx+i]+[rxend])}
			fxch st(3);				//							{sec[i]*([rx+i]+[rxend]),[rxend-4],sec[i+4]*([rxend-4]+[rx+i+4]),[rx+i+4]}
			fstp dword ptr[rx2+i-8];//from r5					{[rxend-4],sec[i+4]*([rxend-4]+[rx+i+4]),[rx+i+4]}
			fsubp st(2),st(0);		//r4+r3						{sec[i+4]*([rxend-4]+[rx+i+4]),[rx+i+4]-[rxend-4]}
			fstp dword ptr[rx2+i-4];//from r2					{[rx+i+4]-[rxend-4]}
			fld dword ptr [rx+i];	//ld r2,dword ptr [rx+i]	{[rx+i],[rx+i+4]-[rxend-4]}
			fld dword ptr [rxend];	//ld r1,dword ptr [rxend]	{[rxend],[rx+i],[rx+i+4]-[rxend-4]}
			fxch st(2);				//							{[rx+i+4]-[rxend-4],[rx+i],[rxend]}
			fstp dword ptr[rx1+i-4]; //from r3					{[rx+i],[rxend]}
			jne back;

			fld st(0);											//{x[i],x[i],x[l-i]}
			fadd st(0),st(2);									//{x[i]+x[l-i],x[i],x[l-i]}
			fxch st(1);											//{x[i],x[i]+x[l-i],x[l-i]}
			fsubrp st(2),st(0);									//{x[i]+x[l-i],x[i]-x[l-i]}
			fmul dword ptr [rsec+i];							//{sec[i]*(x[i]+x[l-i]),x[i]-x[l-i]}
			fxch st(1);											//{x[i]-x[l-i],sec[i]*(x[i]+x[l-i])}
			fstp dword ptr[rx1+i];
			pop ebp;
			fstp dword ptr[rx2+i];
#undef rx
#undef rh
#undef rx1
#undef rx2
#undef rxend
#undef i
#undef rsec 
		}
#endif
		--lnh;
		Dst(x1);	
		Dst(x2);	
		++lnh;
#ifndef _USE_ASM
		float t;

		t=x[hm1];
		x[0]=t+x2[0];
		x[1]=x1[0];
		for (i=0;i<h-2;i+=2){
			x[2] = x2[i]+x2[i+1]-t;
			x[3] = x1[i+1];
			x[4] = x2[i+1]+x2[i+2]+t;
			x[5] = x1[i+2];
			x+=4;
		}
		x[2]=x2[i]-t;
// */
#else
		_asm {
#define X(n) dword ptr[edi+n]
#define X1(n) dword ptr[esi+n]
#define X2(n) dword ptr[ebx+n]

			
			
			mov edx,h;
			mov edi,x;
			mov esi,x1;
			mov ebx,x2;
			lea edx,[edx*4-8];
			xor ecx,ecx;
			push ebp;
#define i ecx
#define h edx
#define n1 eax
#define n2 ebp
#define f edx
			fld X(f+4);			//ld t1,X(f+4)	{X(f+4)}
			fld X2(0);			//ld t2,X2(0)	{X2(0),					X(f+4)}
//esi
			mov n1,X1(0);

			
			fadd st(0),st(1);	//t2+t1			{X2(0)+X(f+4),			X(f+4)}
back3:;	
			fld X2(i);			//ld t4,X2(i)	{X2(i),					X2(0)+X(f+4),			X(f+4)}
			fld X2(i+4);		//ld t3,X2(i+4)	{X2(i+4),				X2(i),					X2(0)+X(f+4),			X(f+4)}
			fadd st(1),st(0);	//t4+t3			{X2(i+4),				X2(i+4)+X2(i),			X2(0)+X(f+4),			X(f+4)}
			fadd X2(i+8);		//t3+X2(i+8)	{X2(i+8)+X2(i+4),		X2(i+4)+X2(i),			X2(0)+X(f+4),			X(f+4)}
//esi
			mov n2,X1(i+4);

			
			
			
			fxch st(1);			//				{X2(i+4)+X2(i),			X2(i+8)+X2(i+4),		X2(0)+X(f+4),			X(f+4)}
//edi
			mov X(4),n1;
			fsub st(0),st(3);	//t4-t1			{X2(i+4)+X2(i)-X(f+4),	X2(i+8)+X2(i+4),		X2(0)+X(f+4),			X(f+4)}
			fxch st(1);			//				{X2(i+8)+X2(i+4),		X2(i+4)+X2(i)-X(f+4),	X2(0)+X(f+4),			X(f+4)}
			fadd st(0),st(3);	//t3+t1			{X2(i+8)+X2(i+4)+X(f+4),X2(i+4)+X2(i)-X(f+4),	X2(0)+X(f+4),			X(f+4)}
			fxch st(2);			//				{X2(0)+X(f+4),			X2(i+4)+X2(i)-X(f+4),	X2(i+8)+X2(i+4)+X(f+4),	X(f+4)}
			fstp X(0);			//from t2		{X2(i+4)+X2(i)-X(f+4),	X2(i+8)+X2(i+4)+X(f+4),	X(f+4)}
//esi
			mov n1,X1(i+8);

			lea i,[i+8];
//edi
			mov X(12),n2;
			
			
			
			
			fstp X(8);			//from t4		{X2(i+8)+X2(i+4)+X(f+4),X(f+4)}
			cmp i,f;
//edi change
			lea edi,[edi+16];
			jne back3;

			fxch st(1);			//				{X(f+4),				X2(i+8)+X2(i+4)+X(f+4)}
			fsubr X2(i);		//x2(i)-t1		{x2(i)-X(f+4),			X2(i+8)+X2(i+4)+X(f+4)}
			mov X(4),n1;

			fxch st(1);			//				{X2(i+8)+X2(i+4)+X(f+4),x2(i)-X(f+4)}
			pop ebp;
			fstp X(0);			//from t3		{x2(i)-X(f+4)}
			fstp X(8);			//from t1		{}
#undef X
#undef X1
#undef X2
#undef f
#undef i
#undef h 
#undef n1 
#undef n2 

		
		
		}
#endif
		currentScratch = x1;
	}
}


void QFT::Forward(float *R, float *I, float *x, int _lnh)
{
//	Profile(QFT_Foward);
	int h;
	int n=1<<_lnh;
	CriticalSectionEntry ce(cs);
	assert(_lnh<=maxln);

	lnh = _lnh-1;

	h=n>>1;
	R[0]=x[0];
	R[h]=x[h];
#ifndef _USE_ASM
	int i;

	for (i=1;i<h-1;i+=2){
		const double t1 = x[i];
		const double t2 = x[n-i];
		const double t3 = x[i+1];
		const double t4 = x[n-i-1];
		R[i]=float(t1+t2);
		I[i]=float(t2-t1);
		R[i+1]=float(t3+t4);
		I[i+1]=float(t4-t3);
	}
	{
		const double t1 = x[i];
		const double t2 = x[n-i];
		R[i]=float(t1+t2);
		I[i]=float(t2-t1);
	}
#else
	_asm {
		mov edx,h;
		mov ebx,x;
		mov eax,n;
		mov ecx,4;
		lea edx,[edx*4-12];
		mov esi,R;
		mov edi,I;
		lea eax,[ebx+eax*4-8];
back:;
		cmp ecx,edx;
		fld dword ptr[ebx+ecx]; //ld t1,dword ptr[ebx+ecx]
		fld dword ptr[eax+4]; //ld t2,dword ptr[eax+4]
		fld dword ptr[ebx+ecx+4]; //ld t3,dword ptr[ebx+ecx+4]
		fld dword ptr[eax]; //ld t4,dword ptr[eax]
		fld st(3); //ld t5,t1
		fadd st(0),st(3); //t5+t2
		fxch st(3); //
		fsubrp st(4),st(0); //t2-t1
		fld st(1); //ld t2,t3
		fadd st(0),st(1); //t2+t4
		fxch st(1); //
		fsubrp st(2),st(0); //t4-t3			
		fxch st(2); //						
		fstp dword ptr[esi+ecx]; //from t5	
		fxch st(2); //						
		fstp dword ptr[edi+ecx]; //from t1 
		fstp dword ptr[esi+ecx+4]; //from t2
		fstp dword ptr[edi+ecx+4]; //from t3
		lea ecx,[ecx + 8];
		lea eax,[eax - 8];
		jne back;

		fld dword ptr[ebx+ecx]; //ld t1,dword ptr[ebx+ecx]
		fld dword ptr[eax+4]; //ld t2,dword ptr[eax+4]
		fld st(1); //ld t5,t1
		fadd st(0),st(1); //t5+t2
		fxch st(1); //
		fsubrp st(2),st(0); //t2-t1
		fstp dword ptr[esi+ecx]; //from t5
		fstp dword ptr[edi+ecx]; //from t1
	
	}
#endif
	I[0]=0.0;
	Dct(R);
	Dst(I+1);
	I[n>>1]=0.0;
}

void QFT::ReverseNoUnpack(float *R, float *I, int _lnh)
{
//	Profile(QFT_Reverse);
	int h;
	int n=1<<_lnh;
	CriticalSectionEntry ce(cs);

	assert(_lnh<=maxln);

	lnh = _lnh-1;
	h=n>>1;

	R[0]*=0.5;
	R[h]*=0.5;
	Dct(R);
	Dst(I+1);
	I[0]=0.0f;
}

void QFT::ReverseHalf(float *x, float *R, float *I, int _lnh)
{
//	Profile(QFT_Reverse);
	int h;
	int n=1<<_lnh;
	CriticalSectionEntry ce(cs);

	assert(_lnh<=maxln);

	lnh = _lnh-1;
	h=n>>1;

	R[0]*=0.5;
	R[h]*=0.5;
	Dct(R);
	Dst(I+1);
//	const double nr=2.0/n;  We assume that the normalization was in the convolution already
//  multiply the cooeficients by 2.0/_lnh beforehand
	x[0]=float(R[0]);
 
	for (int i=1;i<h;i+=2) {
		x[i]=float(R[i]-I[i]);
		x[i+1]=float(R[i+1]-I[i+1]);
	}
}

void QFT::Reverse(float *x, float *R, float *I, int _lnh)
{
//	Profile(QFT_Reverse);
	int h;
	int n=1<<_lnh;
	CriticalSectionEntry ce(cs);

	assert(_lnh<=maxln);

	lnh = _lnh-1;
	h=n>>1;

	R[0]*=0.5;
	R[h]*=0.5;
	Dct(R);
	Dst(I+1);
	const double nr=2.0/n;
	x[0]=float(R[0]*nr);
#ifndef _USE_ASM
	for (int i=1;i<h;i+=2) {
		const double t1 = nr*R[i];
		const double t2 = nr*I[i];
		const double t3 = nr*R[i+1];
		const double t4 = nr*I[i+1];
		x[i]=float(t1-t2);
		x[n-i]=float(t1+t2);
		x[i+1]=float(t3-t4);
		x[n-i-1]=float(t3+t4);
	}
#else
	_asm {
		mov edi,x
		mov ebx,n;
		mov esi,h;
		mov eax,R;
		mov edx,I;
		lea ebx,[edi+ebx*4-4];
		mov ecx,4;
		lea esi,[esi*4];
		fld nr		//ld nr,nr		{nr}
#define R eax
#define I edx
#define x edi
#define rx ebx
#define i ecx
#define h esi
back:;
		fld [R+i]	//ld r1,[R+i]	{[R+i],				nr}
		fld [I+i]	//ld r2,[I+i]	{[I+i],				[R+i],				nr}
		fxch st(1); //				{[R+i],				[I+i],				nr}
		fmul st(0),st(2); //r1*nr	{nr*[R+i],			[I+i],				nr}
		fld [R+i+4];//ld r3,[R+i+4]	{[R+i+4],			nr*[R+i],			[I+i],				nr}
		fxch st(2); //				{[I+i],				nr*[R+i],			[R+i+4],			nr}
		fmul st(0),st(3); //r2*nr	{nr*[I+i],			nr*[R+i],			[R+i+4],			nr}
		fld [I+i+4]; //ld r4,[I+i+4]{[I+i+4],			nr*[I+i],			nr*[R+i],			[R+i+4],			nr}
		fxch st(3); //				{[R+i+4],			nr*[I+i],			nr*[R+i],			[I+i+4],			nr}
		fmul st(0),st(4); //r3*nr	{nr*[R+i+4],		nr*[I+i],			nr*[R+i],			[I+i+4],			nr}
		fld st(2);	//ld r5,r1		{nr*[R+i],			nr*[R+i+4],			nr*[I+i],			nr*[R+i],			[I+i+4],	nr}
		fxch st(4); //				{[I+i+4],			nr*[R+i+4],			nr*[I+i],			nr*[R+i],			nr*[R+i],	nr}
		fmul st(0),st(5); //r4*nr	{nr*[I+i+4],		nr*[R+i+4],			nr*[I+i],			nr*[R+i],			nr*[R+i],	nr}
		fxch st(4); //				{nr*[R+i],			nr*[R+i+4],			nr*[I+i],			nr*[R+i],			nr*[I+i+4],	nr}
		fsub st(0),st(2); //r5-r2	{nr*([R+i]-[I+i]),	nr*[R+i+4],			nr*[I+i],			nr*[R+i],			nr*[I+i+4],	nr}
		fxch st(3) //				{nr*[R+i],			nr*[R+i+4],			nr*[I+i],			nr*([R+i]-[I+i]),	nr*[I+i+4],	nr}
		faddp st(2),st(0); //r1+r2	{nr*[R+i+4],		nr*([R+i]+[I+i]),	nr*([R+i]-[I+i]),	nr*[I+i+4],			nr}
		add i,8;
		fld st(0);	//ld r1,r3		{nr*[R+i+4],		nr*[R+i+4],			nr*([R+i]+[I+i]),	nr*([R+i]-[I+i]),	nr*[I+i+4],	nr}
		sub rx,8;
		fsub st(0),st(4); //r1-r4	{nr*([R+i+4]-[I+i+4]),nr*[R+i+4],		nr*([R+i]+[I+i]),	nr*([R+i]-[I+i]),	nr*[I+i+4],	nr}
		fxch st(3); //				{nr*([R+i]-[I+i]),	nr*[R+i+4],			nr*([R+i]+[I+i]),	nr*([R+i+4]-[I+i+4]),nr*[I+i+4],nr}
		fstp [x+i-8];//from r5		{nr*[R+i+4],		nr*([R+i]+[I+i]),	nr*([R+i+4]-[I+i+4]),nr*[I+i+4],nr}
		faddp st(3),st(0); //r3+r4	{nr*([R+i]+[I+i]),	nr*([R+i+4]-[I+i+4]),nr*([R+i+4]+[I+i+4]),nr}
		cmp i,h;
		fstp [rx+8];//from r2		{nr*([R+i+4]-[I+i+4]),nr*([R+i+4]+[I+i+4]),nr}
		fstp [x+i-4]; //from r1		{nr*([R+i+4]+[I+i+4]),nr}
		fstp [rx+4]; //from r4		{nr}
		jl back;

		fsubp st(0),st(0);
#undef R 
#undef I 
#undef x 
#undef rx 
#undef i 
#undef h
	}
#endif
}

//turns a spectrum into a spectrum of even samples and a spectrum of odd samples
void QFT::DecomposeEvenOdd(float *re,float *ie,float *ro,float *io, float *R, float *I, int _lnh)
{
/*complex version
	complex<float> p(cos(-2*PI/n),sin(-2*PI/n));
	vector<float> fe(hh+1,0.0);
	vector<float> fo(hh+1,0.0);
	fe[0]=(f[0]+f[h])*0.5;
	fo[0]=(f[0]-f[h])*0.5;

    int j;
	for (j=1;j<=hh;++j) {
		fe[j]=(f[j]+conjugate(f[h-j]))*0.5;
		fo[j]=(f[j]-conjugate(f[h-j]))*p^(-j)*0.5;
	};
*/
	float *rotations = Secants.Rotations(_lnh)+2;
	const long n = 1<<_lnh;
	const int h=n>>1;
	const int hh=h>>1;

	re[0]=float((R[0]+R[h])*0.5);
	ro[0]=float((R[0]-R[h])*0.5);
	ie[0]=	io[0]= 0.0;

	for (int j=1;j<hh;++j) {
		re[j]=float((R[j]+R[h-j])*0.5);
		ie[j]=float((I[j]-I[h-j])*0.5);
		const float rx = float((R[j]-R[h-j])*0.5);
		const float ix = float((I[j]+I[h-j])*0.5);
		ro[j]=rx*rotations[0]+ix*rotations[1];
		io[j]=ix*rotations[0]-rx*rotations[1];
		rotations+=2;
	};	

	re[hh]=R[hh];
	ro[hh]=-I[hh];
	ie[hh]=	io[hh]= 0.0;
}
//combines a spectrum of even samples with a spectrum of odd samples
void QFT::CombineEvenOdd(float *R, float *I, float *re,float *ie,float *ro,float *io, int _lnh)
{
/*complex version
	vector<float> r(h+1,0.0);
	complex<float> p(cos(-2*PI/n),sin(-2*PI/n));
	r[0]=fe[0]+fo[0];
	r[h]=fe[0]-fo[0];
	for(j=1;j<hh;++j){
		r[j]=fe[j]+fo[j]*p^j;
	};
	for(;j<h;++j){
		r[j]=conjugate(fe[h-j])+conjugate(fo[h-j])*p^(j);
	};
*/
	float *rotations = Secants.Rotations(_lnh);
	const long n = 1<<_lnh;
	const int h=n>>1;
	const int hh=h>>1;

	float sr=*re - *ro;

	*R=re[0]+ro[0];
	*I=0.0;
	for(int i=1;i<hh;++i){
		R[i] = ro[i]*rotations[i+i]-io[i]*rotations[1+i+i] + re[i];
		I[i] = io[i]*rotations[i+i]+ro[i]*rotations[1+i+i] + ie[i];
	}

	rotations += n-2;

	R += h;
	I += h;

	*R-- = sr;
	*I-- = 0.0;
	
	for(i=1;i<=hh;++i){
		*R-- = ro[i] * rotations[0] + io[i] * rotations[1] + re[i];
		*I-- = ro[i] * rotations[1] - io[i] * rotations[0] - ie[i];
		rotations -= 2;
	}
}

void QFT::jhfftu(float *R, float *I, float *x)
{
	if (lnh>12){
		const long n = 1<<lnh;
		const int h=n>>1;
		const int hh=h>>1;
		const int ansLen = hh+1;
		int i;
		float *rotations = Secants.Rotations(lnh);
		float *fo = currentScratch;
		float *er = fo+h;
		float *ei = er+ansLen;
		float *fe = ei+ansLen;
		float *or, *oi;
		currentScratch = fe+h;
#ifndef _USE_ASM
		for(i=0;i<h;++i){
			fe[i]=x[i+i];
			fo[i]=x[1+i+i];
		}
#else
		_asm {
			xor ecx,ecx;
			mov esi,fe;
			mov edi,fo;
			mov ebx,x;
			mov eax,h;
			lea eax,[eax*4];
			push eax;
			xchg ebp,[esp];

			mov eax,[ebx];
			mov edx,[ebx+4];
			lea ebx,[ebx+8];
back:		
			cmp ecx,ebp;
			mov	[esi+ecx],eax;
			mov eax,[ebx];
			mov [edi+ecx],edx;
			lea ecx,[ecx+4];
			mov edx,[ebx+4];
			lea ebx,[ebx+8];
			jne back;
			
			pop ebp;
		}
#endif
		--lnh;
		jhfftu(er,ei,fe);
		or=fe;
		oi=or+ansLen;
		currentScratch=oi+ansLen;
		jhfftu(or,oi,fo);
		++lnh;
		{
			float sr=*er - *or;
			float si=*ei - *oi;

			*R=er[0]+or[0];
			*I=ei[0]+oi[0];
			for(i=1;i<hh;++i){
				R[i] = or[i]*rotations[i+i]-oi[i]*rotations[1+i+i] + er[i];
				I[i] = oi[i]*rotations[i+i]+or[i]*rotations[1+i+i] + ei[i];
			}

			rotations += n-2;

			R += h;
			I += h;

			*R-- = sr;
			*I-- = si;
			
			for(i=1;i<=hh;++i){
				*R-- = or[i] * rotations[0] + oi[i] * rotations[1] + er[i];
				*I-- = or[i] * rotations[1] - oi[i] * rotations[0] - ei[i];
				rotations -= 2;
			}

		}

		currentScratch = fo;		
	}else{
		int n=lnh;
		Forward(R,I,x,lnh);
		lnh=n;
	}
}
