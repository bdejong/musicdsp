#include "stdafx.h"
#include <stdio.h>
#include <math.h>
#include <vector>
#include "qft.h"

using namespace std;


union int64Union
{
	struct {
		int low;
		int high;
	} ints;
	__int64 int64;
};

inline __int64 GetTimeStamp()
{
	int64Union retval;
	__asm{
		rdtsc;
		mov retval.ints.low,eax;
		mov retval.ints.high,edx;
	}
	return retval.int64;
}



void testsingle(int fftlenln2)
{
	const int fftlen = 1<<fftlenln2;
	const int freqlen = 1+(1<<(fftlenln2-1));
	
	
	//Warning there's some weirdness where at some block sizes
	//(128 & 256 I think)
	//allocating the data and real and imaginary blocks 
	//consecutively slows the program down by 10000%
	//??? I don't know why
	//Usually I cludge around this by using STL or new to 
	//allocate data.
	vector<float> destI(freqlen);
	vector<float> destR(freqlen);
	vector<float> source(fftlen);
	
	//if we leave zeros in we'd be testing the slowness of denormalized
	//numbers... So we fill with noise
	int i,j;
	srand(100);
	for (i=0;i<fftlen;++i){
		source[i]=rand();
	}
	
	__int64 timeper1000 = 0;
	__int64 first = 0;
	
	for (j=0;j<1001;++j){
		__int64 startTime = GetTimeStamp();
		qft.Forward(&destR[0],&destI[0],&source[0],fftlenln2);
		qft.Reverse(&source[0],&destR[0],&destI[0],fftlenln2);
		__int64 curtime = GetTimeStamp()-startTime;
		if (first==0) first = curtime;
		else timeper1000 += curtime;
		srand(100);
		for (i=0;i<fftlen;++i){
			double value = rand();
			if (floor(source[i]+.5) != value)
				printf("function failed at %d %lf should be %lf\n",i,source[i],value);
			source[i]=value;
		}
		
	}
	printf("single precision QFT tranforms %d both ways in %d cycles %d the 1st time\n",
		fftlen,(int)(timeper1000/1000), (int)first);
}

void testdouble(int fftlenln2)
{
	const int fftlen = 1<<fftlenln2;
	const int freqlen = 1+(1<<(fftlenln2-1));
	
	
	//Warning there's some weirdness where at some block sizes
	//(128 & 256 I think)
	//allocating the data and real and imaginary blocks 
	//consecutively slows the program down by 10000%
	//??? I don't know why
	//Usually I cludge around this by using STL or new to 
	//allocate data.
	vector<double> destI(freqlen);
	vector<double> destR(freqlen);
	vector<double> source(fftlen);
	
	//if we leave zeros in we'd be testing the slowness of denormalized
	//numbers... So we fill with noise
	int i,j;
	srand(100);
	for (i=0;i<fftlen;++i){
		source[i]=rand();
	}
	
	__int64 timeper1000 = 0;
	__int64 first = 0;
	
	for (j=0;j<1001;++j){
		__int64 startTime = GetTimeStamp();
		dqft.Forward(&destR[0],&destI[0],&source[0],fftlenln2);
		dqft.Reverse(&source[0],&destR[0],&destI[0],fftlenln2);
		__int64 curtime = GetTimeStamp()-startTime;
		if (first==0) first = curtime;
		else timeper1000 += curtime;
		srand(100);
		for (i=0;i<fftlen;++i){
			double value = rand();
			if (floor(source[i]+.5) != value)
				printf("function failed at %d %lf should be %lf\n",i,source[i],value);
//			source[i]=value;
		}
		
	}
	printf("double precision QFT tranforms %d both ways in %d cycles %d the 1st time\n",
		fftlen,(int)(timeper1000/1000), (int)first);
}

void main()
{
	for (int i=4;i<14;++i) {
		testsingle(i);
		testdouble(i);
		printf("\n");
	}
}
