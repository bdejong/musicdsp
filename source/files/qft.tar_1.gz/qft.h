#ifndef _QFT_H
#define _QFT_H
#include <assert.h>
#include "criticalsection.h"

//This class initializes the tables used by the
//QFT class and the DQFT class
class SecantTable
{
	float **secants;
	float **rotations;
	int maxln;
public:
	float *operator [](int i) { return secants[i]; }
	float *Rotations(int i) { return rotations[i]; }
	SecantTable(int i);
	~SecantTable();
};

//Since the QFT routines are not entirely in-place
//they need to preallocate scratch memory.
//
//MaxQFT sets the size of the scratch pad
//
//maximum block length (2^17)
const int MaxQFT = 17;

//Other limitations:
//The DCT routine can't handle a block size less than 4
//The DST routine can't handle a block size less than 8
//The FFT routines (both forward and reverse) can't handle 
//block sizes less than 16

//Block sizes must be powers of two

//Warning there's some weirdness where at some block sizes
//(128 & 256 I think)
//allocating the data and real and imaginary blocks 
//consecutively slows the program down by 10000%
//??? I don't know why
//Usually I cludge around this by using STL or new to 
//allocate data.

//Note that since scratch pad memory is set aside
//it would not ordinarily be safe to use QFT from 
//multiple threads simultaniously.

//There are two provisions made for this:
//1. you can create more than one QFT object
//   and use different ones in different threads
//2. As currently written, a QFT object has a critical
//   section that makes it block when called called
//   simultanious from different threads.
//Alternately you might consider making the scratch 
//area thread local.

/*
The QFT and DQFT (double precision) classes supply the
following functions:

  1. Real valued FFT and inverse FFT functions.  Note that separate arrays are used
     for real and imaginary component of the resulting spectrum.

  2. Decomposition of a spectrum into a separate spectrum of the even samples
     and a spectrum of the odd samples.  This can be useful for building filter banks.

  3. Reconstituting a spectrum from separate spectrums of the even samples
     and odd samples.  This can be useful for building filter banks.

  4. A discrete Sin transform (a QFT decomposes an FFT into a DST and DCT).

  5. A discrete Cos transfrom.

  6. Since a QFT does it's last stage calculating from the outside in the last part
     can be left unpacked and only calculated as needed in the case where the entire
	 spectrum isn't needed (I used this for calculating correlations and convolutions
	 where I only needed half of the results).
	 ReverseNoUnpack()
	 UnpackStep()
	 and NegUnpackStep()
	 implement this functionality

  NOTE Reverse() normalizes its results (divides by one half the block length), but 
  ReverseNoUnpack() does not.

  7. Also if you only want the first half of the results you can call ReverseHalf()

  NOTE Reverse() normalizes its results (divides by one half the block length), but 
  ReverseHalf() does not.

  8. QFT is less numerically stable than regular FFTs.  With single precision calculations,
     a block length of 2^15 brings the accuracy down to being barely accurate enough.
	 At that size, single precision calculations tested sound files would occasionally have 
	 a sample off by 2, and a couple off by 1 per block. Full volume white noise would generate 
	 a few samples off by as much as 6 per block at the end, beginning and middle.

	 No matter what the inputs the errors are always at the same positions in the block.  
	 There some sort of cancelation that gets more delicate as the block size gets bigger.
	 
	 For the sake of doing convolutions and the like where the forward transform is
	 done only once for one of the inputs, I created a AccurateForward() function.
	 It uses a regular FFT algorithm for blocks larger than 2^12, and decomposes into even and 
	 odd FFTs recursively.

	 In any case you can always use the double precision routines to get more accuracy.
	 DQFT even has routines that take floats as inputs and return double precision
	 spectrum outputs.
*/

class QFT
{
	static SecantTable Secants;
	float *scratch;
	float *currentScratch;
	int lnh;
	int maxln;
//Since QFT uses a permanently allocated scratch space
//you can only be running one QFT per thread at a time.
//The reason I made this a class is so you CAN run
//simultanious transforms (by making multiple QFT objects).
	CriticalSection cs; 
	void Dct(float *x);
	void Dst(float *x);
	void jhfftu(float *R, float *I, float *x);
public:
	QFT(int _max=MaxQFT)
		:scratch(new float[(1<<(_max+3))+2*(_max+1)])
		,currentScratch(scratch)
		,maxln(_max)
	{
		assert(maxln<=MaxQFT);
	}
	~QFT()
	{
		delete [] scratch;
	}
	//Discrete Sine transform.  _lnh is the base two log of the block length.
	//Note that block sizes less than 8 (lnh=3) don't work.
	void Dst(float *x,int _lnh) 
	{ 
		CriticalSectionEntry ce(cs);
		lnh = _lnh; 
		Dst(x); 
	}
	//Discrete Cosine transform.  _lnh is the base two log of the block length.
	//Note that block sizes less than 4 (lnh=2) don't work.
	void Dct(float *x,int _lnh) 
	{ 
		CriticalSectionEntry ce(cs);
		lnh = _lnh; 
		x[0]*=.5; 
		x[1<<lnh]*=.5; 
		Dct(x); 
	}

	//FFT fowrard transform.
	//_lnh is the base two log of the length.  Note that block sizes less 
	//than 16 (lnh=4) don't work.
	//R gets the real part of the spectrum
	//I gets the imaginary part of the spectrum
	//If I remember properly, the order is from low frequencies to high
	//R and I must each have a length of "pow(2,(lnh-1))+1"
	//x is the source and has a length of "pow(2,(lnh))"
	//Note, the values in x are not changed. 

	//somewhat less accurate than AccurateForward for very long
	//blocks.  At a block length of 2^15, this is barely
	//accurate enough for 16 bit sound processing.
	//At 2^15, tested sound files would occasionally have a sample
	//off by 2, and a couple off by 1 per block. 
	//Full volume white noise would generate a few samples
	//off by as much as 6 per block at the end, beginning
	//and middle.
	void Forward(float *R, float *I, float *x, int _lnh);


	//Because my code uses ring buffers I have templates that act like arrays
	//but are not actually arrays.  This function takes x as any indexable type
	//and starts indexing into it as a position "pos"
	template <typename T>
	void ForwardFromTemplate(float *R, float *I, T& x, int pos, int _lnh)
	{
		int h;
		int i;
		int n=1<<_lnh;
		CriticalSectionEntry ce(cs);
		assert(_lnh<=maxln);

		h=n>>1;
		R[0]=x[pos];
		R[h]=x[pos+h];
		for (i=1;i<h;++i){
			const double t1 = x[pos+i];
			const double t2 = x[pos+n-i];
			R[i]=t1+t2;
			I[i]=t2-t1;
		}
		I[0]=0.0;
		lnh = _lnh-1;
		Dct(R);
		Dst(I+1);
		I[h]=0.0;
	}

	//Similar to above, gives a spectrum of even samples only.  The source is
	//assumed to be twice as long.
	template <typename T>
	void ForwardFromTemplateSkipOdd(float *R, float *I, T& x, int pos, int _lnh)
	{
		int h;
		int i;
		int n=pos+(2<<_lnh);
		CriticalSectionEntry ce(cs);
		assert(_lnh<=maxln);


		h=1<<(_lnh-1);
		R[0]=x[pos];
		R[h]=x[pos+h+h];
		for (i=1;i<h;++i){
			const double t1 = x[pos+i+i];
			const double t2 = x[n-i-i];
			R[i]=t1+t2;
			I[i]=t2-t1;
		}
		I[0]=0.0;
		lnh = _lnh-1;
		Dct(R);
		Dst(I+1);
		I[h]=0.0;
	}

	//Significantly slower - uses FFT instead of QFT for top
	//levels of lnh>12
	void AccurateForward(float *R, float *I, float *x, int _lnh)
	{
//		Profile(QFT_AccurateForward);
		CriticalSectionEntry ce(cs);
		lnh=_lnh;
		jhfftu(R, I, x);
	}

	//note, the reverse transform changes R and I in place
	//make copies if you want to preserve them
	void Reverse(float *x, float *R, float *I, int _lnh);

	//for convolutions there's some edges you don't need
	//this is a special case where it only calculates the
	//first have of the reverse transform
	void ReverseHalf(float *x, float *R, float *I, int _lnh);

	void QFT::ReverseNoUnpack(float *R, float *I, int _lnh);
	//this only works for the first half
	static double UnpackStep(int pos, float *R, float *I) { return R[pos]-I[pos]; }
	//gets you the last half of the spectrum, indexed backwards from the end
	static double NegUnpackStep(int pos, float *R, float *I) { return R[pos]+I[pos]; }

	//turns a spectrum into a spectrum of even samples and a spectrum of odd samples
	static void DecomposeEvenOdd(float *re,float *ie,float *ro,float *io, float *R, float *I, int _lnh);
	//combines a spectrum of even samples with a spectrum of odd samples
	static void CombineEvenOdd(float *R, float *I, float *re,float *ie,float *ro,float *io, int _lnh);
};

//Note these tables are built using complex multiplication to 
//rotate the previous entry.  It would be more accurate to
//use sin and cos for every entry.
class DSecantTable
{
	double **secants;
	double **rotations;
	int maxln;
public:
	double *operator [](int i) { return secants[i]; }
	double *Rotations(int i) { return rotations[i]; }
	DSecantTable(int i);
	~DSecantTable();
};

//maximum block length (2^17)
const int MaxDQFT = 17;

class DQFT
{
	static DSecantTable Secants;
	double *scratch;
	double *currentScratch;
	int lnh;
	int maxln;
//Since DQFT uses a permanently allocated scratch space
//you can only be running one DQFT per thread at a time.
//The reason I made this a class is so you CAN run
//simultanious transforms (by making multiple DQFT objects).
	CriticalSection cs; 
	void Dct(double *x);
	void Dst(double *x);
	void jhfftu(double *R, double *I, double *x);
public:
	DQFT(int _max=MaxDQFT)
		:scratch(new double[(1<<(_max+3))+2*(_max+1)+(1<<_max)])
		,currentScratch(scratch)
		,maxln(_max)
	{
		assert(maxln<=MaxQFT);
	}
	~DQFT()
	{
		delete [] scratch;
	}
	//Discrete Sine transform.  _lnh is the base two log of the block length.
	//Note that block sizes less than 8 (lnh=3) don't work.
	void Dst(double *x,int _lnh) 
	{ 
		CriticalSectionEntry ce(cs);
		lnh = _lnh; 
		Dst(x); 
	}
	//Discrete Cosine transform.  _lnh is the base two log of the block length.
	//Note that block sizes less than 4 (lnh=2) don't work.
	void Dct(double *x,int _lnh) 
	{ 
		CriticalSectionEntry ce(cs);
		lnh = _lnh; 
		x[0]*=.5; 
		x[1<<lnh]*=.5; 
		Dct(x); 
	}

	//I have no idea what the accuracy is for the double precision version
	//but, probably, the number of bits lost is the same - you just start
	//with more bits.

	//FFT fowrard transform.
	//_lnh is the base two log of the length.  Note that block sizes less 
	//than 16 (lnh=4) don't work.
	//R gets the real part of the spectrum
	//I gets the imaginary part of the spectrum
	//If I remember properly, the order is from low frequencies to high
	//R and I must each have a length of "pow(2,(lnh-1))+1"
	//x is the source and has a length of "pow(2,(lnh))"
	//Note, the values in x are not changed. 
	void Forward(double *R, double *I, double *x, int _lnh);

	//Starts with an array of floats instead of doubles, but does all 
	//of it's calculations to double accuracy and puts the results in 
	//arrays of doubles
	void Forward(double *R, double *I, float *x, int _lnh);
	

	//Because my code uses ring buffers I have templates that act like arrays
	//but are not actually arrays.  This function takes x as any indexable type
	//and starts indexing into it as a position "pos"
	template <typename T>
	void ForwardFromTemplate(double *R, double *I, T& x, int pos, int _lnh)
	{
		int h;
		int i;
		int n=1<<_lnh;
		CriticalSectionEntry ce(cs);
		assert(_lnh<=maxln);

		h=n>>1;
		R[0]=x[pos];
		R[h]=x[pos+h];
		for (i=1;i<h;++i){
			const double t1 = x[pos+i];
			const double t2 = x[pos+n-i];
			R[i]=t1+t2;
			I[i]=t2-t1;
		}
		I[0]=0.0;
		lnh = _lnh-1;
		Dct(R);
		Dst(I+1);
		I[h]=0.0;
	}

	//At one point I had a use for a routine that gave me the spectrum
	//of even samples.  Note that x is assumed to be pow(2, _lnh+1) long
	template <typename T>
	void ForwardFromTemplateSkipOdd(double *R, double *I, T& x, int pos, int _lnh)
	{
		int h;
		int i;
		int n=pos+(2<<_lnh);
		CriticalSectionEntry ce(cs);
		assert(_lnh<=maxln);


		h=1<<(_lnh-1);
		R[0]=x[pos];
		R[h]=x[pos+h+h];
		for (i=1;i<h;++i){
			const double t1 = x[pos+i+i];
			const double t2 = x[n-i-i];
			R[i]=t1+t2;
			I[i]=t2-t1;
		}
		I[0]=0.0;
		lnh = _lnh-1;
		Dct(R);
		Dst(I+1);
		I[h]=0.0;
	}

	//Significantly slower - uses FFT instead of DQFT for top
	//levels of lnh>12
	void AccurateForward(double *R, double *I, double *x, int _lnh)
	{
//		Profile(QFT_AccurateForward);
		CriticalSectionEntry ce(cs);
		lnh=_lnh;
		jhfftu(R, I, x);
	}
	//Starts with an array of floats instead of doubles, but does all 
	//of it's calculations to double accuracy and puts the results in 
	//arrays of doubles
	void AccurateForward(double *R, double *I, float *x, int _lnh)
	{
		int n=1<<_lnh;
		double *temp = currentScratch;
		currentScratch += n;
		for (int i=0;i<n;i+=2) {
			temp[i] = x[i];
			temp[i+1] = x[i+1];
		}
		AccurateForward(R,I,temp,_lnh);
		currentScratch = temp;
	}

	//note, the reverse transform changes R and I in place
	//make copies if you want to preserve them
	void Reverse(double *x, double *R, double *I, int _lnh);
	void Reverse(float *x, double *R, double *I, int _lnh);

	//turns a spectrum into a spectrum of even samples and a spectrum of odd samples
	static void DecomposeEvenOdd(double *re,double *ie,double *ro,double *io, double *R, double *I, int _lnh);
	//combines a spectrum of even samples with a spectrum of odd samples
	static void CombineEvenOdd(double *R, double *I, double *re,double *ie,double *ro,double *io, int _lnh);

	void ReverseNoUnpack(double *R, double *I, int _lnh);
	//this only works for the first half
	static double UnpackStep(int pos, double *R, double *I) { return R[pos]-I[pos]; }
	//gets you the last half of the spectrum, indexed backwards from the end
	static double NegUnpackStep(int pos, double *R, double *I) { return R[pos]+I[pos]; }
};

//It's usually convenient to have at least one of each defined
extern QFT qft;
extern DQFT dqft;

#endif