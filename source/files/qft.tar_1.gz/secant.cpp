#include "stdafx.h"
//#include <stdlib.h>
#include <math.h>
//#include "basic.hpp"
#include <complex>
#include "qft.h"

using namespace std;

SecantTable::~SecantTable()
{
	for (int i=2;i<=maxln;++i){
		delete [] secants[i];
		delete [] rotations[i];
	}
	delete [] secants;
	delete [] rotations;
}


SecantTable::SecantTable(int _maxln)
{
	int i,j;
	const double pi = 3.141592653589793238462643383;
	maxln = _maxln;
	secants=new float *[maxln+1];
	rotations=new float *[maxln+1];
	for (i=2;i<=maxln;++i){
		complex<double> a(2.0,0.0);
		double theta=pi/(1<<i);
		complex<double> p(cos(theta),sin(theta));
		int entries = (1<<(i-1));
		float *table= new float [entries];

		secants[i]=table;
		for	(j=0;j<entries;++j)
		{
			*table++ = (float)(1.0/a.real());
			a*=p;
		}
		table=new float [2*(entries+1)];
		rotations[i] = table;
		theta *= -2.0;
		a= complex<double>(1.0,0.0);
		p= complex<double>(cos(theta),sin(theta));
		for	(j=0;j<=entries;++j)
		{
			*table++ = a.real();
			*table++ = a.imag();
			a*=p;
		}
	}
}

DSecantTable::~DSecantTable()
{
	for (int i=2;i<=maxln;++i){
		delete [] secants[i];
		delete [] rotations[i];
	}
	delete [] secants;
	delete [] rotations;
}

//Note these tables are built using complex multiplication to 
//rotate the previous entry.  It would be more accurate to
//use sin and cos for every entry.

DSecantTable::DSecantTable(int _maxln)
{
	int i,j;
	const double pi = 3.141592653589793238462643383;
	maxln = _maxln;
	secants=new double *[maxln+1];
	rotations=new double *[maxln+1];
	for (i=2;i<=maxln;++i){
		complex<double> a(2.0,0.0);
		double theta=pi/(1<<i);
		complex<double> p(cos(theta),sin(theta));
		int entries = (1<<(i-1));
		double *table= new double [entries];

		secants[i]=table;
		for	(j=0;j<entries;++j)
		{
			*table++ = (double)(1.0/a.real());
			a*=p;
		}
		table=new double [2*(entries+1)];
		rotations[i] = table;
		theta *= -2.0;
		a= complex<double>(1.0,0.0);
		p= complex<double>(cos(theta),sin(theta));
		for	(j=0;j<=entries;++j)
		{
			*table++ = a.real();
			*table++ = a.imag();
			a*=p;
		}
	}
}
