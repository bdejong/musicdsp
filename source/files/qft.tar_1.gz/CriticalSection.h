#ifndef INCLUDED_CRITICALSECTION_H
#define INCLUDED_CRITICALSECTION_H
#ifndef _WINDOWS_
#include <windows.h>
#endif
class CriticalSectionEntry;
class CriticalSection
{
public:
  CriticalSection()
  {
    InitializeCriticalSection(&cs);
  }
  ~CriticalSection()
  {
    DeleteCriticalSection(&cs);
  }
  
protected:
    friend class CriticalSectionEntry;

  void Enter()
  {
    EnterCriticalSection(&cs);
  }

  void Leave()
  {
    LeaveCriticalSection(&cs);
  }
  CRITICAL_SECTION cs;
private:
	CriticalSection(const CriticalSection&){}
	void operator =(const CriticalSection&){}
};

class AdvancedCriticalSection :public CriticalSection
{
public:
//just changing the access to Enter and Leave:

  using CriticalSection::Enter;
  using CriticalSection::Leave;
};

class CriticalSectionEntry
{
public:
  explicit CriticalSectionEntry(const CriticalSection& c)
    : cs(const_cast<CriticalSection *>(&c))
  {
    cs->Enter();
  }
  ~CriticalSectionEntry()
  {
    cs->Leave();
  }

private:
  CriticalSection *cs; 
};

#endif
