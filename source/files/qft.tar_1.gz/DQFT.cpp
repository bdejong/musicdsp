#include "stdafx.h"
//#include <stdlib.h>
//#include <math.h>
//#include "basic.hpp"
#include "qft.h"

DQFT dqft;

#define	sec1	0.5411961001461970
#define	sec2	0.70710678118654752
#define	sec3	1.3065629648763763

static const double Sec1=sec1;
static const double Sec2=sec2;
static const double Sec3=sec3;

DSecantTable DQFT::Secants(MaxQFT);

#define _USE_ASM

void DQFT::Dct(double *x)
{
	if (lnh==2) {
#ifndef _USE_ASM
		const double t1=x[0]-x[4];
		const double t2=0.70710678118654*(x[1]-x[3]);
		const double t3=x[1]+x[3];
		const double t4=x[0]+x[4];
		const double t5=t4+x[2];
		x[0]=(double)(t5+t3);
		x[1]=(double)(t1+t2);
		x[2]=(double)(t4-x[2]);
		x[3]=(double)(t1-t2);
		x[4]=(double)(t5-t3);
#else
		_asm{
			mov	eax,x;
#define X(a) qword ptr [eax + (a*8)]
						//						{0			1			2			3			4			5			6			7			8}
			fld X(0);	//ld r1,X(0)			{																								r1}
			fld X(1);	//ld r2,X(1)			{																					r2,			r1}
			fld st(1);	//ld r4,r1				{																		r4,			r2,			r1}
			fxch st(2);	//						{																		r1,			r2,			r4}
			fsub X(4);	//r1-X(4)				{																		r1,			r2,			r4}
			fxch st(1);	//						{																		r2,			r1,			r4}
			fsub X(3);	//r2-X(3)				{																		r2,			r1,			r4}
			fxch st(2);	//						{																		r4,			r1,			r2}		
			fadd X(4);	//r4+X(4)				{																		r4,			r1,			r2}
			fld X(1);	//ld r3,X(1)			{															r3,			r4,			r1,			r2}
			fxch st(3);	//						{															r2,			r4,			r1,			r3}
			fmul Sec2;	//r2*1/sqrt2			{															r2,			r4,			r1,			r3}
			fld X(2);	//ld r5,X(2)			{												r5,			r2,			r4,			r1,			r3}
			fxch st(4);	//						{												r3,			r2,			r4,			r1,			r5}
			fadd X(3);	//r3+X(3)				{												r3,			r2,			r4,			r1,			r5}
			fxch st(4);	//						{												r5,			r2,			r4,			r1,			r3}
			fadd st(0),st(2);	//r5+r4			{												r5,			r2,			r4,			r1,			r3}
			fxch st(2);	//						{												r4,			r2,			r5,			r1,			r3}
			fsub X(2);	//r4-X[2]				{												r4,			r2,			r5,			r1,			r3}
			fld st(1);	//ld r6,r2				{									r6,			r4,			r2,			r5,			r1,			r3}
			fld st(5);	//ld r7,r3				{						r7,			r6,			r4,			r2,			r5,			r1,			r3}
			fxch st(1);	//						{						r6,			r7,			r4,			r2,			r5,			r1,			r3}
			fadd st(0),st(5);	//r6+r1			{						r6,			r7,			r4,			r2,			r5,			r1,			r3}
			fxch st(2);	//						{						r4,			r7,			r6,			r2,			r5,			r1,			r3}
			fstp X(2);	//from r4				{									r7,			r6,			r2,			r5,			r1,			r3}
			fadd st(0),st(3);	//r7+r5			{									r7,			r6,			r2,			r5,			r1,			r3}
			fxch st(2);	//						{									r2,			r6,			r7,			r5,			r1,			r3}
			fsubp st(4),st(0); //r1-r2			{												r6,			r7,			r5,			r1,			r3}
			fxch st(4);	//						{												r3,			r7,			r5,			r1,			r6}
			fsubp st(2),st(0); //r5-r3			{															r7,			r5,			r1,			r6}
			fxch st(3);	//						{															r6,			r5,			r1,			r7}
			fstp X(1);	//from r6				{																		r5,			r1,			r7}
			fxch st(2);	//						{																		r7,			r1,			r5}
			fstp X(0);	//from r7				{																					r1,			r5}
			fstp X(3);	//from r1				{																								r5}
			fstp X(4);	//from r5				{}
		}
#undef X
#endif
		return;
	}
	{
		const int l=(1<<lnh)+1;
		int n=l-1;
		const int h=n>>1;
		const int hp1=h+1;
		double *secants = Secants[lnh];
		double *x1=currentScratch;
		double *x2=x1+hp1;
		int i;
		
		currentScratch=x2+hp1;
#ifndef _USE_ASM
		for (i=0;i<h;++i){
			x1[i]=x[i]+x[l-i-1];
			x2[i]=(x[i]-x[l-i-1])* secants[i];
		}
		x1[h]=x[h];
		x2[h]=0;
#else
// /*		Note, the assembly language version of the loop is doubled (2 per iteration)
		_asm {
			mov edx,l;
			mov ebx,-8;
			mov esi,x;			//x is			esi
			lea edx,[edx*8];
			mov ecx,h;			//h*4 will be	[esp]
			mov eax,x1;			//x1 is			eax
			add ebx,esi;		//&x[l-i-1] is	ebx
			lea ecx,[ecx*8];
			mov	edi,x2;			//x2 is			edi
			add ebx,edx;
			mov edx, secants;	//secants		edx
			push ebp;
			mov ebp,ecx;
			xor ecx,ecx;		//i*4 is		ecx
#define rx esi
#define rh ebp
#define rx1 eax
#define rx2 edi
#define rxend ebx
#define i ecx
#define rsec edx
			fld qword ptr [rxend];	//ld r1,qword ptr [rxend]	{r1}
			fld qword ptr [rx];		//ld r2,qword ptr [rx]		{r2,r1}
back:;
			fld qword ptr [rxend-8];//ld r3,qword ptr [rxend-4]	{r3,r2,r1}
			fld qword ptr [rx+i+8];	//ld r4,qword ptr [rx+i+4]	{r4,r3,r2,r1}
			fld st(3);				//ld r5,r1					{r5,r4,r3,r2,r1}
			fsubr st(0),st(3);		//r2-r5						{r5,r4,r3,r2,r1}
			fxch st(3);				//							{r5,r4,r3,r2,r1}
			faddp st(4),st(0);		//r2+r1						{r4,r3,r5,r1}
			fld st(1);				//ld r2,r3					{r2,r4,r3,r5,r1}
			fsubr st(0),st(1);		//r4-r2						{r2,r4,r3,r5,r1}
			fxch st(3);				//							{r2,r4,r3,r5,r1}
			fmul qword ptr [rsec+i];//r5*qword ptr [rsec+i]		{r5,r4,r3,r2,r1}
			lea i,[i+16];
			lea rxend,[rxend-16];
			cmp i,rh;
			fld qword ptr [rsec+i-8];//ld r6,qword ptr [rsec+i-4]{r6,r5,r4,r3,r2,r1}
			fmulp st(4),st(0);		//r6*r2						{r5,r4,r3,r2,r1}
			fxch st(4);				//							{r5,r4,r3,r2,r1}
			fstp qword ptr[rx1+i-16];//from r1					{r4,r3,r2,r5}
			fxch st(3);				//							{r4,r3,r2,r5}
			fstp qword ptr[rx2+i-16];//from r5					{r3,r2,r4}
			fxch st(2);				//							{r3,r2,r4}
			faddp st(2),st(0);		//r4+r3						{r2,r3}
			fstp qword ptr[rx2+i-8];//from r2					{r3}
			fld qword ptr [rx+i];	//ld r2,qword ptr [rx+i]	{r2,r3}
			fld qword ptr [rxend];	//ld r1,qword ptr [rxend]	{r1,r2,r3}
			fxch st(2);				//							{r1,r2,r3}
			fstp qword ptr[rx1+i-8];//from r3					{r2,r1}
			jne back;

			fstp qword ptr [rx1+i];	//from r2					{r1}
			mov rx1,0;				//same bit pattern as 0.0f
			fsubp st(0),st(0);
			pop ebp;
			mov [rx2+i],rx1;//x2[h]=0; I'm assuming 0.0d is 0 too
			mov [rx2+i+4],rx1;
#undef rx
#undef rh
#undef rx1
#undef rx2
#undef rxend
#undef i
#undef rsec 
		}
#endif
		--lnh;
		Dct(x1);	
		Dct(x2);	
		++lnh;
// There's no assembly language version of this loop because
// for double precision the code would have to be quite different than it is
// for single precision where I can store x1[i] in eax.
		for (i=0;i<h;++i){
			*x++ = x1[i];
			*x++ = x2[i]+x2[i+1];
		}
		*x=x1[h];
		currentScratch = x1;
	}
}



void DQFT::Dst(double *x)
{
	if (lnh==3){
#ifndef _USE_ASM
		const double t=x[3];
		double x1_0,x1_1,x1_2;
		double x2_0,x2_1,x2_2;

		x1_0=x[0]-x[6];
		x2_0=(x[0]+x[6])* sec1;
		x1_1=x[1]-x[5];
		x2_1=(x[1]+x[5])* sec2;
		x1_2=x[2]-x[4];
		x2_2=(x[2]+x[4])* sec3;
		{
			const double t=0.70710678118654*(x1_0+x1_2);
			const double t2=x1_1;
			x1_1=x1_0-x1_2;
			x1_0=(double)(t+t2);
			x1_2=(double)(t-t2);
		}
		{
			const double t=0.70710678118654*(x2_0+x2_2);
			const double t2=x2_1;
			x2_1=x2_0-x2_2;
			x2_0=(double)(t+t2);
			x2_2=(double)(t-t2);
		}
		x[0]=t+x2_0;
		x[1]=x1_0;

		x[2] = x2_0+x2_1-t;
		x[3] = x1_1;

		x[4] = x2_1+x2_2+t;
		x[5] = x1_2;

		x[6]=x2_2-t;
#else
		_asm{
			mov	eax,x;
#define X(a) qword ptr [eax + (a*8)]
			fld X(0);	//ld r1,X(0)		{r1}
			fld X(1);	//ld r2,X(1)		{r2,r1}
			fld st(1);	//ld r3,r1			{r3,r2,r1}
			fld X(2);	//ld r5,X(2)		{r5,r3,r2,r1}
			fld st(2);	//ld r4,r2			{r4,r5,r3,r2,r1}
			fld st(1);	//ld r6,r5			{r6,r4,r5,r3,r2,r1}
			fadd X(4);	//r6+X(4)			{r6,r4,r5,r3,r2,r1}
			fxch st(1);	//					{r6,r4,r5,r3,r2,r1}
			fadd X(5);	//r4+X(5)			{r4,r6,r5,r3,r2,r1}
			fxch st(3);	//					{r4,r6,r5,r3,r2,r1}
			fadd X(6);	//r3+X(6)			{r3,r6,r5,r4,r2,r1}
			fxch st(1);	//					{r3,r6,r5,r4,r2,r1}
			fmul Sec3;	//r6*Sec3			{r6,r3,r5,r4,r2,r1}
			fxch st(5);	//					{r6,r3,r5,r4,r2,r1}
			fsub X(6);	//r1-X(6)			{r1,r3,r5,r4,r2,r6}
			fxch st(3);	//					{r1,r3,r5,r4,r2,r6}
			fmul Sec2;	//r4*Sec2			{r4,r3,r5,r1,r2,r6}
			fld st(5);	//ld r7,r6			{r7,r4,r3,r5,r1,r2,r6}
			fxch st(5);	//					{r7,r4,r3,r5,r1,r2,r6}
			fsub X(5);	//r2-X(5)			{r2,r4,r3,r5,r1,r7,r6}
			fxch st(2);	//					{r2,r4,r3,r5,r1,r7,r6}
			fmul Sec1;	//r3*Sec1			{r3,r4,r2,r5,r1,r7,r6}
			fxch st(3);	//					{r3,r4,r2,r5,r1,r7,r6}
			fsub X(4);	//r5-X(4)			{r5,r4,r2,r3,r1,r7,r6}
			fld st(4);	//ld r8,r1			{r8,r5,r4,r2,r3,r1,r7,r6}
			fxch st(6);	//					{r8,r5,r4,r2,r3,r1,r7,r6}
			fadd st(0),st(4); //r7+r3		{r7,r5,r4,r2,r3,r1,r8,r6}
			fxch st(6);	//					{r7,r5,r4,r2,r3,r1,r8,r6}
			fadd st(0),st(1); //r8+r5		{r8,r5,r4,r2,r3,r1,r7,r6}
			fxch st(7);	//					{r8,r5,r4,r2,r3,r1,r7,r6}
			fsubp st(4),st(0); //r3-r6		{r5,r4,r2,r3,r1,r7,r8}
			fxch st(5);	//					{r5,r4,r2,r3,r1,r7,r8}
			fmul Sec2;	//r7*Sec2			{r7,r4,r2,r3,r1,r5,r8}
			fxch st(5);	//					{r7,r4,r2,r3,r1,r5,r8}
			fsubp st(4),st(0); //r1-r5		{r4,r2,r3,r1,r7,r8}
			fxch st(5);	//					{r4,r2,r3,r1,r7,r8}
			fmul Sec2;	//r8*Sec2			{r8,r2,r3,r1,r7,r4}
			fld st(5);	//ld r6,r4			{r6,r8,r2,r3,r1,r7,r4}
			fadd st(0),st(5); //r6+r7		{r6,r8,r2,r3,r1,r7,r4}
			fxch st(5);	//					{r6,r8,r2,r3,r1,r7,r4}
			fsubrp st(6),st(0); //r7-r4		{r8,r2,r3,r1,r6,r4}
			fld X(3);	//ld r7,X(3)		{r7,r8,r2,r3,r1,r6,r4}
			fld st(2);	//ld r5,r2			{r5,r7,r8,r2,r3,r1,r6,r4}
			fxch st(1);	//					{r5,r7,r8,r2,r3,r1,r6,r4}
			fadd st(0),st(6); //r7+r6		{r7,r5,r8,r2,r3,r1,r6,r4}
			fxch st(6);	//					{r7,r5,r8,r2,r3,r1,r6,r4}
			fadd st(0),st(4); //r6+r3		{r6,r5,r8,r2,r3,r1,r7,r4}
			fxch st(4);	//					{r6,r5,r8,r2,r3,r1,r7,r4}
			fadd X(3);	//r3+X(3)			{r3,r5,r8,r2,r6,r1,r7,r4}
			fxch st(1);	//					{r3,r5,r8,r2,r6,r1,r7,r4}
			fadd st(0),st(2); //r5+r8		{r5,r3,r8,r2,r6,r1,r7,r4}
			fxch st(2);	//					{r5,r3,r8,r2,r6,r1,r7,r4}
			fsubrp st(3),st(0); //r8-r2		{r3,r5,r2,r6,r1,r7,r4}
			fadd st(0),st(6); //r3+r4		{r3,r5,r2,r6,r1,r7,r4}
			fxch st(3);	//					{r3,r5,r2,r6,r1,r7,r4}
			fsub X(3);	//r6-X(3)			{r6,r5,r2,r3,r1,r7,r4}
			fxch st(5);	//					{r6,r5,r2,r3,r1,r7,r4}
			fstp X(0);	//from r7			{r5,r2,r3,r1,r6,r4}
			fxch st(5);	//					{r5,r2,r3,r1,r6,r4}
			fsub X(3);	//r4-X(3)			{r4,r2,r3,r1,r6,r5}
			fxch st(5);	//					{r4,r2,r3,r1,r6,r5}
			fstp X(1);	//from r5			{r2,r3,r1,r6,r4}
			fstp X(5);
			fstp X(4);
			fstp X(3);
			fstp X(2);
			fstp X(6);
#undef X
		}
#endif 
		return;
	}else{
		const int l=(1<<lnh)-1;
//		double t;
		int n=l+1;
		const int h=n>>1;
		const int hm1=h-1;
		double *x1=currentScratch;
		double *x2=x1+hm1;
		int i;
		double *secants = Secants[lnh]+1;

		currentScratch=x2+hm1;
#ifndef _USE_ASM

		for (i=0;i<hm1;++i){
			x1[i]=x[i]-x[l-i-1];
			x2[i]=(x[i]+x[l-i-1])* *secants++;
		}
#else
// /* 		Note, the assembly language version of the loop is doubled (2 per iteration)

		_asm {
			mov edx,l;
			mov ebx,-8;
			mov esi,x;			//x is			esi
			lea edx,[edx*8];
			mov ecx,h;			//h*4 will be	[esp]
			mov eax,x1;			//x1 is			eax
			add ebx,esi;		//&x[l-i-1] is	ebx
			lea ecx,[ecx*8-16];
			mov	edi,x2;			//x2 is			edi
			add ebx,edx;
			mov edx, secants;	//secants		edx
			push ebp
			mov ebp,ecx;
			mov ecx,0;			//i*4 is		ecx
#define rx esi
#define rh ebp
#define rx1 eax
#define rx2 edi
#define rxend ebx
#define i ecx
#define rsec edx
			fld qword ptr [rxend];	//ld r1,qword ptr [rxend]	{[rxend]}
			fld qword ptr [rx];		//ld r2,qword ptr [rx]		{[rx],[rxend]}
back:;
			fld qword ptr [rxend-8];//ld r3,qword ptr [rxend-4]	{[rxend-4],[rx+i],[rxend]}
			fld qword ptr [rx+i+8];	//ld r4,qword ptr [rx+i+4]	{[rx+i+4],[rxend-4],[rx+i],[rxend]}
			fld st(3);				//ld r5,r1					{[rxend],[rx+i+4],[rxend-4],[rx+i],[rxend]}
			fadd st(0),st(3);		//r2+r5						{[rx+i]+[rxend],[rx+i+4],[rxend-4],[rx+i],[rxend]}
			fxch st(3);				//							{[rx+i],[rx+i+4],[rxend-4],[rx+i]+[rxend],[rxend]}
			fsubrp st(4),st(0);		//r2+r1	 					{[rx+i+4],[rxend-4],[rx+i]+[rxend],[rx+i]-[rxend]}
			fld st(1);				//ld r2,r3					{[rxend-4],[rx+i+4],[rxend-4],[rx+i]+[rxend],[rx+i]-[rxend]}
			fadd st(0),st(1);		//r4-r2						{[rxend-4]+[rx+i+4],[rx+i+4],[rxend-4],[rx+i]+[rxend],[rx+i]-[rxend]}
			fxch st(3);				//							{[rx+i]+[rxend],[rx+i+4],[rxend-4],[rxend-4]+[rx+i+4],[rx+i]-[rxend]}
			fmul qword ptr [rsec+i];//r5*qword ptr [rsec+i]		{sec[i]*([rx+i]+[rxend]),[rx+i+4],[rxend-4],[rxend-4]+[rx+i+4],[rx+i]-[rxend]}
			lea i,[i+16];
			lea rxend,[rxend-16];
			cmp i,rh;
			fld qword ptr [rsec+i-8];//ld r6,qword ptr [rsec+i-4]{sec[i+4],sec[i]*([rx+i]+[rxend]),[rx+i+4],[rxend-4],[rxend-4]+[rx+i+4],[rx+i]-[rxend]}
			fmulp st(4),st(0);		//r6*r2						{sec[i]*([rx+i]+[rxend]),[rx+i+4],[rxend-4],sec[i+4]*([rxend-4]+[rx+i+4]),[rx+i]-[rxend]}
			fxch st(4);				//							{[rx+i]-[rxend],[rx+i+4],[rxend-4],sec[i+4]*([rxend-4]+[rx+i+4]),sec[i]*([rx+i]+[rxend])}
			fstp qword ptr[rx1+i-16];//from r1					{[rx+i+4],[rxend-4],sec[i+4]*([rxend-4]+[rx+i+4]),sec[i]*([rx+i]+[rxend])}
			fxch st(3);				//							{sec[i]*([rx+i]+[rxend]),[rxend-4],sec[i+4]*([rxend-4]+[rx+i+4]),[rx+i+4]}
			fstp qword ptr[rx2+i-16];//from r5					{[rxend-4],sec[i+4]*([rxend-4]+[rx+i+4]),[rx+i+4]}
			fsubp st(2),st(0);		//r4+r3						{sec[i+4]*([rxend-4]+[rx+i+4]),[rx+i+4]-[rxend-4]}
			fstp qword ptr[rx2+i-8];//from r2					{[rx+i+4]-[rxend-4]}
			fld qword ptr [rx+i];	//ld r2,qword ptr [rx+i]	{[rx+i],[rx+i+4]-[rxend-4]}
			fld qword ptr [rxend];	//ld r1,qword ptr [rxend]	{[rxend],[rx+i],[rx+i+4]-[rxend-4]}
			fxch st(2);				//							{[rx+i+4]-[rxend-4],[rx+i],[rxend]}
			fstp qword ptr[rx1+i-8]; //from r3					{[rx+i],[rxend]}
			jne back;

			fld st(0);											//{x[i],x[i],x[l-i]}
			fadd st(0),st(2);									//{x[i]+x[l-i],x[i],x[l-i]}
			fxch st(1);											//{x[i],x[i]+x[l-i],x[l-i]}
			fsubrp st(2),st(0);									//{x[i]+x[l-i],x[i]-x[l-i]}
			fmul qword ptr [rsec+i];							//{sec[i]*(x[i]+x[l-i]),x[i]-x[l-i]}
			fxch st(1);											//{x[i]-x[l-i],sec[i]*(x[i]+x[l-i])}
			fstp qword ptr[rx1+i];
			pop ebp;
			fstp qword ptr[rx2+i];
#undef rx
#undef rh
#undef rx1
#undef rx2
#undef rxend
#undef i
#undef rsec 
		}
#endif
		--lnh;
		Dst(x1);	
		Dst(x2);	
		++lnh;
// once again, no assembly language version of the double precision version
// because it would take a major rewrite.
// I did, however double the loop and hope the compiler can schedule 
// a doubled loop better

		double t=x[hm1];
		x[0]=t+x2[0];
		x[1]=x1[0];
		for (i=0;i<h-2;i+=2){
			x[2] = x2[i]+x2[i+1]-t;
			x[3] = x1[i+1];
			x[4] = x2[i+1]+x2[i+2]+t;
			x[5] = x1[i+2];
			x+=4;
		}
		x[2]=x2[i]-t;
		currentScratch = x1;
	}
}


void DQFT::Forward(double *R, double *I, double *x, int _lnh)
{
//	Profile(QFT_Foward);
	int h;
//	int i;
	int n=1<<_lnh;
	CriticalSectionEntry ce(cs);
	assert(_lnh<=maxln);

	lnh = _lnh-1;

	h=n>>1;
	R[0]=x[0];
	R[h]=x[h];
#ifndef _USE_ASM
	for (int i=1;i<h-1;i+=2){
		const double t1 = x[i];
		const double t2 = x[n-i];
		const double t3 = x[i+1];
		const double t4 = x[n-i-1];
		R[i]=t1+t2;
		I[i]=t2-t1;
		R[i+1]=t3+t4;
		I[i+1]=t4-t3;
	}
	{
		const double t1 = x[i];
		const double t2 = x[n-i];
		R[i]=t1+t2;
		I[i]=t2-t1;
	}
#else
	_asm {
		mov edx,h;
		mov ebx,x;
		mov eax,n;
		mov ecx,8;
		lea edx,[edx*8-24];
		mov esi,R;
		mov edi,I;
		lea eax,[ebx+eax*8-16];
back:;
		cmp ecx,edx;
		fld qword ptr[ebx+ecx]; //ld t1,qword ptr[ebx+ecx]
		fld qword ptr[eax+8]; //ld t2,qword ptr[eax+4]
		fld qword ptr[ebx+ecx+8]; //ld t3,qword ptr[ebx+ecx+4]
		fld qword ptr[eax]; //ld t4,qword ptr[eax]
		fld st(3); //ld t5,t1
		fadd st(0),st(3); //t5+t2
		fxch st(3); //
		fsubrp st(4),st(0); //t2-t1
		fld st(1); //ld t2,t3
		fadd st(0),st(1); //t2+t4
		fxch st(1); //
		fsubrp st(2),st(0); //t4-t3			
		fxch st(2); //						
		fstp qword ptr[esi+ecx]; //from t5	
		fxch st(2); //						
		fstp qword ptr[edi+ecx]; //from t1 
		fstp qword ptr[esi+ecx+8]; //from t2
		fstp qword ptr[edi+ecx+8]; //from t3
		lea ecx,[ecx + 16];
		lea eax,[eax - 16];
		jne back;

		fld qword ptr[ebx+ecx]; //ld t1,qword ptr[ebx+ecx]
		fld qword ptr[eax+8]; //ld t2,qword ptr[eax+4]
		fld st(1); //ld t5,t1
		fadd st(0),st(1); //t5+t2
		fxch st(1); //
		fsubrp st(2),st(0); //t2-t1
		fstp qword ptr[esi+ecx]; //from t5
		fstp qword ptr[edi+ecx]; //from t1
	
	}
#endif
	I[0]=0.0;
	Dct(R);
	Dst(I+1);
	I[n>>1]=0.0;
}

void DQFT::Forward(double *R, double *I, float *x, int _lnh)
{
//	Profile(QFT_Foward);
	int h;
//	int i;
	int n=1<<_lnh;
	CriticalSectionEntry ce(cs);
	assert(_lnh<=maxln);

	lnh = _lnh-1;

	h=n>>1;
	R[0]=x[0];
	R[h]=x[h];
#ifndef _USE_ASM
	for (int i=1;i<h-1;i+=2){
		const double t1 = x[i];
		const double t2 = x[n-i];
		const double t3 = x[i+1];
		const double t4 = x[n-i-1];
		R[i]=t1+t2;
		I[i]=t2-t1;
		R[i+1]=t3+t4;
		I[i+1]=t4-t3;
	}
	{
		const double t1 = x[i];
		const double t2 = x[n-i];
		R[i]=t1+t2;
		I[i]=t2-t1;
	}
#else
	_asm {
		mov edx,h;
		mov ebx,x;
		mov eax,n;
		mov ecx,4;
		lea edx,[edx*4-12];
		mov esi,R;
		mov edi,I;
		lea eax,[ebx+eax*4-8];
back:;
		cmp ecx,edx;
		fld dword ptr[ebx+ecx]; //ld t1,qword ptr[ebx+ecx]
		fld dword ptr[eax+4]; //ld t2,qword ptr[eax+4]
		fld dword ptr[ebx+ecx+4]; //ld t3,qword ptr[ebx+ecx+4]
		fld dword ptr[eax]; //ld t4,qword ptr[eax]
		fld st(3); //ld t5,t1
		fadd st(0),st(3); //t5+t2
		fxch st(3); //
		fsubrp st(4),st(0); //t2-t1
		fld st(1); //ld t2,t3
		fadd st(0),st(1); //t2+t4
		fxch st(1); //
		fsubrp st(2),st(0); //t4-t3			
		fxch st(2); //						
		fstp qword ptr[esi+ecx*2]; //from t5	
		fxch st(2); //						
		fstp qword ptr[edi+ecx*2]; //from t1 
		fstp qword ptr[esi+8+ecx*2]; //from t2
		fstp qword ptr[edi+8+ecx*2]; //from t3
		lea ecx,[ecx + 8];
		lea eax,[eax - 8];
		jne back;

		fld dword ptr[ebx+ecx]; //ld t1,qword ptr[ebx+ecx]
		fld dword ptr[eax+4]; //ld t2,qword ptr[eax+4]
		fld st(1); //ld t5,t1
		fadd st(0),st(1); //t5+t2
		fxch st(1); //
		fsubrp st(2),st(0); //t2-t1
		fstp qword ptr[esi+ecx*2]; //from t5
		fstp qword ptr[edi+ecx*2]; //from t1
	
	}
#endif
	I[0]=0.0;
	Dct(R);
	Dst(I+1);
	I[n>>1]=0.0;
}

void DQFT::ReverseNoUnpack(double *R, double *I, int _lnh)
{
//	Profile(QFT_Reverse);
	int h;
	int n=1<<_lnh;
	CriticalSectionEntry ce(cs);

	assert(_lnh<=maxln);

	lnh = _lnh-1;
	h=n>>1;

	R[0]*=0.5;
	R[h]*=0.5;
	Dct(R);
	Dst(I+1);
	I[0]=0.0f;
}


void DQFT::Reverse(double *x, double *R, double *I, int _lnh)
{
//	Profile(QFT_Reverse);
	int h;
	int n=1<<_lnh;
	CriticalSectionEntry ce(cs);

	assert(_lnh<=maxln);

	lnh = _lnh-1;
	h=n>>1;

	R[0]*=0.5;
	R[h]*=0.5;
	Dct(R);
	Dst(I+1);
	const double nr=2.0/n;
	x[0]=R[0]*nr;
#ifndef _USE_ASM
	for (int i=1;i<h;i+=2) {
		const double t1 = nr*R[i];
		const double t2 = nr*I[i];
		const double t3 = nr*R[i+1];
		const double t4 = nr*I[i+1];
		x[i]=t1-t2;
		x[n-i]=t1+t2;
		x[i+1]=t3-t4;
		x[n-i-1]=t3+t4;
	}
#else
	_asm {
		mov edi,x
		mov ebx,n;
		mov esi,h;
		mov eax,R;
		mov edx,I;
		lea ebx,[edi+ebx*8-8];
		mov ecx,8;
		lea esi,[esi*8];
		fld nr		//ld nr,nr		{nr}
#define R eax
#define I edx
#define x edi
#define rx ebx
#define i ecx
#define h esi
back:;
		fld qword ptr [R+i]	//ld r1,[R+i]	{[R+i],				nr}
		fld qword ptr [I+i]	//ld r2,[I+i]	{[I+i],				[R+i],				nr}
		fxch st(1); //				{[R+i],				[I+i],				nr}
		fmul st(0),st(2); //r1*nr	{nr*[R+i],			[I+i],				nr}
		fld qword ptr [R+i+8];//ld r3,[R+i+4]	{[R+i+4],			nr*[R+i],			[I+i],				nr}
		fxch st(2); //				{[I+i],				nr*[R+i],			[R+i+4],			nr}
		fmul st(0),st(3); //r2*nr	{nr*[I+i],			nr*[R+i],			[R+i+4],			nr}
		fld qword ptr [I+i+8]; //ld r4,[I+i+4]{[I+i+4],			nr*[I+i],			nr*[R+i],			[R+i+4],			nr}
		fxch st(3); //				{[R+i+4],			nr*[I+i],			nr*[R+i],			[I+i+4],			nr}
		fmul st(0),st(4); //r3*nr	{nr*[R+i+4],		nr*[I+i],			nr*[R+i],			[I+i+4],			nr}
		fld st(2);	//ld r5,r1		{nr*[R+i],			nr*[R+i+4],			nr*[I+i],			nr*[R+i],			[I+i+4],	nr}
		fxch st(4); //				{[I+i+4],			nr*[R+i+4],			nr*[I+i],			nr*[R+i],			nr*[R+i],	nr}
		fmul st(0),st(5); //r4*nr	{nr*[I+i+4],		nr*[R+i+4],			nr*[I+i],			nr*[R+i],			nr*[R+i],	nr}
		fxch st(4); //				{nr*[R+i],			nr*[R+i+4],			nr*[I+i],			nr*[R+i],			nr*[I+i+4],	nr}
		fsub st(0),st(2); //r5-r2	{nr*([R+i]-[I+i]),	nr*[R+i+4],			nr*[I+i],			nr*[R+i],			nr*[I+i+4],	nr}
		fxch st(3) //				{nr*[R+i],			nr*[R+i+4],			nr*[I+i],			nr*([R+i]-[I+i]),	nr*[I+i+4],	nr}
		faddp st(2),st(0); //r1+r2	{nr*[R+i+4],		nr*([R+i]+[I+i]),	nr*([R+i]-[I+i]),	nr*[I+i+4],			nr}
		add i,16;
		fld st(0);	//ld r1,r3		{nr*[R+i+4],		nr*[R+i+4],			nr*([R+i]+[I+i]),	nr*([R+i]-[I+i]),	nr*[I+i+4],	nr}
		sub rx,16;
		fsub st(0),st(4); //r1-r4	{nr*([R+i+4]-[I+i+4]),nr*[R+i+4],		nr*([R+i]+[I+i]),	nr*([R+i]-[I+i]),	nr*[I+i+4],	nr}
		fxch st(3); //				{nr*([R+i]-[I+i]),	nr*[R+i+4],			nr*([R+i]+[I+i]),	nr*([R+i+4]-[I+i+4]),nr*[I+i+4],nr}
		fstp qword ptr [x+i-16];//from r5		{nr*[R+i+4],		nr*([R+i]+[I+i]),	nr*([R+i+4]-[I+i+4]),nr*[I+i+4],nr}
		faddp st(3),st(0); //r3+r4	{nr*([R+i]+[I+i]),	nr*([R+i+4]-[I+i+4]),nr*([R+i+4]+[I+i+4]),nr}
		cmp i,h;
		fstp qword ptr [rx+16];//from r2		{nr*([R+i+4]-[I+i+4]),nr*([R+i+4]+[I+i+4]),nr}
		fstp qword ptr [x+i-8]; //from r1		{nr*([R+i+4]+[I+i+4]),nr}
		fstp qword ptr [rx+8]; //from r4		{nr}
		jl back;

		fsubp st(0),st(0);
#undef R 
#undef I 
#undef x 
#undef rx 
#undef i 
#undef h
	}
#endif
}

void DQFT::Reverse(float *x, double *R, double *I, int _lnh)
{
//	Profile(QFT_Reverse);
	int h;
	int n=1<<_lnh;
	CriticalSectionEntry ce(cs);

	assert(_lnh<=maxln);

	lnh = _lnh-1;
	h=n>>1;

	R[0]*=0.5;
	R[h]*=0.5;
	Dct(R);
	Dst(I+1);
	const double nr=2.0/n;
	x[0]=float(R[0]*nr);
#ifndef _USE_ASM

	for (int i=1;i<h;i+=2) {
		const double t1 = nr*R[i];
		const double t2 = nr*I[i];
		const double t3 = nr*R[i+1];
		const double t4 = nr*I[i+1];
		x[i]=float(t1-t2);
		x[n-i]=float(t1+t2);
		x[i+1]=float(t3-t4);
		x[n-i-1]=float(t3+t4);
	}
#else
	_asm {
		mov edi,x
		mov ebx,n;
		mov esi,h;
		mov eax,R;
		mov edx,I;
		lea ebx,[edi+ebx*4-4];
		mov ecx,4;
		lea esi,[esi*4];
		fld nr		//ld nr,nr		{nr}
#define R eax
#define I edx
#define x edi
#define rx ebx
#define i ecx
#define h esi
back:;
		fld qword ptr [R+i*2]	//ld r1,[R+i]	{[R+i],				nr}
		fld qword ptr [I+i*2]	//ld r2,[I+i]	{[I+i],				[R+i],				nr}
		fxch st(1); //				{[R+i],				[I+i],				nr}
		fmul st(0),st(2); //r1*nr	{nr*[R+i],			[I+i],				nr}
		fld qword ptr [R+8+i*2];//ld r3,[R+i+4]	{[R+i+4],			nr*[R+i],			[I+i],				nr}
		fxch st(2); //				{[I+i],				nr*[R+i],			[R+i+4],			nr}
		fmul st(0),st(3); //r2*nr	{nr*[I+i],			nr*[R+i],			[R+i+4],			nr}
		fld qword ptr [I+8+i*2]; //ld r4,[I+i+4]{[I+i+4],			nr*[I+i],			nr*[R+i],			[R+i+4],			nr}
		fxch st(3); //				{[R+i+4],			nr*[I+i],			nr*[R+i],			[I+i+4],			nr}
		fmul st(0),st(4); //r3*nr	{nr*[R+i+4],		nr*[I+i],			nr*[R+i],			[I+i+4],			nr}
		fld st(2);	//ld r5,r1		{nr*[R+i],			nr*[R+i+4],			nr*[I+i],			nr*[R+i],			[I+i+4],	nr}
		fxch st(4); //				{[I+i+4],			nr*[R+i+4],			nr*[I+i],			nr*[R+i],			nr*[R+i],	nr}
		fmul st(0),st(5); //r4*nr	{nr*[I+i+4],		nr*[R+i+4],			nr*[I+i],			nr*[R+i],			nr*[R+i],	nr}
		fxch st(4); //				{nr*[R+i],			nr*[R+i+4],			nr*[I+i],			nr*[R+i],			nr*[I+i+4],	nr}
		fsub st(0),st(2); //r5-r2	{nr*([R+i]-[I+i]),	nr*[R+i+4],			nr*[I+i],			nr*[R+i],			nr*[I+i+4],	nr}
		fxch st(3) //				{nr*[R+i],			nr*[R+i+4],			nr*[I+i],			nr*([R+i]-[I+i]),	nr*[I+i+4],	nr}
		faddp st(2),st(0); //r1+r2	{nr*[R+i+4],		nr*([R+i]+[I+i]),	nr*([R+i]-[I+i]),	nr*[I+i+4],			nr}
		add i,8;
		fld st(0);	//ld r1,r3		{nr*[R+i+4],		nr*[R+i+4],			nr*([R+i]+[I+i]),	nr*([R+i]-[I+i]),	nr*[I+i+4],	nr}
		sub rx,8;
		fsub st(0),st(4); //r1-r4	{nr*([R+i+4]-[I+i+4]),nr*[R+i+4],		nr*([R+i]+[I+i]),	nr*([R+i]-[I+i]),	nr*[I+i+4],	nr}
		fxch st(3); //				{nr*([R+i]-[I+i]),	nr*[R+i+4],			nr*([R+i]+[I+i]),	nr*([R+i+4]-[I+i+4]),nr*[I+i+4],nr}
		fstp dword ptr [x+i-8];//from r5		{nr*[R+i+4],		nr*([R+i]+[I+i]),	nr*([R+i+4]-[I+i+4]),nr*[I+i+4],nr}
		faddp st(3),st(0); //r3+r4	{nr*([R+i]+[I+i]),	nr*([R+i+4]-[I+i+4]),nr*([R+i+4]+[I+i+4]),nr}
		cmp i,h;
		fstp dword ptr [rx+8];//from r2		{nr*([R+i+4]-[I+i+4]),nr*([R+i+4]+[I+i+4]),nr}
		fstp dword ptr [x+i-4]; //from r1		{nr*([R+i+4]+[I+i+4]),nr}
		fstp dword ptr [rx+4]; //from r4		{nr}
		jl back;

		fsubp st(0),st(0);
#undef R 
#undef I 
#undef x 
#undef rx 
#undef i 
#undef h
	}
#endif
}


//turns a spectrum into a spectrum of even samples and a spectrum of odd samples
void DQFT::DecomposeEvenOdd(double *re,double *ie,double *ro,double *io, double *R, double *I, int _lnh)
{
/*complex version
	complex<double> p(cos(-2*PI/n),sin(-2*PI/n));
	vector<double> fe(hh+1,0.0);
	vector<double> fo(hh+1,0.0);
	fe[0]=(f[0]+f[h])*0.5;
	fo[0]=(f[0]-f[h])*0.5;

    int j;
	for (j=1;j<=hh;++j) {
		fe[j]=(f[j]+conjugate(f[h-j]))*0.5;
		fo[j]=(f[j]-conjugate(f[h-j]))*p^(-j)*0.5;
	};
*/
	double *rotations = Secants.Rotations(_lnh)+2;
	const long n = 1<<_lnh;
	const int h=n>>1;
	const int hh=h>>1;

	re[0]=(R[0]+R[h])*0.5;
	ro[0]=(R[0]-R[h])*0.5;
	ie[0]=	io[0]= 0.0;

	for (int j=1;j<hh;++j) {
		re[j]=(R[j]+R[h-j])*0.5;
		ie[j]=(I[j]-I[h-j])*0.5;
		const double rx = (R[j]-R[h-j])*0.5;
		const double ix = (I[j]+I[h-j])*0.5;
		ro[j]=rx*rotations[0]+ix*rotations[1];
		io[j]=ix*rotations[0]-rx*rotations[1];
		rotations+=2;
	};	

	re[hh]=R[hh];
	ro[hh]=-I[hh];
	ie[hh]=	io[hh]= 0.0;
}
//combines a spectrum of even samples with a spectrum of odd samples
void DQFT::CombineEvenOdd(double *R, double *I, double *re,double *ie,double *ro,double *io, int _lnh)
{
/*complex version
	vector<double> r(h+1,0.0);
	complex<double> p(cos(-2*PI/n),sin(-2*PI/n));
	r[0]=fe[0]+fo[0];
	r[h]=fe[0]-fo[0];
	for(j=1;j<hh;++j){
		r[j]=fe[j]+fo[j]*p^j;
	};
	for(;j<h;++j){
		r[j]=conjugate(fe[h-j])+conjugate(fo[h-j])*p^(j);
	};
*/
	double *rotations = Secants.Rotations(_lnh);
	const long n = 1<<_lnh;
	const int h=n>>1;
	const int hh=h>>1;

	double sr=*re - *ro;

	*R=re[0]+ro[0];
	*I=0.0;
	for(int i=1;i<hh;++i){
		R[i] = ro[i]*rotations[i+i]-io[i]*rotations[1+i+i] + re[i];
		I[i] = io[i]*rotations[i+i]+ro[i]*rotations[1+i+i] + ie[i];
	}

	rotations += n-2;

	R += h;
	I += h;

	*R-- = sr;
	*I-- = 0.0;
	
	for(i=1;i<=hh;++i){
		*R-- = ro[i] * rotations[0] + io[i] * rotations[1] + re[i];
		*I-- = ro[i] * rotations[1] - io[i] * rotations[0] - ie[i];
		rotations -= 2;
	}
}

void DQFT::jhfftu(double *R, double *I, double *x)
{
	if (lnh>12){
		const long n = 1<<lnh;
		const int h=n>>1;
		const int hh=h>>1;
		const int ansLen = hh+1;
		int i;
		double *rotations = Secants.Rotations(lnh);
		double *fo = currentScratch;
		double *er = fo+h;
		double *ei = er+ansLen;
		double *fe = ei+ansLen;
		double *or, *oi;
		currentScratch = fe+h;

		for(i=0;i<h;++i){
			fe[i]=x[i+i];
			fo[i]=x[1+i+i];
		}
		--lnh;
		jhfftu(er,ei,fe);
		or=fe;
		oi=or+ansLen;
		currentScratch=oi+ansLen;
		jhfftu(or,oi,fo);
		++lnh;
		{
			double sr=*er - *or;
			double si=*ei - *oi;

			*R=er[0]+or[0];
			*I=ei[0]+oi[0];
			for(i=1;i<hh;++i){
				R[i] = or[i]*rotations[i+i]-oi[i]*rotations[1+i+i] + er[i];
				I[i] = oi[i]*rotations[i+i]+or[i]*rotations[1+i+i] + ei[i];
			}

			rotations += n-2;

			R += h;
			I += h;

			*R-- = sr;
			*I-- = si;
			
			for(i=1;i<=hh;++i){
				*R-- = or[i] * rotations[0] + oi[i] * rotations[1] + er[i];
				*I-- = or[i] * rotations[1] - oi[i] * rotations[0] - ei[i];
				rotations -= 2;
			}

		}

		currentScratch = fo;		
	}else{
		int n=lnh;
		Forward(R,I,x,lnh);
		lnh=n;
	}
}
