#ifndef _DEFINES_H_
#define _DEFINES_H_

typedef int BOOL;
#define FALSE 0
#define TRUE 1

#endif