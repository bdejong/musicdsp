function [] = anwrite (h,z,Name)

% function [] = anwrite (h,z,an-filename)
%
% this function writes phase-vocoder data to a .pv.an-file, which can then be
% processed with MONAN or other tools from the SNDAN package.
%
% H is a typical sndan header used as a structure. Z is a data structure with 
% phase, magn and freq informations.
% 
% Name is the name of the .pv.an-file to be written (with or w/o extension)
% If the function is started without name, you will be asked for it.
%
% See also ANREAD 


MAX=32768;

if nargin < 3
   Name = input ('write file as ? :','s'); %name of output file with extension!
end;

if (size(Name,2)>6)
  if ~strcmp(Name(end-5:end),'.pv.an')
    Name=[Name '.pv.an'];
  end;
else
  Name=[Name '.pv.an'];
end;

[fod,message] = fopen (Name,'r+','b'); %big-endian!
if (fod ~= -1)
   quest = input('file exists...overwrite? ','s');
   if (strcmp(quest,'n')) | (strcmp(quest,'N'))
      fclose(fod);
      return;
   end;
else
 
   fod=fopen(Name,'w+','b');
end;

empty=0;
s=h.performer; fprintf(fod,'%c',s);fwrite(fod,empty,'char'); %write a typical
s=h.instrument;fprintf(fod,'%c',s);fwrite(fod,empty,'char');% sndan header!
s=h.date;      fprintf(fod,'%c',s);fwrite(fod,empty,'char');
s=h.pitch;     fprintf(fod,'%c',s);fwrite(fod,empty,'char');
s=h.dyn;       fprintf(fod,'%c',s);fwrite(fod,empty,'char');
s=h.vibra;     fprintf(fod,'%c',s);fwrite(fod,empty,'char');
s=h.part;      fprintf(fod,'%c',s);fwrite(fod,empty,'char');
s=h.type;      fprintf(fod,'%c',s);fwrite(fod,empty,'char');
s=h.comments;  fprintf(fod,'%c',s);fwrite(fod,empty,'char');
s=h.andate;    fprintf(fod,'%c',s);fwrite(fod,empty,'char');
fseek(fod,0,'cof');
s=h.interpval; fwrite(fod,s,'float');
s=h.sr;        fwrite(fod,s,'float');
s=h.tl;        fwrite(fod,s,'float');
s=h.smax;      fwrite(fod,s,'float');
s=h.fa;        fwrite(fod,s,'float');
s=h.dt;        fwrite(fod,s,'float');
s=h.fftlen;    fwrite(fod,s,'int');
s=h.nhar;      fwrite(fod,s,'int');
s=h.nchans;    fwrite(fod,s,'int');
s=h.npts;      fwrite(fod,s,'int');

if (strcmp(h.type,'simple'))  %data type: simple (32 bit floats)
      bittype='float';        %           compact (16 bit short ints)
      SCALE = 1;
   elseif (strcmp(h.type,'compact'))
      bittype='ushort';
      SCALE = h.fa/MAX;
      else error('data type not supported!!');
   end;


   fwrite(fod,z.phase(1:h.nhar),'float'); %writes phase information into file!
   
   % All amplidtudes and frequency deviations for one harmonic are collected in
   % the vector 'framedata' and then written en bloc.

   for i=1:h.npts
     if (strcmp(bittype,'float'))
             framedata(1:2:2*h.nhar)=z.ampl(i,:);
             framedata(2:2:2*h.nhar)=z.freq(i,:);
         elseif (strcmp(bittype,'ushort'))
             framedata(1:2:2*h.nhar)=z.ampl(i,:)/h.smax;
             framedata(2:2:2*h.nhar)=z.freq(i,:)/(SCALE*j)+MAX;
         end
         fwrite(fod,framedata,bittype); %writes complete data for one frame
   end
   
         
fclose(fod);






      
   
