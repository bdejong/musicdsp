function [h,z] = anread(Name)

% function [h,z] = anread(an-filename)
%
% Name is the name of the .pv.an-file to be read (with or w/o extension)
%
% h contains header informations, z contains analysis data
%
% h = struct (...                  
%   'performer','  ',...
%   'instrument','  ',...
%   'date','  ',...
%   'pitch','  ',...
%   'dyn','  ',...
%   'vibra','  ',...
%   'part','  ',...
%   'type','  ',...
%   'comments','  ',...
%   'andate','  ',...
%   'interpval',0.0,...
%   'sr',0.0,...
%   'tl',0.0,...
%   'smax',0.0,...
%   'fa',0.0,...
%   'dt',0.0,...
%   'fftlen',0,...
%   'nhar',0,...
%   'nchans',0,...
%   'npts',0);
%
% z= struct(...                       
%      'phase',...
%      'ampl',...
%      'freq');
%
%
% This function reads an .pv.an file, which was created
% with sndan (gopvan) and returns the header in vector h 
% and the data in vector z. 
% H and z are structures e.g. h.performer contains the name of the performer,
% z.phase is an array of the phase data.
% If the function is started without name, you will be asked for it.
%
% See also ANWRITE



if nargin < 1
  Name	= input('Which .an-file to read?:','s');  	%name of .an-file
end

if (size(Name,2)>6)
  if ~strcmp(Name(end-5:end),'.pv.an')
    Name=[Name '.pv.an'];
  end;
else
  Name=[Name '.pv.an'];
end;

[fid, message]		= fopen (Name,'r','b'); %big-endian	
if (fid == -1),
   message,
   error,
end;

h = struct (...                  %structure for .pv.an header!
   'performer','  ',...
   'instrument','  ',...
   'date','  ',...
   'pitch','  ',...
   'dyn','  ',...
   'vibra','  ',...
   'part','  ',...
   'type','  ',...
   'comments','  ',...
   'andate','  ',...
   'interpval',0.0,...
   'sr',0.0,...
   'tl',0.0,...
   'smax',0.0,...
   'fa',0.0,...
   'dt',0.0,...
   'fftlen',0,...
   'nhar',0,...
   'nchans',0,...
   'npts',0);

head_size = 1000;    
MAX=32768;

[header,count]=fscanf(fid,'%c',head_size); %first read header to know nhar!
i=1;
j=1;
while (header(i)~=0)             %read all chars!
   h.performer(j)=header(i);
   i=i+1;
   j=j+1;
end
i=i+1;
j=1;
while (header(i)~=0)
   h.instrument(j)=header(i);
   i=i+1;
   j=j+1;
end
i=i+1;
j=1;
while (header(i)~=0)
   h.date(j)=header(i);
   i=i+1;
   j=j+1;
end
i=i+1;
j=1;
while (header(i)~=0)
   h.pitch(j)=header(i);
   i=i+1;
   j=j+1;
end
i=i+1;
j=1;
while (header(i)~=0)
   h.dyn(j)=header(i);
   i=i+1;
   j=j+1;
end
i=i+1;
j=1;
while (header(i)~=0)
   h.vibra(j)=header(i);
   i=i+1;
   j=j+1;
end
i=i+1;
j=1;
while (header(i)~=0)
   h.part(j)=header(i);
   i=i+1;
   j=j+1;
end
i=i+1;
j=1;
while (header(i)~=0)
   h.type(j)=header(i);
   i=i+1;
   j=j+1;
end
i=i+1;
j=1;
while (header(i)~=0)
   h.comments(j)=header(i);
   i=i+1;
   j=j+1;
end
i=i+1;
j=1;
while (header(i)~=0)
   h.andate(j)=header(i);
   i=i+1;
   j=j+1;
end


frewind(fid);
fseek(fid,i,'bof');

h.interpval=fread(fid,1,'float'); %read all floats!
h.sr=fread(fid,1,'float');
h.tl=fread(fid,1,'float');
h.smax=fread(fid,1,'float');
h.fa=fread(fid,1,'float');
h.dt=fread(fid,1,'float');
h.fftlen=fread(fid,1,'int');
h.nhar=fread(fid,1,'int');
h.nchans=fread(fid,1,'int');
h.npts=fread(fid,1,'int');


   z= struct(...                       %structure for phase,magn and freq data
      'phase',zeros(h.nhar,1),...
      'ampl',zeros(h.npts,h.nhar),...
      'freq',zeros(h.npts,h.nhar));
   
   
   if (strcmp(h.type,'simple'))       %data type: simple(32 bit floats) or 
      bittype='float';                % compact (16 bit short ints)
      SCALE = 1;
   elseif (strcmp(h.type,'compact'))
      bittype='ushort';
      SCALE = h.fa/MAX;
      else error('data type not supported!!');
   end;
  
   z.phase=fread(fid,h.nhar,'float'); % read phase data!

   % The amplidtudes and frequency deviations for one harmonic are derived from
   % one block of data which is read into the vector 'framedata'

   if (strcmp(bittype,'ushort'))
     harnr=(1:h.nhar); 
   end
   
   for i=1:h.npts
         framedata=fread(fid,2*h.nhar,bittype);  %read complete data for one frame
         if (strcmp(bittype,'float'))
            z.ampl(i,:)=framedata(1:2:2*h.nhar); %extract ampl data!
            z.freq(i,:)=framedata(2:2:2*h.nhar); %extract freq data!
         elseif (strcmp(bittype,'ushort'))
            z.ampl(i,:)=framedata(1:2:2*h.nhar)*h.smax; %extract ampl data!
            z.freq(i,:)=framedata(2:2:2*h.nhar).*harnr*SCALE; %extract freq data!
            disp('Halt Stop!! compact wird noch nicht unterst�tzt!');
         end
  end
   
   
fclose(fid);
